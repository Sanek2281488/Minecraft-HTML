

let creative=0,dd=0,diff=3,rsp=null,slBed=null,slSet=0,bowOn=0,bowT=0,DF=1,kbx=0,kbz=0,mobN=0,spT2=0,newD=3;const mobs=[],arrs=[],DN=['','Мирная','Лёгкая','Нормальная','Сложная','Эксперт'],DNOTE=['','Враждебных мобов нет','Мобы есть, урон слабый','Обычные мобы и урон','Мобы сильнее и точнее','Одна жизнь: после смерти мир удаляется'];const VER='Beta 1.0',crops=new Set(),sleepers=new Set();let slp=0,slT=0,sleepH=[0,1],RD=4,FOV=75,SENS=1,wt='normal',myName='Игрок',myId=0;const cheat={god:0,fly:0},YO=50,H=306,SEA=67,NT=42,RG=33,$=i=>document.getElementById(i);
const ch=new Map(),ac=new Set(),NB=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],HD=[[1,0],[-1,0],[0,1],[0,-1]];
const get=(x,y,z)=>{if(y<0)return 3;if(y>=H)return 0;const c=ch.get((x>>4)+','+(z>>4));return c?c.D[((y<<4|z&15)<<4)|(x&15)]:3};
const fget=(x,y,z)=>{const c=ch.get((x>>4)+','+(z>>4));return c?c.F[((y<<4|z&15)<<4)|(x&15)]:0};
const cell=(x,y,z)=>get(Math.floor(x),Math.floor(y),Math.floor(z));
const sol=(x,y,z)=>{const b=get(x,y,z);return b&&b!=7&&b!=8&&b!=51&&b!=52&&b!=61};
let seed=Math.random()*1e4|0;
function h2(x,y,z){const n=Math.sin(x*127.1+y*311.7+z*74.7+seed)*43758.5453;return n-Math.floor(n)}
const sm=t=>t*t*(3-2*t),L=(a,b,t)=>a+(b-a)*t;
function n3(x,y,z){const X=Math.floor(x),Y=Math.floor(y),Z=Math.floor(z),a=sm(x-X),b=sm(y-Y),c=sm(z-Z);
return L(L(L(h2(X,Y,Z),h2(X+1,Y,Z),a),L(h2(X,Y+1,Z),h2(X+1,Y+1,Z),a),b),L(L(h2(X,Y,Z+1),h2(X+1,Y,Z+1),a),L(h2(X,Y+1,Z+1),h2(X+1,Y+1,Z+1),a),b),c)}
function fbm(x,z,o){let s=0,a=1,t=0,f=1;for(let i=0;i<o;i++){s+=n3(x*f,0,z*f)*a;t+=a;a/=2;f*=2}return s/t}
function rng(s){return()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}

// ---------- мир: биомы, рельеф, пещеры, деревни ----------
// биомы: 0 равнины, 1 лес, 2 пустыня, 3 тундра
function col(x,z){const t=fbm(x/150+100,z/150,2),m=fbm(x/110-50,z/110+70,2),b=fbm(x/60,z/60,4),mt=Math.max(0,fbm(x/70+9,z/70+9,3)-.68)*6;
if(wt=='flat')return{h:20+YO,bi:t<.43?3:t>.57&&m<.5?2:m>.56?1:0};const A=wt=='amp'?1.8:1;return{h:Math.max(2+YO,Math.min(H-4,Math.floor(9+YO+b*16*A+mt*mt*105*A-(wt=='isl'?4:0)))),bi:t<.43?3:t>.57&&m<.5?2:m>.56?1:0}}
function colH(c,lx,lz){let t=H-1;while(t>0&&(!c.D[(t*16+lz)*16+lx]||c.D[(t*16+lz)*16+lx]==51||c.D[(t*16+lz)*16+lx]==52||c.D[(t*16+lz)*16+lx]==61))t--;c.h[lz*16+lx]=t;let u=t;if(c.D[(u*16+lz)*16+lx]==6||c.D[(u*16+lz)*16+lx]==63)while(u>0){const b=c.D[(u*16+lz)*16+lx];if(b==0||b==6||b==51||b==52||b==61||b==63)u--;else break}c.lh[lz*16+lx]=u}
// ---- Beta 1.0: каньоны и входные пещеры ----
function carveCanyon(c,cx,cz,cols){const X0=cx*16,Z0=cz*16,I=(x,y,z)=>(y*16+z)*16+x;
for(let lz=0;lz<16;lz++)for(let lx=0;lx<16;lx++){const x=X0+lx,z=Z0+lz,hh=cols[lz*16+lx].h;if(hh<=SEA+3)continue;
const mk=n3(x/230+310,0,z/230-120);if(mk<.46)continue;
const wx=x+(n3(x/40,0,z/40)-.5)*46,wz=z+(n3(x/40+50,0,z/40+50)-.5)*46,rg=Math.abs(n3(wx/110+17,0,wz/110-40)-.5),W=.035+Math.min(.03,(mk-.46)*.1);if(rg>=W)continue;
const fr=rg/W,d=Math.floor((24+n3(x/15,0,z/15)*14)*Math.min(1,(1-fr)*2.2));
for(let y=Math.max(3,hh-d+1);y<=hh;y++){const i=I(lx,y,lz);if(c.D[i]!=55){c.D[i]=0;c.F[i]=0}}}}
const ENT=new Map(),ES=44;
function entr(ex,ez){const k=seed+'|'+ex+'|'+ez;let t=ENT.get(k);if(t!==undefined)return t;t=null;
const r=rng(ex*374761393^ez*668265263^seed^777);
if(r()<.65){const x=ex*ES+4+(r()*(ES-8)|0),z=ez*ES+4+(r()*(ES-8)|0),h0=col(x,z).h;
if(h0>SEA+3&&h0<H-30){let a=0,bh=-1;for(let k2=0;k2<8;k2++){const q=k2*.785+r()*.3,hq=col(Math.floor(x+Math.cos(q)*12),Math.floor(z+Math.sin(q)*12)).h;if(hq>bh){bh=hq;a=q}}
let px=x+.5,py=h0+.5,pz=z+.5;const P=[],N=58;
for(let i=0;i<N;i++){P.push([px,py,pz,i<3?2.9:2.1+r()*.5,1]);a+=(r()-.5)*.3;py+=i<30?-.45:i<44?-.15:(r()-.5)*.6;if(py<9)py=9;px+=Math.cos(a);pz+=Math.sin(a)}
P[36]=[P[36][0],P[36][1],P[36][2],4.4,.7];P[N-1]=[P[N-1][0],P[N-1][1],P[N-1][2],5.2,.7];t={x,z,P}}}
ENT.set(k,t);return t}
function carveEnt(c,cx,cz){const X0=cx*16,Z0=cz*16,I=(x,y,z)=>(y*16+z)*16+x,e0=Math.floor((X0-70)/ES),e1=Math.floor((X0+86)/ES),f0=Math.floor((Z0-70)/ES),f1=Math.floor((Z0+86)/ES);
for(let ex=e0;ex<=e1;ex++)for(let ez=f0;ez<=f1;ez++){const t=entr(ex,ez);if(!t)continue;
for(const[px,py,pz,rad,sq]of t.P){if(px+rad+1<X0||px-rad-1>=X0+16||pz+rad+1<Z0||pz-rad-1>=Z0+16)continue;
const x0=Math.max(X0,Math.floor(px-rad)),x1=Math.min(X0+15,Math.floor(px+rad)),z0=Math.max(Z0,Math.floor(pz-rad)),z1=Math.min(Z0+15,Math.floor(pz+rad)),y0=Math.max(3,Math.floor(py-rad*sq)),y1=Math.min(H-3,Math.floor(py+rad*sq));
for(let y=y0;y<=y1;y++)for(let z=z0;z<=z1;z++)for(let x=x0;x<=x1;x++){const dx=x+.5-px,dy=(y+.5-py)/sq,dz=z+.5-pz;if(dx*dx+dy*dy+dz*dz<=rad*rad){const i=I(x-X0,y,z-Z0),b=c.D[i];if(b&&b!=55&&b!=7&&b!=8){c.D[i]=0;c.F[i]=0}}}}}}

function gen(cx,cz){const c={D:new Uint8Array(16*H*16),F:new Uint8Array(16*H*16),h:new Uint16Array(256),lh:new Uint16Array(256),cx,cz,q:1};ch.set(cx+','+cz,c);
const r=rng(cx*73856093^cz*19349663^seed),X0=cx*16,Z0=cz*16,cols=[],I=(x,y,z)=>(y*16+z)*16+x;
for(let lz=0;lz<16;lz++)for(let lx=0;lx<16;lx++){const x=X0+lx,z=Z0+lz,k=col(x,z);let hh=k.h;const bi=k.bi;cols.push(k);
for(let y=0;y<=hh;y++){const bc=hh<=SEA+1||bi==2;let b=3;
if(y==hh)b=hh>40+YO?12:hh>34+YO?3:bc?4:bi==3?12:1;else if(y>hh-4)b=hh>34+YO?3:bc?4:2;else{const o=r();b=y==0||(y<3&&o<.5)?55:3}
if(wt!='flat'&&y>2&&y<=hh-2){const a=n3(x/11,y/7,z/11),e=n3(x/10+40,y/6,z/10),d=n3(x/6+9,y/6,z/6);if((Math.abs(a-.5)<.045&&Math.abs(e-.5)<.05)||d>.78||a>.8)b=y<=14?8:0}
c.D[I(lx,y,lz)]=b;if(b==8)c.F[I(lx,y,lz)]=8}
for(let y=hh+1;y<=SEA;y++){c.D[I(lx,y,lz)]=7;c.F[I(lx,y,lz)]=8}}
// жилы руд: несколько блоков рядом, как в оригинальном майнкрафте (отдельный генератор — деревья и мобы не сдвигаются)
{const vr=rng(cx*83492791^cz*297121507^seed^91237),V=[[11,13,6,12,1,YO+60],[56,7,4,8,1,YO+40],[57,1.6,3,6,1,YO+10],[58,1.4,3,4,1,YO-18],[59,2.6,4,7,1,YO-8],[60,1.8,3,6,1,YO]];
for(const[ob,att,mn,mx,y0,y1]of V){let n=Math.floor(att)+(vr()<att%1?1:0);
while(n-->0){let x=2+(vr()*12|0),y=y0+(vr()*(y1-y0)|0),z=2+(vr()*12|0),pl=0,tr=0;const sz=mn+(vr()*(mx-mn+1)|0);
while(pl<sz&&tr++<sz*6){if(x>=0&&x<16&&z>=0&&z<16&&y>=1&&y<H&&c.D[I(x,y,z)]==3){c.D[I(x,y,z)]=ob;pl++}const d=vr()*6|0;if(d==0)x++;else if(d==1)x--;else if(d==2)y++;else if(d==3)y--;else if(d==4)z++;else z--}}}}
if(wt!='flat'){const v0=cols[136].bi==0&&cols[136].h>SEA+2&&cols[136].h<30+YO&&h2(cx>>1,cz>>1,7)<.14;if(!v0){carveCanyon(c,cx,cz,cols);carveEnt(c,cx,cz)}}
// деревня
const hc=cols[136].h,S=(x,y,z,b)=>{c.D[I(x,y,z)]=b},vil=cols[136].bi==0&&hc>SEA+2&&hc<30+YO&&h2(cx>>1,cz>>1,7)<.14;
if(vil){for(let z=1;z<15;z++)for(let x=1;x<15;x++){for(let y=hc+1;y<=hc+8;y++)S(x,y,z,0);for(let y=Math.max(1,hc-8);y<hc;y++)S(x,y,z,2);S(x,hc,z,1)}
for(const[x0,z0,dz]of[[1,1,4],[10,1,4],[5,10,0]]){for(let i=0;i<5;i++)for(let j=0;j<5;j++){S(x0+i,hc,z0+j,9);S(x0+i,hc+4,z0+j,9);
if(i%4==0||j%4==0)for(let y=1;y<4;y++){let b=i%4==0&&j%4==0?5:9;if(i==2&&j==dz&&y<3)b=0;if(y==2&&(i==0||i==4)&&j==2)b=0;S(x0+i,hc+y,z0+j,b)}}
S(x0+1,hc+1,z0+1,13)}
for(let i=7;i<10;i++)for(let j=7;j<10;j++){S(i,hc,j,10);S(i,hc+1,j,10)}S(8,hc,8,7);c.F[I(8,hc,8)]=8}
for(let lz=0;lz<16;lz++)for(let lx=0;lx<16;lx++)colH(c,lx,lz);
// деревья
if(!vil)for(let lz=2;lz<14;lz++)for(let lx=2;lx<14;lx++){const k=cols[lz*16+lx],t=c.h[lz*16+lx],b=c.D[I(lx,t,lz)];
if((b==1||b==12)&&r()<[.008,.06,0,.02][k.bi]){const th=4+(r()*2|0);
for(let y=t+th-2;y<=t+th+1;y++){const q=y>t+th-1?1:2;for(let i=-q;i<=q;i++)for(let j=-q;j<=q;j++)if((Math.abs(i)+Math.abs(j)<q*2||r()<.5)&&y<H&&!c.D[I(lx+i,y,lz+j)])S(lx+i,y,lz+j,6)}
for(let y=t+1;y<=t+th;y++)S(lx,y,lz,5)}}
for(let lz=0;lz<16;lz++)for(let lx=0;lx<16;lx++)colH(c,lx,lz);
if(!vil)for(let lz=0;lz<16;lz++)for(let lx=0;lx<16;lx++){const t=c.h[lz*16+lx];if(t<H-2&&c.D[I(lx,t,lz)]==1&&!c.D[I(lx,t+1,lz)]&&h2(X0+lx,77,Z0+lz)<.16)S(lx,t+1,lz,52)}
for(const e of edits)if((e[0]>>4)==cx&&(e[2]>>4)==cz&&e[1]>=0&&e[1]<H){c.D[I(e[0]&15,e[1],e[2]&15)]=e[3];c.F[I(e[0]&15,e[1],e[2]&15)]=e[4];if(e[3]==51)crops.add(e[0]+','+e[1]+','+e[2])}for(let lz=0;lz<16;lz++)for(let lx=0;lx<16;lx++)colH(c,lx,lz);
if(r()<.35){const lx=r()*16|0,lz=r()*16|0,t=c.h[lz*16+lx];if(c.D[I(lx,t,lz)]==1&&!dead.has(cx+','+cz))animal(Math.min(2,r()*3|0),X0+lx,t+1,Z0+lz,cx+','+cz,r())}}

// ---------- текстуры ----------
const cv=document.createElement('canvas');cv.width=NT*16;cv.height=16;const cx=cv.getContext('2d');
const sh=(c,r,a=40)=>[c[0]+(r-.5)*a,c[1]+(r-.5)*a,c[2]+(r-.5)*a];
function tile(i,f){const im=cx.createImageData(16,16);for(let y=0;y<16;y++)for(let x=0;x<16;x++){const c=f(x,y,h2(i*31+x,y,5),h2(i*17+x,y,9));im.data.set([c[0],c[1],c[2],c[3]??255],(y*16+x)*4)}cx.putImageData(im,i*16,0)}
const GR=[95,160,60],DI=[134,96,67],ST=[125,125,125];
tile(0,(x,y,r)=>sh(GR,r));tile(1,(x,y,r)=>y<4+(r>.6?1:0)?sh(GR,r):sh(DI,r));tile(2,(x,y,r)=>sh(DI,r));tile(3,(x,y,r)=>sh(ST,r,35));tile(4,(x,y,r)=>sh([219,207,142],r,25));
tile(5,(x,y,r)=>sh([102,81,50],x%4==0?.2:r,35));
tile(6,(x,y,r)=>{const d=Math.max(Math.abs(x-7.5),Math.abs(y-7.5));return d>6?sh([102,81,50],r,30):sh((d|0)%3==0?[120,95,58]:[160,130,80],r,20)});
tile(7,(x,y,r,q)=>{const c=sh([50,130,40],r,50);c[3]=q>.8?0:255;return c});
tile(8,(x,y,r)=>sh([50,90,200],r,30));tile(9,(x,y,r,q)=>q>.72?sh([255,200,50],r,40):sh([230,95,20],r,80));
tile(10,(x,y,r)=>y%4==3?[110,80,45]:sh([170,130,75],r,20));tile(11,(x,y,r)=>sh([110,110,110],h2((x>>2)*7,(y>>2)*3,9)*.7+r*.3,70));
tile(12,(x,y,r)=>h2((x>>1)+3,y>>1,77)>.76?[30,30,30]:sh(ST,r,35));
tile(13,(x,y,r)=>sh([240,245,250],r,15));tile(14,(x,y,r)=>x%5==2||y%5==2?[90,60,30]:sh([170,130,75],r,20));
tile(15,(x,y,r)=>sh([236,236,236],r,16));tile(16,(x,y,r)=>sh([42,42,48],r,14));tile(17,(x,y,r)=>sh([112,74,42],r,18));tile(18,(x,y,r)=>sh([242,152,192],r,16));
tile(19,(x,y,r)=>{const e=x<2||x>13||y<1||y>14,pn=x>3&&x<12&&((y>2&&y<7)||(y>8&&y<13));return x==12&&y==8?[50,50,50]:e?sh([110,75,40],r,20):pn?sh([135,98,52],r,15):sh([160,120,68],r,20)});
tile(20,(x,y,r)=>{const e=x<2||x>13||y<1||y>14,g=x>3&&x<12&&y>3&&y<12&&!(x==7||x==8||y==7||y==8);return e?sh([110,75,40],r,20):g?sh([170,210,235],r,10):sh([160,120,68],r,20)});
tile(21,(x,y,r)=>y%4==1?sh([62,40,25],r,14):sh([102,68,42],r,20)); // грядка (верх)
for(let st=0;st<4;st++)tile(22+st,(x,y,r)=>{const top=16-[4,7,11,15][st],on=x%4==1||(x%4==3&&y>top+2);if(y<top||!on)return[0,0,0,0];
if(st==3&&y<top+5)return sh([226,196,72],r,30);return sh(st==3?[176,160,60]:[72+st*12,150-st*6,40],r,30)}); // пшеница: 4 стадии
tile(26,(x,y,r)=>{const hh=[3,0,7,5,10,0,6,12,8,0,5,11,7,9,0,4][x],top=16-hh;if(!hh||y<top)return[0,0,0,0];return sh([84+(y-top)*2,148+(y&3)*7-(y-top),50],r,28)}); // кустик травы
tile(27,(x,y,r)=>{if(x>3&&x<12&&y>7&&y<14)return y>11&&x>5&&x<10?sh([200,90,20],r,40):sh([35,35,38],r,10);if(x>4&&x<11&&y>2&&y<5)return sh([40,40,44],r,10);return sh([125,125,125],r,35)}); // печка
tile(34,(x,y,r)=>x<7||x>8||y<6?[0,0,0,0]:y<9?(y==6?[255,242,168]:[255,176,46]):sh([122,82,48],r,24));
tile(40,(x,y,r)=>{if(x==0||x==15||y==0||y==15)return[...sh([205,232,242],r,18),255];if((x==2&&y>=2&&y<=5)||(y==2&&x>=2&&x<=5)||(x==y&&x>=7&&x<=9)||(x==4&&y==4))return[255,255,255,255];return[0,0,0,0]}); // стекло: рамка + блики, середина прозрачная
tile(41,(x,y,r)=>{const e=Math.min(x,y,15-x,15-y);if(e==0)return sh([150,152,158],r,10);if(e==1)return sh([232,234,238],r,8);if(x==7||x==8||y==7||y==8)return sh([188,190,196],r,10);return sh([214,216,222],r,12)}); // железный блок
tile(28,(x,y,r)=>h2(x>>1,y>>1,3)>.5?sh([30,30,30],r,20):sh([95,95,95],r,50));
const chb=(x,y,r,l,rt)=>(l&&x<1)||(rt&&x>14)||y<1||y>14?sh([95,64,28],r,16):y==5?sh([80,52,22],r,12):sh([158,113,52],r,22);
const chl=(x,y,r,x0,x1)=>x>=x0&&x<=x1&&y>=4&&y<=8?sh([205,205,205],r,25):null;
tile(35,(x,y,r)=>x<1||x>14||y<1||y>14?sh([95,64,28],r,16):sh([150,106,48],r,22));
tile(36,(x,y,r)=>chb(x,y,r,1,1));tile(37,(x,y,r)=>chl(x,y,r,7,8)||chb(x,y,r,1,1));
tile(38,(x,y,r)=>chl(x,y,r,14,15)||chb(x,y,r,1,0));tile(39,(x,y,r)=>chl(x,y,r,0,1)||chb(x,y,r,0,1));
const ore=(i,c,sd)=>tile(i,(x,y,r)=>h2((x>>1)+sd,y>>1,77)>.7?sh(c,r,50):sh(ST,r,35));
ore(29,[215,160,130],3);ore(30,[245,210,60],5);ore(31,[90,230,225],7);ore(32,[200,30,30],9);ore(33,[40,70,190],11);
const tex=new THREE.CanvasTexture(cv);tex.magFilter=tex.minFilter=THREE.NearestFilter;tex.generateMipmaps=false;

// ---------- блоки и предметы ----------
const B={1:{t:[0,2,1],n:'Трава',h:.6,d:2},2:{t:[2,2,2],n:'Земля',h:.5},3:{t:[3,3,3],n:'Камень',h:1.5,d:10,s:1},4:{t:[4,4,4],n:'Песок',h:.5},5:{t:[6,6,5],n:'Бревно',h:1},6:{t:[7,7,7],n:'Листва',h:.2,d:0},7:{t:[8,8,8]},8:{t:[9,9,9]},9:{t:[10,10,10],n:'Доски',h:1},10:{t:[11,11,11],n:'Булыжник',h:2,s:1},11:{t:[12,12,12],n:'Угольная руда',h:2,d:24,s:1},12:{t:[13,2,13],n:'Снег',h:.3},13:{t:[14,10,10],n:'Верстак',h:1},14:{t:[10,10,10],n:'Деревянные ступеньки',h:1},15:{t:[11,11,11],n:'Каменные ступеньки',h:2,s:1},16:{t:[19,19,19],h:1,d:31},17:{t:[15,10,10],h:.5},18:{t:[15,15,15],n:'Белая шерсть',h:.4},19:{t:[16,16,16],n:'Чёрная шерсть',h:.4},20:{t:[17,17,17],n:'Коричневая шерсть',h:.4},21:{t:[18,18,18],n:'Розовая шерсть',h:.4},50:{t:[21,2,2],n:'Грядка',h:.5,d:2},51:{t:[25,25,25],h:.05,d:0},52:{t:[26,26,26],h:.05,d:0},53:{t:[11,11,27],n:'Печка',h:2,s:1},54:{t:[10,10,10],n:'Забор',h:.8},55:{t:[28,28,28],n:'Бедрок'},56:{t:[29,29,29],n:'Железная руда',h:2.5,s:1},57:{t:[30,30,30],n:'Золотая руда',h:3,d:72,s:1},58:{t:[31,31,31],n:'Алмазная руда',h:3.5,d:74,s:1},59:{t:[32,32,32],n:'Редстоун',h:3,d:75,s:1},60:{t:[33,33,33],n:'Лазурит',h:3,d:76,s:1},61:{t:[34,34,34],n:'Факел',h:.05},62:{t:[35,35,37],n:'Сундук',h:1.5},63:{t:[40,40,40],n:'Стекло',h:.3},64:{t:[41,41,41],n:'Железный блок',h:5,s:1}};
const IT={92:['Деревянный меч','🗡️'],93:['Каменный меч','🗡️'],94:['Железный меч','⚔️'],95:['Алмазный меч','⚔️'],96:['Лук','🏹'],97:['Стрела','➳'],98:['Гнилая плоть','🥩'],99:['Лодка','🛶'],77:['Палка','🥢'],48:['Деревянная кирка','⛏️'],22:['Сырая свинина','🥩'],23:['Жареная свинина','🍖'],24:['Уголь','⚫'],25:['Ведро','🪣'],26:['Ведро воды','💧'],27:['Ведро лавы','🔥'],28:['Сырая говядина','🥩'],29:['Стейк','🍖'],30:['Кожа','🟫'],31:['Дверь','🚪'],32:['Сырая баранина','🥩'],33:['Жареная баранина','🍖'],38:['Белая кровать','🛏️'],39:['Чёрная кровать','🛏️'],40:['Коричневая кровать','🛏️'],41:['Розовая кровать','🛏️'],34:['Каменная кирка','⛏️'],35:['Деревянный топор','🪓'],36:['Каменный топор','🪓'],37:['Деревянная лопата','🥄'],42:['Каменная лопата','🥄'],43:['Деревянная мотыга','🌾'],44:['Каменная мотыга','🌾'],100:['Железный топор','🪓'],101:['Алмазный топор','🪓'],102:['Железная лопата','🥄'],103:['Алмазная лопата','🥄'],45:['Семена','🌱'],46:['Пшеница','🌾'],47:['Хлеб','🍞']};
Object.assign(IT,{70:['Сырое железо'],71:['Железный слиток'],72:['Сырое золото'],73:['Золотой слиток'],74:['Алмаз'],75:['Красная пыль'],76:['Лазурит'],78:['Железная кирка'],79:['Алмазная кирка']});
['Кожаные','Железные','Алмазные'].forEach((m,i)=>['ботинки','штаны','нагрудник','шлем'].forEach((n,j)=>IT[80+i*4+j]=[m+' '+n]));
const FD={98:4,22:3,23:8,28:3,29:8,32:3,33:8,47:6},nm=id=>B[id]?B[id].n:IT[id][0];
// инструменты: тип (p кирка, a топор, s лопата, h мотыга) и уровень (1 дерево, 2 камень)
const TL={92:['w',1],93:['w',2],94:['w',3],95:['w',4],96:['b',5],48:['p',1],34:['p',2],35:['a',1],36:['a',2],37:['s',1],42:['s',2],43:['h',1],44:['h',2],78:['p',3],79:['p',4],100:['a',3],101:['a',4],102:['s',3],103:['s',4]},DMG={92:4,93:5,94:6,95:7,78:5,79:6,48:3,34:4,35:4,36:5,37:3,42:4,43:2,44:3,100:6,101:7,102:5,103:6};
const BC=b=>B[b].s?'p':[5,9,13,14,16,17,54,62].includes(b)?'a':[1,2,4,12,50].includes(b)?'s':(b==6||b==51)?'h':'';
const furn=new Map(),SM={56:71,70:71,72:73,22:23,28:29,32:33,10:3,5:24,4:63},FUEL={24:48,5:9,9:9,77:3,13:9,54:9},SMT=6;let fz=null; // SM — что во что плавится, FUEL — время горения (с), SMT — время плавки
const toolMul=(id,b)=>{const t=TL[id];if(B[b]&&B[b].s&&!(t&&t[0]=='p'))return .2;return t&&B[b]&&BC(b)==t[0]?(t[1]>3?6.5:t[1]>2?4.5:t[1]>1?2.4:1.6):1};
const MAXD={1:60,2:132,3:250,4:1561,5:385},dmax=id=>MAXD[TL[id][1]],ptier=id=>{const t=TL[id];return t&&t[0]=='p'?t[1]:0},REQ={56:2,57:3,58:3,59:3,60:3,64:2},chests=new Map();let cz=null; // REQ — какой уровень кирки нужен, чтобы руда дала добычу
const ico={};for(const id in B){const c=document.createElement('canvas');c.width=c.height=32;const g=c.getContext('2d'),t=B[id].t;g.imageSmoothingEnabled=false;
const face=(ti,a,b,cc,d,e,f,sh)=>{g.setTransform(a,b,cc,d,e,f);g.drawImage(cv,ti*16,0,16,16,0,0,16,16);if(sh){g.globalCompositeOperation=id==63?'source-atop':'source-over';g.fillStyle='rgba(0,0,0,'+sh+')';g.fillRect(0,0,16,16);g.globalCompositeOperation='source-over'}};
face(t[2],15/16,7.5/16,0,15.5/16,1,8.5,.28);face(t[2],15/16,-7.5/16,0,15.5/16,16,16,.5);face(t[0],15/16,7.5/16,-15/16,7.5/16,16,1,0);
g.setTransform(1,0,0,1,0,0);ico[id]=c.toDataURL()}
const icoCv={};
function itemIcon(id){const c=document.createElement('canvas');c.width=c.height=16;const g=c.getContext('2d'),R=(x,y,w,h,k)=>{g.fillStyle=k;g.fillRect(x,y,w,h)};
const meat=(a,b)=>{R(4,5,8,7,a);R(3,6,10,5,a);R(5,6,4,2,b);R(11,2,2,3,'#f2f2f2');R(12,4,1,2,'#f2f2f2')},bk=f=>{R(3,3,10,1,'#777');R(3,5,10,1,'#bbb');R(4,6,8,6,'#9a9a9a');R(5,12,6,1,'#7a7a7a');R(4,6,8,1,'#666');if(f)R(4,5,8,2,f)};
if(id==77)for(let i=0;i<11;i++){R(2+i,13-i,2,1,'#8a5a2b');R(3+i,13-i,1,1,'#6b4420')}
if(id==54){R(2,2,3,13,'#8a5a2b');R(11,2,3,13,'#8a5a2b');R(2,2,1,13,'#a97c43');R(11,2,1,13,'#a97c43');R(2,1,3,1,'#c79a58');R(11,1,3,1,'#c79a58');R(5,4,6,2,'#b98a4a');R(5,9,6,2,'#b98a4a');R(5,5,6,1,'#7d5a2a');R(5,10,6,1,'#7d5a2a')}
if(id==14){R(1,9,14,6,'#b08a4a');R(8,3,7,6,'#b08a4a');R(1,9,7,1,'#d0aa66');R(8,3,7,1,'#d0aa66');R(1,12,14,1,'#7d5a2a');R(8,6,7,1,'#7d5a2a');R(8,8,7,1,'#7d5a2a');R(1,14,14,1,'#5a3e1c');R(14,3,1,12,'#5a3e1c')}
if(id==15){R(1,9,14,6,'#8a8a8a');R(8,3,7,6,'#8a8a8a');R(1,9,7,1,'#b0b0b0');R(8,3,7,1,'#b0b0b0');R(1,12,14,1,'#5f5f5f');R(8,6,7,1,'#5f5f5f');R(4,10,2,1,'#a5a5a5');R(11,4,2,1,'#a5a5a5');R(1,14,14,1,'#4a4a4a');R(14,3,1,12,'#4a4a4a')}
if(id==61){R(7,6,2,8,'#7a5230');R(7,3,2,3,'#ffb02e');R(8,3,1,2,'#fff2a8');R(6,4,1,2,'#ff7a1e');R(9,4,1,2,'#ff7a1e')}
{const ing=(a,b,c)=>{R(3,7,10,4,a);R(4,6,9,1,b);R(3,11,10,1,c)},lump=(a,b)=>{R(5,4,6,9,a);R(4,5,8,7,a);R(6,6,2,2,b);R(9,9,2,2,b)};
if(id==70){R(3,3,10,10,'#b4b6bc');R(3,3,10,1,'#eceef2');R(3,3,1,10,'#dadce0');R(3,12,10,1,'#6f7178');R(12,3,1,10,'#8a8c92');R(5,5,3,2,'#d6aa90');R(9,8,2,3,'#d6aa90');R(6,9,2,2,'#9a9ca2')}if(id==72)lump('#e8c860','#a8862a');
if(id==71)ing('#d8d8d8','#ffffff','#8f8f8f');if(id==73)ing('#f2d233','#fff3a0','#b8921a');
if(id==74){R(5,4,6,2,'#c8fffb');R(4,6,8,3,'#3de0d6');R(5,9,6,2,'#22a8a0');R(7,11,2,1,'#22a8a0');R(6,6,2,1,'#fff')}
if(id==75){R(4,9,8,3,'#a01010');R(5,7,6,3,'#d02020');R(7,6,2,1,'#ff6060');R(6,9,1,1,'#ff6060')}
if(id==76){R(4,5,8,8,'#2a4fbf');R(5,4,6,10,'#2a4fbf');R(6,6,2,2,'#7f9fff');R(9,9,2,2,'#7f9fff')}
if(id>=80&&id<92){const m=(id-80)>>2,sl=(id-80)&3,c=['#9a5a2a','#d0d0d0','#33d6cc'][m],h=['#c78a52','#ffffff','#b5fff9'][m];
if(sl==0){R(3,5,4,6,c);R(9,5,4,6,c);R(2,10,5,3,c);R(9,10,5,3,c);R(3,5,4,1,h);R(9,5,4,1,h)}
if(sl==1){R(4,3,8,3,c);R(4,6,3,7,c);R(9,6,3,7,c);R(4,3,8,1,h)}
if(sl==2){R(3,3,10,10,c);R(1,3,2,6,c);R(13,3,2,6,c);g.clearRect(6,3,4,2);R(3,3,3,1,h);R(10,3,3,1,h)}
if(sl==3){R(3,4,10,5,c);R(3,9,3,4,c);R(10,9,3,4,c);R(3,4,10,1,h)}}}
{const W=['#a97c43','#d2a96a'],S=['#8d8d8d','#cfcfcf'],TC={48:['p',W],34:['p',S],35:['a',W],36:['a',S],37:['s',W],42:['s',S],43:['h',W],44:['h',S],78:['p',['#e6e6e6','#ffffff']],79:['p',['#3de0d6','#b8fffa']],100:['a',['#d0d0d0','#f4f4f4']],101:['a',['#3de0d6','#b8fffa']],102:['s',['#d0d0d0','#f4f4f4']],103:['s',['#3de0d6','#b8fffa']]},q=TC[id];
if(q){const[t,[a,b]]=q;R(7,5,2,9,'#8a5a2b');
if(t=='p'){R(3,3,10,2,a);R(2,5,2,2,a);R(12,5,2,2,a);R(3,3,10,1,b)}
if(t=='a'){R(3,2,6,5,a);R(9,3,2,3,a);R(3,2,6,1,b)}
if(t=='s'){R(6,1,4,6,a);R(7,0,2,1,a);R(6,1,4,1,b)}
if(t=='h'){R(3,3,7,2,a);R(3,5,2,3,a);R(3,3,7,1,b)}}}
if(id==22)meat('#ef9aa2','#f8c8cb');if(id==23)meat('#8b4a22','#c8793a');
if(id==24){R(5,5,6,6,'#222');R(4,6,8,4,'#222');R(6,6,2,1,'#666');R(9,8,1,1,'#555');R(6,9,2,1,'#444')}
if(id==32)meat('#c4545e','#e8999c');if(id==33)meat('#7a4025','#b5702f');
if(id==31){R(4,1,8,14,'#6b4a26');R(5,2,6,5,'#a97c43');R(6,3,4,2,'#bcd8ea');R(5,9,6,5,'#a97c43');R(9,8,1,1,'#222')}
if(id>=38&&id<=41){R(2,10,12,2,'#9a6a35');R(2,12,2,2,'#6b4420');R(12,12,2,2,'#6b4420');R(2,6,12,5,['#e8e8e8','#2a2a2d','#6e4828','#f096bc'][id-38]);R(2,5,4,3,'#f4f4f4')}
if(id==28)meat('#b02a35','#e2757e');if(id==29)meat('#6b3418','#a9602b');if(id==30){R(3,3,10,10,'#8a5a2b');R(4,4,8,8,'#a06a35');R(3,3,10,1,'#6b4420');R(3,12,10,1,'#6b4420');R(3,3,1,10,'#6b4420');R(12,3,1,10,'#6b4420');for(let i=5;i<12;i+=2)R(i,3,1,1,'#d8c8a0')}if(id==25)bk();if(id==26)bk('#3a6fe0');if(id==27)bk('#ff7a1a');
if(id==45){R(4,7,2,2,'#4f7a2a');R(8,5,2,2,'#4f7a2a');R(10,9,2,2,'#4f7a2a');R(6,10,2,2,'#6b9a38');R(5,4,1,1,'#9fd05a');R(11,6,1,1,'#9fd05a');R(3,11,1,1,'#9fd05a')}
if(id==46)for(let i=0;i<3;i++){R(4+i*3,6,1,8,'#c9a63c');R(3+i*3,2,3,5,'#e6c84f');R(4+i*3,2,1,5,'#b8902a')}
if(id==47){R(3,7,10,5,'#b9772f');R(4,6,8,1,'#cf9448');R(3,11,10,1,'#8f5a22');R(5,8,2,1,'#e6b66a');R(8,8,2,1,'#e6b66a');R(10,7,2,1,'#e6b66a')}
if(id>=92&&id<=95){const bl=['#a97c43','#8d8d8d','#d8d8d8','#3de0d6'][id-92],hl=['#d2a96a','#cfcfcf','#ffffff','#b8fffa'][id-92];for(let i=0;i<9;i++){R(5+i,9-i,2,2,bl);R(5+i,9-i,1,1,hl)}for(const[x,y]of[[2,8],[3,9],[4,10],[5,11],[6,12]])R(x,y,1,1,'#6b4420');R(3,11,1,1,'#8a5a2b');R(2,12,1,1,'#8a5a2b');R(1,13,2,2,'#5a3b25')}
if(id==96){const W='#8a5a2b';R(9,1,3,1,W);R(11,2,2,2,W);R(12,4,2,3,W);R(13,7,1,2,W);R(12,9,2,3,W);R(11,12,2,2,W);R(9,14,3,1,W);for(let y=2;y<14;y++)R(6,y,1,1,'#e8e8e8');R(7,1,2,1,'#e8e8e8');R(7,14,2,1,'#e8e8e8')}
if(id==97){for(let i=0;i<10;i++)R(3+i,12-i,1,1,'#8b6a3a');R(11,2,2,2,'#aaaaaa');R(12,1,2,1,'#cccccc');R(2,11,1,1,'#fff');R(3,13,1,1,'#fff');R(1,12,1,1,'#ddd');R(4,13,1,1,'#ddd')}
if(id==98)meat('#6a7f3c','#8fa352');
if(id==99){
 // top-down pixel boat icon with a wooden rim and visible planks
 R(2,3,12,2,'#6b4728');R(1,5,14,7,'#805128');R(2,12,12,2,'#5a3a20');
 R(3,5,10,6,'#c19458');R(4,5,2,6,'#95602f');R(7,5,2,6,'#a8753c');R(10,5,2,6,'#95602f');
 R(3,4,10,1,'#e0b778');R(2,5,1,6,'#d0a064');R(13,5,1,6,'#d0a064');
 R(4,6,1,4,'#714821');R(8,6,1,4,'#714821');R(11,6,1,4,'#714821');R(4,13,8,1,'#3d2a19');
}
icoCv[id]=c;return c.toDataURL()}
for(const id in IT)ico[id]=itemIcon(id);ico[61]=itemIcon(61);ico[54]=itemIcon(54);ico[14]=itemIcon(14);ico[15]=itemIcon(15);
const icon=id=>`<img src="${ico[id]}">`;

// ---------- рендер чанков ----------
const FACES=[[1,0,0,[[1,0,1],[1,0,0],[1,1,0],[1,1,1]],2,.8],[-1,0,0,[[0,0,0],[0,0,1],[0,1,1],[0,1,0]],2,.8],[0,1,0,[[0,1,1],[1,1,1],[1,1,0],[0,1,0]],0,1],[0,-1,0,[[0,0,0],[1,0,0],[1,0,1],[0,0,1]],1,.5],[0,0,1,[[0,0,1],[1,0,1],[1,1,1],[0,1,1]],2,.65],[0,0,-1,[[1,0,0],[0,0,0],[0,1,0],[1,1,0]],2,.65]];
const UV=[[0,0],[1,0],[1,1],[0,1]];
const lt=(x,y,z)=>{const c=ch.get((x>>4)+','+(z>>4));if(!c)return 1;const t=c.lh[(z&15)*16+(x&15)];return y>=t?1:Math.max(.03,1-(t-y)*.17)};
const scene=new THREE.Scene(),SKY=new THREE.Color(0x87ceeb),NIGHT=new THREE.Color(0x0a0f24),skyC=new THREE.Color();scene.background=new THREE.Color();
const fogN=new THREE.Fog(0,40,RD*16+4),fogW=new THREE.Fog(0x2040a0,.5,14),fogL=new THREE.Fog(0xc04010,.1,3);scene.fog=fogN;
const camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,.05,200);camera.rotation.order='YXZ';
const renderer=new THREE.WebGLRenderer({antialias:false});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);document.body.prepend(renderer.domElement);
const matO=new THREE.MeshBasicMaterial({map:tex,vertexColors:true,alphaTest:.5}),matW=new THREE.MeshBasicMaterial({map:tex,vertexColors:true,transparent:true,opacity:.72,depthWrite:false});
const SUNU={value:new THREE.Vector4(0,1,0,0)},BRU={value:1},HL=[],HLU={value:[0,1,2,3].map(()=>new THREE.Vector4(0,0,0,0))};let EM=[],BL=[0,0,0];const NOL=[0,0,0];
function lm(m){m.onBeforeCompile=sd=>{sd.uniforms.uBr=BRU;sd.uniforms.uSun=SUNU;sd.uniforms.uHL=HLU;sd.vertexShader=sd.vertexShader.replace('#include <common>','#include <common>\nattribute vec3 bcol;varying vec3 vB;varying vec3 vWp;uniform vec4 uHL[4];').replace('#include <color_vertex>','#include <color_vertex>\nvB=bcol;vWp=(modelMatrix*vec4(position,1.)).xyz;{vec3 wp=(modelMatrix*vec4(position,1.)).xyz;for(int i=0;i<4;i++){if(uHL[i].w>0.){float d=distance(wp,uHL[i].xyz);float v0=clamp(1.-d/uHL[i].w,0.,1.);vB=max(vB,vec3(1.,.78,.45)*(v0*(.4+.6*v0)));}}}');
sd.fragmentShader=sd.fragmentShader.replace('#include <common>','#include <common>\nvarying vec3 vB;varying vec3 vWp;uniform float uBr;uniform vec4 uSun;').replace('#include <color_fragment>','vec3 fN=normalize(cross(dFdx(vWp),dFdy(vWp)));float sL=mix(1.,.8+.32*max(dot(fN,uSun.xyz),0.),uSun.w);diffuseColor.rgb*=min(vColor*uBr*sL+vB,vec3(1.15));')};m.customProgramCacheKey=()=>'lm'}
lm(matO);lm(matW);
let skyF=1,plS=1,skyT=1,skyTt=0;const skyD=new THREE.Color();
// освещённость в точке (небо × время суток, факелы, лава) — для руки, игроков, мобов
function lightAt(x,y,z){const X=Math.floor(x),Y=Math.floor(y),Z=Math.floor(z);let r=0;const sk=lt(X,Y,Z)*BRU.value;
for(let a=-1;a<=1;a++)for(let e=-1;e<=1;e++){const o=ch.get(((X>>4)+a)+','+((Z>>4)+e));if(o)for(const q of emOf(o)){const dx=q[0]-x,dy=q[1]-y,dz=q[2]-z,d2=dx*dx+dy*dy+dz*dz;if(d2<q[3]*q[3]){const v0=1-Math.sqrt(d2)/q[3];r=Math.max(r,v0*(.4+.6*v0))}}}
for(const q of HL){const dx=q[0]-x,dy=q[1]-y,dz=q[2]-z,d2=dx*dx+dy*dy+dz*dz;if(d2<q[3]*q[3]){const v0=1-Math.sqrt(d2)/q[3];r=Math.max(r,v0*(.4+.6*v0))}}
return Math.max(.06,Math.min(1,Math.max(sk,r)))}
// источники света чанка: факелы и открытая лава (кэш в c.em, сбрасывается при их изменении)
function emOf(c){if(!c.em){const a=[],X0=c.cx*16,Z0=c.cz*16;let mx=0;for(const v of c.h)if(v>mx)mx=v;
for(let y=0;y<=Math.min(H-1,mx+2);y++)for(let lz=0;lz<16;lz++)for(let lx=0;lx<16;lx++){const b=c.D[(y*16+lz)*16+lx];if(b==61)a.push([X0+lx+.5,y+.5,Z0+lz+.5,10,1,.78,.45]);
else if(b==8){const x=X0+lx,z=Z0+lz;if(!get(x,y+1,z)||!get(x+1,y,z)||!get(x-1,y,z)||!get(x,y,z+1)||!get(x,y,z-1)||!get(x,y-1,z))a.push([x+.5,y+.5,z+.5,9,1,.5,.2])}}c.em=a}return c.em}
function bl(x,y,z,s=1){if(!EM.length)return NOL;let r=0,g=0,b=0;const px=x+.5,py=y+.5,pz=z+.5;
for(const e of EM){const dx=e[0]-px,dy=e[1]-py,dz=e[2]-pz,d2=dx*dx+dy*dy+dz*dz;if(d2>=e[3]*e[3])continue;const v0=1-Math.sqrt(d2)/e[3],v=v0*(.4+.6*v0);if(v*e[4]>r)r=v*e[4];if(v*e[5]>g)g=v*e[5];if(v*e[6]>b)b=v*e[6]}return[r*s,g*s,b*s]}
function mk(T,m,X,Z){if(!T.i.length)return null;const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(T.p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(T.u,2));g.setAttribute('color',new THREE.Float32BufferAttribute(T.c,3));g.setAttribute('bcol',new THREE.Float32BufferAttribute(T.b,3));g.setIndex(T.i);const o=new THREE.Mesh(g,m);o.position.set(X,0,Z);scene.add(o);return o}
function drop(c){if(c.m)c.m.forEach(o=>{if(o){scene.remove(o);o.geometry.dispose()}});c.m=null}
function cross(T,tl,lx,y,lz,k){for(const[a,b,c,d]of[[0,0,1,1],[0,1,1,0]]){const base=T.p.length/3;[[a,0,b],[c,0,d],[c,1,d],[a,1,b]].forEach((v,j)=>{T.p.push(lx+v[0],y+v[1],lz+v[2]);T.u.push((tl+.01+UV[j][0]*.98)/NT,.01+UV[j][1]*.98);T.c.push(k,k,k);T.b.push(BL[0],BL[1],BL[2])});
T.i.push(base,base+1,base+2,base,base+2,base+3,base,base+2,base+1,base,base+3,base+2)}}
function build(c){drop(c);const O={p:[],u:[],c:[],i:[],b:[]},Wt={p:[],u:[],c:[],i:[],b:[]},X0=c.cx*16,Z0=c.cz*16;
EM=[];for(let a=-1;a<=1;a++)for(let e=-1;e<=1;e++){const o=ch.get((c.cx+a)+','+(c.cz+e));if(o)for(const q of emOf(o))if(q[0]>X0-10&&q[0]<X0+26&&q[2]>Z0-10&&q[2]<Z0+26)EM.push(q)}if(EM.length>300){const st=Math.ceil(EM.length/300);EM=EM.filter((_,i)=>i%st==0)}
let mx=0;for(const v of c.h)if(v>mx)mx=v;for(let y=0;y<=Math.min(H-1,mx+2);y++)for(let lz=0;lz<16;lz++)for(let lx=0;lx<16;lx++){const b=c.D[(y*16+lz)*16+lx];if(!b)continue;const x=X0+lx,z=Z0+lz,T=b==7?Wt:O;
if(PT.has(b)){BL=bl(x,y,z);part(O,b,c.F[(y*16+lz)*16+lx],lx,y,lz,x,z);continue}if(b==51||b==52){BL=bl(x,y,z);cross(O,b==51?22+(c.F[(y*16+lz)*16+lx]&3):26,lx,y,lz,lt(x,y,z));continue}for(const f of FACES){const nx=lx+f[0],nz=lz+f[2],ny=y+f[1],n=(nx>=0&&nx<16&&nz>=0&&nz<16&&ny>=0&&ny<H)?c.D[(ny*16+nz)*16+nx]:get(x+f[0],ny,z+f[2]);if(!(n==0||n==51||n==52||PT.has(n)||(n!=b&&(n==6||n==7||n==63))))continue;
const k=f[5]*(b==8?1:lt(x+f[0],y+f[1],z+f[2])),t=B[b].t[f[4]],base=T.p.length/3;BL=bl(x+f[0],y+f[1],z+f[2],f[5]);
f[3].forEach((v,j)=>{T.p.push(lx+v[0],y+v[1],lz+v[2]);T.u.push((t+.01+UV[j][0]*.98)/NT,.01+UV[j][1]*.98);T.c.push(k,k,k);T.b.push(BL[0],BL[1],BL[2])});
T.i.push(base,base+1,base+2,base,base+2,base+3)}}
const w=mk(Wt,matW,X0,Z0);if(w)w.renderOrder=1;c.m=[mk(O,matO,X0,Z0),w];c.q=0}
function setB(x,y,z,b,f=8){if(y<0||y>=H)return;const c=ch.get((x>>4)+','+(z>>4));if(!c)return;const lx=x&15,lz=z&15,i=((y<<4|lz)<<4)|lx;const ob=c.D[i];c.D[i]=b;c.F[i]=f;if(b==62||ob==62)lidSync(x,y,z,b,f);if(ob==61||b==61||ob==8||b==8){const lv=ob==8||b==8;
if(!lv&&c.em){const ex=x+.5,ey=y+.5,ez=z+.5;c.em=c.em.filter(q=>!(q[0]==ex&&q[1]==ey&&q[2]==ez));if(b==61)c.em.push([ex,ey,ez,10,1,.78,.45])}else c.em=null;
const R=lv?9:10;for(let a=-1;a<=1;a++)for(let e=-1;e<=1;e++){const o=ch.get((c.cx+a)+','+(c.cz+e));if(o){const X0=o.cx*16,Z0=o.cz*16;if(x>=X0-R&&x<X0+16+R&&z>=Z0-R&&z<Z0+16+R)o.q=1}}}if(b==51)crops.add(x+','+y+','+z);colH(c,lx,lz);c.q=1;
const n=(a,b2)=>{const o=ch.get((c.cx+a)+','+(c.cz+b2));if(o)o.q=1};if(!lx)n(-1,0);if(lx==15)n(1,0);if(!lz)n(0,-1);if(lz==15)n(0,1);
for(const d of NB)ac.add((x+d[0])+','+(y+d[1])+','+(z+d[2]));ac.add(x+','+y+','+z)}

// ---------- течение воды и лавы ----------
let fn=0;
function put(x,y,z,b,f){const o=b==7?8:7;pset(x,y,z,NB.some(d=>get(x+d[0],y+d[1],z+d[2])==o)?10:b,f)}
function fluid(){fn++;const A=[...ac].slice(0,500);A.forEach(k=>ac.delete(k));
for(const k of A){const[x,y,z]=k.split(',').map(Number),b=get(x,y,z);if(b!=7&&b!=8)continue;if(b==8&&fn%4){ac.add(k);continue}
const f=fget(x,y,z);
if(f<8&&get(x,y+1,z)!=b&&!HD.some(d=>get(x+d[0],y,z+d[1])==b&&fget(x+d[0],y,z+d[1])>f)){pset(x,y,z,0);continue}
const sp=b==8?3:7,nf=f==8?sp:f-1,dn=get(x,y-1,z);
if(dn==0)put(x,y-1,z,b,sp);else if(dn!=7&&dn!=8&&nf>=1)for(const d of HD)if(get(x+d[0],y,z+d[1])==0)put(x+d[0],y,z+d[1],b,nf)}}

// ---------- ступеньки, двери, кровати ----------
const TS=[[0,-1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1]]; // m факела: 0 на полу, 1..4 на стене; TS — где опора
function chkT(x,y,z){for(const d of[[0,1,0],[-1,0,0],[1,0,0],[0,0,-1],[0,0,1]]){const a=x+d[0],b=y+d[1],c=z+d[2];if(get(a,b,c)==61){const q=TS[fget(a,b,c)];if(a+q[0]==x&&b+q[1]==y&&c+q[2]==z){pset(a,b,c,0,0);dropItem(61,1,a+.5,b+.3,c+.5)}}}}
const PT=new Set([14,15,16,17,50,54,61,62]),lids=new Map(),lidOpen=k=>{const L=lids.get(k);return L&&!L.keep};
const fcon=(x,y,z)=>{const n=get(x,y,z);return n==54||(n&&!PT.has(n)&&n!=6&&n!=7&&n!=8&&n!=51&&n!=52)};
function fbox(x,y,z,col){const q=[[.375,0,.375,.625,col?1.5:1,.625]],A=(x0,z0,x1,z1)=>col?q.push([x0,0,z0,x1,1.5,z1]):q.push([x0,.375,z0,x1,.5625,z1],[x0,.6875,z0,x1,.9375,z1]);
if(fcon(x+1,y,z))A(.625,.4375,1,.5625);if(fcon(x-1,y,z))A(0,.4375,.375,.5625);if(fcon(x,y,z+1))A(.4375,.625,.5625,1);if(fcon(x,y,z-1))A(.4375,0,.5625,.375);return q}
const pbox=(b,m,x,y,z,col)=>{if(b==62){const q=[.0625,0,.0625,.9375,.875,.9375,.875],pc=(m>>2)&7;if(pc){const e=HD[pc-1];if(e[0]>0)q[3]=1;else if(e[0]<0)q[0]=0;else if(e[1]>0)q[5]=1;else q[2]=0}if(m&64)q[1]=.625;else if((m&32)&&lidOpen(x+','+y+','+z))q[4]=.625;return[q]}if(b==61){if(!m)return[[.4375,0,.4375,.5625,.625,.5625]];const q=TS[m],cx=.5+q[0]*.3,cz=.5+q[2]*.3;return[[cx-.0625,.2,cz-.0625,cx+.0625,.825,cz+.0625]]}if(b==54)return fbox(x,y,z,col);if(b==14||b==15){return[[0,0,0,1,.5,1],[[.5,.5,0,1,1,1],[0,.5,0,.5,1,1],[0,.5,.5,1,1,1],[0,.5,0,1,1,.5]][m&3]]}
if(b==16){const d=m&3,T=.1875,A=[[1-T,0,0,1,1,1],[0,0,0,T,1,1],[0,0,1-T,1,1,1],[0,0,0,1,1,T]],O=[[0,0,0,1,1,T],[0,0,1-T,1,1,1],[0,0,0,T,1,1],[1-T,0,0,1,1,1]];const M=[[0,0,1-T,1,1,1],[0,0,0,1,1,T],[1-T,0,0,1,1,1],[0,0,0,T,1,1]];return[m&4?(m&16?M[d]:O[d]):A[d]]}
if(b==50)return[[0,0,0,1,.9375,1]];return[[0,0,0,1,.5625,1]]};
const ctex=(m,fi,f)=>{if(fi!=2)return 35;const n=HD[m&3];if(f[0]!=n[0]||f[2]!=n[1])return 36;const pc=(m>>2)&7;if(!pc)return 37;const e=HD[pc-1];return e[0]*n[1]-e[1]*n[0]>0?38:39};
function cuv(f,q,X,Y,Z){if(f[1])return[(X-q[0])/(q[3]-q[0]),(Z-q[2])/(q[5]-q[2])];const h=Y/(q[6]||q[4]-q[1]);if(f[0]){const t=(Z-q[2])/(q[5]-q[2]);return[f[0]>0?1-t:t,h]}const t=(X-q[0])/(q[3]-q[0]);return[f[2]>0?t:1-t,h]}
const ptex=(b,m,fi,f)=>b==62?ctex(m,fi,f):b==61?34:b==54?10:b==50?(fi==0?21:2):b==14?10:b==15?11:b==16?(m&8?20:19):(fi==0?15+((m>>2)&3):10);
// настенный факел: стержень 2×2 пикселя, наклонён на 45° верхушкой от стены
function torchW(T,m,lx,y,lz,x,z){const w=TS[m],S=Math.SQRT1_2,hw=.0625,L=.625,n=[-w[0],0,-w[2]],a=[n[0]*S,S,n[2]*S],t=[n[2],0,-n[0]],v=[-n[0]*S,S,-n[2]*S],B0=[.5+w[0]*.46,.25,.5+w[2]*.46];
const C=(i,sx,sy)=>[0,1,2].map(k=>B0[k]+a[k]*i*L+t[k]*sx*hw+v[k]*sy*hw),u0=.4375,u1=.5625,vt=.625,e0=.4375,e1=.5625,sd=[[u0,0],[u1,0],[u1,vt],[u0,vt]],ec=[[u0,e0],[u1,e0],[u1,e1],[u0,e1]];
const F=[[[C(0,1,-1),C(0,1,1),C(1,1,1),C(1,1,-1)],t,sd],[[C(0,-1,-1),C(0,-1,1),C(1,-1,1),C(1,-1,-1)],t.map(q=>-q),sd],[[C(0,-1,1),C(0,1,1),C(1,1,1),C(1,-1,1)],v,sd],[[C(0,-1,-1),C(0,1,-1),C(1,1,-1),C(1,-1,-1)],v.map(q=>-q),sd],
[[C(1,-1,-1),C(1,1,-1),C(1,1,1),C(1,-1,1)],a,ec],[[C(0,-1,-1),C(0,1,-1),C(0,1,1),C(0,-1,1)],a.map(q=>-q),ec]],sk=lt(x,y,z);
for(let[P,o,U]of F){P=P.slice();U=U.slice();const e1v=[P[1][0]-P[0][0],P[1][1]-P[0][1],P[1][2]-P[0][2]],e2v=[P[3][0]-P[0][0],P[3][1]-P[0][1],P[3][2]-P[0][2]],N=[e1v[1]*e2v[2]-e1v[2]*e2v[1],e1v[2]*e2v[0]-e1v[0]*e2v[2],e1v[0]*e2v[1]-e1v[1]*e2v[0]];
if(N[0]*o[0]+N[1]*o[1]+N[2]*o[2]<0){P.reverse();U.reverse()}
const sh=.75+.25*o[1],base=T.p.length/3;P.forEach((q,j)=>{T.p.push(lx+q[0],y+q[1],lz+q[2]);T.u.push((34+.01+U[j][0]*.98)/NT,.01+U[j][1]*.98);T.c.push(sh*sk,sh*sk,sh*sk);T.b.push(BL[0]*sh,BL[1]*sh,BL[2]*sh)});
T.i.push(base,base+1,base+2,base,base+2,base+3)}}
function part(T,b,m,lx,y,lz,x,z){if(b==61&&m>0)return torchW(T,m,lx,y,lz,x,z);const occ=n=>n&&!PT.has(n)&&n!=6&&n!=7&&n!=51&&n!=52&&n!=63;
for(const q of pbox(b,m,x,y,z))for(const f of FACES){
const bd=f[0]>0?q[3]==1:f[0]<0?q[0]==0:f[1]>0?q[4]==1:f[1]<0?q[1]==0:f[2]>0?q[5]==1:q[2]==0;
if(bd&&occ(get(x+f[0],y+f[1],z+f[2])))continue;
const k=f[5]*lt(x,y,z),base=T.p.length/3,tl=ptex(b,m,f[4],f);
f[3].forEach(v=>{const X=v[0]?q[3]:q[0],Y=v[1]?q[4]:q[1],Z=v[2]?q[5]:q[2],u=f[0]?Z-(b==61?q[2]-.4375:0):X-(b==61?q[0]-.4375:0),w=f[1]?Z-(b==61?q[2]-.4375:0):Y-(b==61?q[1]:0);
const cu=b==62?cuv(f,q,X,Y,Z):null;T.p.push(lx+X,y+Y,lz+Z);T.u.push((tl+.01+(cu?cu[0]:u)*.98)/NT,.01+(cu?cu[1]:w)*.98);T.c.push(k,k,k);T.b.push(BL[0]*f[5],BL[1]*f[5],BL[2]*f[5])});
T.i.push(base,base+1,base+2,base,base+2,base+3)}}
const dirOf=()=>{const fx=-Math.sin(p.yaw),fz=-Math.cos(p.yaw);return Math.abs(fx)>Math.abs(fz)?(fx>0?0:1):(fz>0?2:3)};
function setDoorOpen(x,y,z,open){const m=fget(x,y,z),lo=m&8?y-1:y;for(const yy of[lo,lo+1])if(get(x,yy,z)==16){const q=fget(x,yy,z);pset(x,yy,z,16,open?q|4:q&~4)}}
function toggleDoor(x,y,z){const m=fget(x,y,z),lo=m&8?y-1:y,q=fget(x,lo,z),open=!(q&4);setDoorOpen(x,lo,z,open);
if(q&32){const d=q&3,ax=d<2?[0,1]:[1,0],sg=q&64?1:-1,a=x+ax[0]*sg,c=z+ax[1]*sg;if(get(a,lo,c)==16)setDoorOpen(a,lo,c,open)}
if(!sfx('door',.8,.95+Math.random()*.1)){noise(.12,.25,1200,'lowpass');tone(140,.12,'square',.08,100)}}
// двойные двери: две двери рядом (одинаково повёрнутые) открываются вместе и расходятся в разные стороны
function placeDoor(x,y,z,m){const d=m&3,ax=d<2?[0,1]:[1,0],NP=~(16|32|64);let mm=m;
for(const sg of[-1,1]){const a=x+ax[0]*sg,c=z+ax[1]*sg;if(get(a,y,c)!=16)continue;const q=fget(a,y,c);if((q&8)||(q&3)!=d||(q&32))continue;
const mir=(d==0||d==2)?sg<0:sg>0;mm=(m&NP)|32|(sg>0?64:0)|(mir?16:0)|(q&4);
const nb=32|(sg<0?64:0)|(mir?0:16);pset(a,y,c,16,(q&NP)|nb);pset(a,y+1,c,16,(fget(a,y+1,c)&NP)|nb);break}
pset(x,y,z,16,mm);pset(x,y+1,z,16,mm|8)}
function unpairDoor(x,y,z,m){if(!(m&32))return;const d=m&3,ax=d<2?[0,1]:[1,0],sg=m&64?1:-1,a=x+ax[0]*sg,c=z+ax[1]*sg,lo=m&8?y-1:y;
for(const yy of[lo,lo+1])if(get(a,yy,c)==16){const q=fget(a,yy,c);if((q&3)==d&&(q&32))pset(a,yy,c,16,q&~(16|32|64))}}
function startSleep(x,y,z){if(slp)return;if(tm<.5)return toast('Спать можно только ночью');if(nearMob())return toast('Вы не можете спать — рядом монстры');const fm=fget(x,y,z),hd=HD[fm&3],sx=fm&16?x-hd[0]:x,sz=fm&16?z-hd[1]:z,bcx=sx+.5+hd[0]*.5,bcz=sz+.5+hd[1]*.5;for(const[rid,r]of rp)if(sleepers.has(rid)&&Math.abs(r.tx.x-bcx)<.9&&Math.abs(r.tx.z-bcz)<.9&&Math.abs(r.tx.y-(y+.5626))<1.2)return toast('Кровать занята — построй свою');sleepH=hd;slp=1;slT=0;slSet=0;slBed=[sx,y,sz];p.x=sx+.5+hd[0]*.5;p.z=sz+.5+hd[1]*.5;p.y=y+.5626;p.yaw=Math.atan2(hd[0],hd[1]);p.vx=p.vz=p.vy=0;
const d=$('dark');d.style.transition='opacity 3s';d.style.opacity=.82;$('wake').style.display='block';snd({t:'z',v:1});document.exitPointerLock();ovs()}
function lieSync(g,on,x,y,z,hx,hz){const u=g.userData;if(on){u.lying=1;g.rotation.order='YXZ';g.rotation.set(-Math.PI/2,Math.atan2(-hx,-hz),0);g.position.set(x-hx*.9,y+.15,z-hz*.9);if(u.hd)u.hd.rotation.x=0;if(u.nt)u.nt.visible=false}else if(u.lying){u.lying=0;g.rotation.set(0,g.rotation.y,0);if(u.nt)u.nt.visible=true}}
function wake(){if(!slp)return;slp=0;const d=$('dark');d.style.transition='opacity 1.2s';d.style.opacity=0;$('wake').style.display='none';$('zmsg').textContent='';p.pitch=0;snd({t:'z',v:0});
lockPtr();setTimeout(ovs,250)}
$('wake').onclick=wake;
function sleepTick(dt){if(!slp)return;slT+=dt;p.pitch+=(1.35-p.pitch)*Math.min(1,dt*8);
const ids=[...rp.keys()],cnt=ids.filter(i=>sleepers.has(i)).length+1,tot=ids.length+1,msg=tot>1?`Спят: ${cnt}/${tot}`+(cnt<tot?' — ждём остальных':''):'Zzz…';
if($('zmsg').textContent!=msg)$('zmsg').textContent=msg;
if(slT>=2&&!slSet&&slBed){slSet=1;rsp=slBed.slice();toast('Точка возрождения установлена')}if(nearMob()){toast('Рядом монстры — вы проснулись');wake()}
if(host()&&cnt==tot&&slT>=4&&tm>=.5){tm=.02;snd({t:'tm',v:tm})}
if(tm<.5)wake()}

// ---------- физика ----------
function hit(e,x,y,z){const r=e.w/2-.001;for(let i=Math.floor(x-r);i<=Math.floor(x+r);i++)for(let j=Math.floor(y)-1;j<=Math.floor(y+e.h-.001);j++)for(let k=Math.floor(z-r);k<=Math.floor(z+r);k++){const b=get(i,j,k);if(!b||b==7||b==8||b==51||b==52||b==61)continue;if(j<Math.floor(y)&&b!=54)continue;if(!PT.has(b))return 1;
for(const q of pbox(b,fget(i,j,k),i,j,k,1))if(x+r>i+q[0]&&x-r<i+q[3]&&y+e.h>j+q[1]&&y<j+q[4]&&z+r>k+q[2]&&z-r<k+q[5])return 1}return 0}
function mv(e,dx,dy,dz){e.hx=0;const gr=e.g;if(!hit(e,e.x+dx,e.y,e.z))e.x+=dx;else if(e.st&&gr&&dx&&!hit(e,e.x+dx,e.y+.6,e.z)){e.y+=.6;e.x+=dx}else e.hx=1;if(!hit(e,e.x,e.y,e.z+dz))e.z+=dz;else if(e.st&&gr&&dz&&!hit(e,e.x,e.y+.6,e.z+dz)){e.y+=.6;e.z+=dz}else e.hx=1;
e.g=0;if(!hit(e,e.x,e.y+dy,e.z))e.y+=dy;else{if(dy<0)e.g=1;e.vy=0}}
const topY=(x,z)=>{for(let y=H-1;y>0;y--){const b=get(x,y,z);if(b&&b!=6&&b!=51&&b!=52&&b!=61)return y}return 0};

// ---------- игрок и инвентарь ----------
const p={x:0,y:0,z:0,vx:0,vy:0,vz:0,w:.6,h:1.8,yaw:0,pitch:0,hp:20,food:20,g:0,st:1};
const oh=[null];let hand=0,swL=0;const inv=Array(27).fill(null),arm=Array(4).fill(null),AP=[[1,2,3,1],[2,5,6,2],[3,6,8,3]],AT=id=>id>=80&&id<92?(id-80)&3:-1,aDef=()=>1-Math.min(.8,arm.reduce((s,a)=>s+(a?AP[(a.id-80)>>2][(a.id-80)&3]:0),0)*.04),gr=Array(9).fill(null);let sel=0,cur=null,gn=2,out=null,invOpen=false,locked=false,tm=.1;
const cnt=id=>inv.reduce((s,a)=>s+(a&&a.id==id?a.n:0),0);
function add(id,n,w){if(TL[id]){for(let k=0;k<n;k++){const i=inv.indexOf(null);if(i<0){toast('Инвентарь полон');break}inv[i]={id,n:1,w:w||0}}return ref()}
const s=inv.find(a=>a&&a.id==id);if(s)s.n+=n;else{const i=inv.indexOf(null);if(i<0)return toast('Инвентарь полон');inv[i]={id,n}}ref()}
function wearTool(n){if(creative)return;const s=hand?oh[0]:inv[sel];if(!s||!TL[s.id])return;s.w=(s.w||0)+n;
if(s.w>=dmax(s.id)){toast(nm(s.id)+' сломалась');if(!sfx('toolbreak')){noise(.15,.3,900);tone(180,.2,'square',.12,70)}if(s.n>1){s.n--;s.w=0}else if(hand)oh[0]=null;else inv[sel]=null}ref()}
function take(id,n){if(creative)return;if(hand){const a=oh[0];if(a&&a.id==id){a.n-=n;if(a.n<=0)oh[0]=null}ref();return}for(let i=0;i<27&&n>0;i++){const a=inv[i];if(a&&a.id==id){const t=Math.min(n,a.n);a.n-=t;n-=t;if(!a.n)inv[i]=null}}ref()}
function spawn(){const q=findSpawn()||[.5,130,.5];p.x=q[0];p.y=q[1];p.z=q[2];p.vy=0}
function findSpawn(){for(let t=0;t<999;t++){const x=(spr()-.5)*(40+t*8)|0,z=(spr()-.5)*(40+t*8)|0;if(col(x,z).h>SEA+2){
for(let i=-1;i<=1;i++)for(let j=-1;j<=1;j++)if(!ch.get(((x>>4)+i)+','+((z>>4)+j)))gen((x>>4)+i,(z>>4)+j);
if(topY(x,z)<col(x,z).h-3)continue;return[x+.5,topY(x,z)+1,z+.5]}}return null}
function toast(t){const e=$('toast');e.textContent=t;e.style.opacity=1;clearTimeout(toast.t);toast.t=setTimeout(()=>e.style.opacity=0,1800)}

// ---------- крафт и UI ----------
const RC=[{p:[[5]],o:[9,4]},{p:[[9],[9]],o:[77,4]},{p:[[9,9],[9,9]],o:[13,1]},{p:[[9,9,9],[9,0,9],[9,9,9]],o:[62,1]},{p:[[9,9,9],[0,77,0],[0,77,0]],o:[48,1]},{p:[[10,0,10],[0,10,0]],o:[25,1]},{s:[22,24],o:[23,2]},{s:[28,24],o:[29,2]},{s:[32,24],o:[33,2]},{p:[[9,0,0],[9,9,0],[9,9,9]],o:[14,4]},{p:[[0,0,9],[0,9,9],[9,9,9]],o:[14,4]},{p:[[10,0,0],[10,10,0],[10,10,10]],o:[15,4]},{p:[[0,0,10],[0,10,10],[10,10,10]],o:[15,4]},{p:[[9,9],[9,9],[9,9]],o:[31,1]},{p:[[18,18,18],[9,9,9]],o:[38,1]},{p:[[19,19,19],[9,9,9]],o:[39,1]},{p:[[20,20,20],[9,9,9]],o:[40,1]},{p:[[21,21,21],[9,9,9]],o:[41,1]},{p:[[71,71,71],[71,71,71],[71,71,71]],o:[64,1]},{s:[64],o:[71,9]}];
for(const[m,i]of[[9,0],[10,1]]){const q=(p,o)=>RC.push({p,o:[o,1]});
if(i)q([[m,m,m],[0,77,0],[0,77,0]],34);
q([[m,m],[m,77],[0,77]],35+i);q([[m,m],[77,m],[77,0]],35+i);
q([[m],[77],[77]],37+i*5);
q([[m,m],[0,77],[0,77]],43+i);q([[m,m],[77,0],[77,0]],43+i);q([[m],[m],[77]],92+i)}
RC.push({p:[[46,46,46]],o:[47,1]},{p:[[9,77,9],[9,77,9]],o:[54,3]},{p:[[10,10,10],[10,0,10],[10,10,10]],o:[53,1]});
[30,71,74].forEach((m,i)=>[[[m,0,m],[m,0,m]],[[m,m,m],[m,0,m],[m,0,m]],[[m,0,m],[m,m,m],[m,m,m]],[[m,m,m],[m,0,m]]].forEach((p,j)=>RC.push({p,o:[80+i*4+j,1]})));
RC.push({p:[[71,71,71],[0,77,0],[0,77,0]],o:[78,1]},{p:[[74,74,74],[0,77,0],[0,77,0]],o:[79,1]},{p:[[24],[77]],o:[61,4]});RC.push(
{p:[[71,71],[71,77],[0,77]],o:[100,1]},
{p:[[71,71],[77,71],[77,0]],o:[100,1]},
{p:[[74,74],[74,77],[0,77]],o:[101,1]},
{p:[[74,74],[77,74],[77,0]],o:[101,1]},
{p:[[71],[77],[77]],o:[102,1]},
{p:[[74],[77],[77]],o:[103,1]}
);

RC.push({p:[[71],[71],[77]],o:[94,1]},{p:[[74],[74],[77]],o:[95,1]},{p:[[24],[77],[30]],o:[97,4]},{p:[[0,77,30],[77,0,30],[0,77,30]],o:[96,1]},{p:[[30,77,0],[30,0,77],[30,77,0]],o:[96,1]});
function furnTick(dt){for(const f of furn.values()){const i0=f.s[0],fu=f.s[1],o=f.s[2],sm=i0&&SM[i0.id],can=sm&&(!o||(o.id==sm&&o.n<64));
if(f.burn>0)f.burn-=dt;
if(f.burn<=0&&can&&fu&&FUEL[fu.id]){f.burn=f.burnMax=FUEL[fu.id];if(!--fu.n)f.s[1]=null}
if(f.burn>0&&can){f.prog+=dt;if(f.prog>=SMT){f.prog=0;if(!--i0.n)f.s[0]=null;f.s[2]=o?{id:o.id,n:o.n+1}:{id:sm,n:1}}}else f.prog=Math.max(0,f.prog-dt*2)}}
function furnHTML(){fz.sg=JSON.stringify(fz.s);return`<div style="display:flex;flex-direction:column;align-items:center;gap:2px">${S('f0',fz.s[0])}<span id="fzf" style="opacity:${fz.burn>0?1:.25}">🔥</span>${S('f1',fz.s[1])}</div><div style="width:70px;height:8px;background:#0006"><i id="fzb" style="display:block;height:100%;background:#fff;width:${Math.min(100,fz.prog/SMT*100)}%"></i></div>➜${S('f2',fz.s[2])}`}
function furnUI(){if(!invOpen||!fz)return;if(JSON.stringify(fz.s)!=fz.sg)ref();const b=$('fzb'),fl=$('fzf');if(b)b.style.width=Math.min(100,fz.prog/SMT*100)+'%';if(fl)fl.style.opacity=fz.burn>0?1:.25}
function chestHTML(){const n=cz.b?54:27;return`<div style="display:flex;flex-direction:column;align-items:center;gap:4px"><div style="font-size:14px;text-shadow:0 1px 2px #000">${cz.b?'Большой сундук':'Сундук'}</div><div class="g" style="grid-template-columns:repeat(9,44px);gap:2px">${[...Array(n).keys()].map(i=>S('x'+i,(i<27?cz.a:cz.b)[i%27])).join('')}</div></div>`}
function openChest(x,y,z){const m=fget(x,y,z),pc=(m>>2)&7;let ka=x+','+y+','+z,kb=null;
if(pc){const d=HD[pc-1],x2=x+d[0],z2=z+d[1];if(get(x2,y,z2)==62){const k2=x2+','+y+','+z2;if(d[0]<0||d[1]<0){kb=ka;ka=k2}else kb=k2}}
const g=k=>{let a=chests.get(k);if(!a){a=Array(27).fill(null);chests.set(k,a)}return a};
cz={a:g(ka),b:kb?g(kb):null,ka,kb,cells:[ka,kb].filter(Boolean).map(q=>q.split(',').map(Number))};fz=null;cz.cells.forEach(([a,b,c])=>pset(a,b,c,62,fget(a,b,c)|32));tone(300,.1,'square',.08,200);openInv(2)}
function syncChest(k){if(ws&&ws.readyState==1)snd({t:'k',k,s:chests.get(k)||null})}
function setChest(k,a){const o=chests.get(k);if(o){for(let i=0;i<27;i++)o[i]=a[i]||null}else chests.set(k,a);if(invOpen&&cz)ref()}
function openFurn(k){fz=furn.get(k);if(!fz){fz={s:[null,null,null],burn:0,burnMax:0,prog:0};furn.set(k,fz)}openInv(2)}
function rec(){const n=gn;let r0=9,r1=-1,c0=9,c1=-1;for(let r=0;r<n;r++)for(let c=0;c<n;c++)if(gr[r*n+c]){r0=Math.min(r0,r);r1=Math.max(r1,r);c0=Math.min(c0,c);c1=Math.max(c1,c)}
if(r1<0)return null;const P=[];for(let r=r0;r<=r1;r++){P.push([]);for(let c=c0;c<=c1;c++)P[P.length-1].push(gr[r*n+c]?gr[r*n+c].id:0)}
const fl=P.flat().filter(x=>x).sort().join();
for(const q of RC)if(q.s?q.s.slice().sort().join()==fl:JSON.stringify(q.p)==JSON.stringify(P))return q.o;return null}
const durBar=a=>{if(!TL[a.id]||!a.w)return'';const f=Math.max(0,1-a.w/dmax(a.id));return`<span class="dur"><span style="width:${f*100}%;background:hsl(${f*120},85%,48%)"></span></span>`};
const S=(k,a)=>`<div class="sl${k=='i'+sel?' sel':''}" data-k="${k}" title="${a?nm(a.id)+(TL[a.id]?` (прочность ${dmax(a.id)-(a.w||0)}/${dmax(a.id)})`:''):''}">${a?icon(a.id)+(a.n>1?`<b>${a.n}</b>`:'')+durBar(a):''}</div>`;
function ref(){out=rec();$('bar').innerHTML=`<div id="ohs" style="opacity:${oh[0]?1:.4}">${S('h0',oh[0])}</div>`+[...Array(9).keys()].map(i=>S('i'+i,inv[i])).join('');$('cur').innerHTML=cur?icon(cur.id)+`<b>${cur.n}</b>`:'';
if(!invOpen)return;
{const cmE=$('cm');cmE.style.display=creative?'flex':'none';if(creative&&!cmE.dataset.b){cmE.dataset.b=1;cmE.innerHTML=[...Object.keys(B).filter(i=>B[i].n),...Object.keys(IT).filter(i=>i!=70)].map(Number).sort((a,b)=>a-b).map(i=>S('c'+i,{id:i,n:1})).join('')}}
{const trE=$('tr');trE.style.display=creative?'flex':'none';if(creative)trE.innerHTML='<span>Корзина: положи предмет — он пропадёт<br>(ПКМ — удалить 1 шт.)</span>'+S('t0',null).replace('</div>','<span style="font-size:22px;opacity:.8">🗑️</span></div>')} $('ar').style.display=cz?'none':'flex';$('ar').innerHTML=[0,1,2,3].map(i=>{const h=S('a'+i,arm[i]);return arm[i]?h:h.replace('</div>',`<span style="font-size:9px;opacity:.5">${['Ботинки','Штаны','Тело','Шлем'][i]}</span></div>`)}).join('')+'<span style="width:14px"></span>'+(oh[0]?S('h0',oh[0]):S('h0',null).replace('</div>','<span style="font-size:9px;opacity:.5">Лев. рука</span></div>'));
$('cr').innerHTML=cz?chestHTML():fz?furnHTML():`<div class="g" style="grid-template-columns:repeat(${gn},44px);gap:2px">${[...Array(gn*gn).keys()].map(i=>S('g'+i,gr[i])).join('')}</div>➜${S('o',out&&{id:out[0],n:out[1]})}`;
$('ig').innerHTML=[...Array(18).keys()].map(i=>S('i'+(i+9),inv[i+9])).join('')+[...Array(9).keys()].map(i=>S('i'+i,inv[i])).join('')}
$('inv').onmousedown=e=>{const t=e.target.closest('.sl');if(!t)return;const k=t.dataset.k,a=k[0],i=+k.slice(1);
if(a=='t'){if(creative&&cur){if(e.button==2&&cur.n>1)cur.n--;else cur=null}ref();return} if(a=='c'){cur={id:i,n:TL[i]||e.button==2?1:64};ref();return}
if(a=='o'){if(out&&(!cur||(cur.id==out[0]&&!TL[out[0]]&&cur.n+out[1]<=64))){gr.forEach((s,j)=>{if(s&&!--s.n)gr[j]=null});cur=cur?{id:cur.id,n:cur.n+out[1]}:{id:out[0],n:out[1]}}}
else{if(a=='f'){if(i==2){const o=fz.s[2];if(o&&(!cur||cur.id==o.id)){cur=cur?{id:cur.id,n:cur.n+o.n}:{id:o.id,n:o.n};fz.s[2]=null}ref();return}if(cur&&!(i==0?SM[cur.id]:FUEL[cur.id])){toast(i?'Это не топливо':'Это нельзя переплавить');return}}if(a=='a'&&cur&&(AT(cur.id)!=i||(arm[i]&&arm[i].id==cur.id)))return;const ar=a=='i'?inv:a=='f'?fz.s:a=='a'?arm:a=='h'?oh:a=='x'?(i<27?cz.a:cz.b):gr,ix=a=='x'?i%27:i,s=ar[ix];
if(e.button==2&&cur&&!TL[cur.id]&&(!s||s.id==cur.id)){ar[ix]=s?{id:s.id,n:s.n+1}:{id:cur.id,n:1};if(!--cur.n)cur=null}
else if(e.button==2&&cur&&TL[cur.id]&&!s){ar[ix]=cur;cur=null}else if(e.button==2){}else if(!cur){cur=s;ar[ix]=null}else if(!s){ar[ix]=cur;cur=null}else if(s.id==cur.id&&!TL[s.id]){s.n+=cur.n;cur=null}else{ar[ix]=cur;cur=s}if(a=='x')syncChest(i<27?cz.ka:cz.kb)}
ref()};
function ovs(){const show=!started||(!locked&&!invOpen&&!conOpen&&!slp&&!dd),was=mo();M.style.display=show?'flex':'none';$('inv').style.display=invOpen?'flex':'none';if(show&&!was&&started)scr('pause')}
function openInv(n){gn=n;invOpen=true;document.exitPointerLock();ref();ovs()}
function closeInv(){invOpen=false;[...gr,cur].forEach(s=>s&&add(s.id,s.n,s.w));gr.fill(null);cur=null;fz=null;if(cz&&cz.cells)cz.cells.forEach(c=>{const L=lids.get(c.join());if(L&&!L.keep)L.d=-1});cz=null;lockPtr();ref();ovs()}
const SPR=(()=>{const HM=['.XXX.XXX.','XXXXXXXXX','XXXXXXXXX','XXXXXXXXX','.XXXXXXX.','..XXXXX..','...XXX...','....X....','.........'],
FM=['....XXX..','...XXXXX.','..XXXXXXX','..XXXXXXX','..XXXXXX.','...XXXX..','..BB.....','.BB......','BB.......'];
const draw=(mask,part,food)=>{const c=document.createElement('canvas');c.width=c.height=9;const g=c.getContext('2d'),on=(x,y)=>x>=0&&y>=0&&x<9&&y<9&&mask[y][x]!='.';
for(let y=0;y<9;y++)for(let x=0;x<9;x++){if(!on(x,y))continue;const edge=!on(x-1,y)||!on(x+1,y)||!on(x,y-1)||!on(x,y+1),fl=part=='F'||(part=='H'&&x<=4);let col;
if(edge&&!(food&&mask[y][x]=='B'))col='#120606';else if(!fl)col=food?'#43322a':'#3d1515';
else if(food)col=mask[y][x]=='B'?'#f4ecd8':(x==4&&y==1)||(x==5&&y==2)?'#eaa564':'#c8681f';
else col=(x==1&&y==1)||(x==2&&y==1)?'#ff9d9d':y>=5?'#b81212':'#e61e1e';
g.fillStyle=col;g.fillRect(x,y,1,1)}return c.toDataURL()};
const o={};for(const s of'FHE'){o['h'+s]=draw(HM,s,0);o['f'+s]=draw(FM,s,1)}return o})();
{const st=document.createElement('style');st.textContent='.ic{width:20px;height:20px;image-rendering:pixelated;display:inline-block;margin-right:1px;filter:drop-shadow(0 1px 0 #0008)}.ic.wv{animation:hungerwave 1.3s ease-in-out infinite}@keyframes hungerwave{0%,55%,100%{transform:translateY(0)}25%{transform:translateY(-6px)}}';document.head.appendChild(st)}
let hudK='';
function hud(){const k=p.hp+'|'+p.food+'|'+creative;if(k!==hudK){hudK=k;const q=(v,pre,rev,wv)=>[...Array(10).keys()].map(i=>{const d=v-(rev?9-i:i)*2,s=d>=2?'F':d>=1?'H':'E';return`<img class="ic${wv?' wv':''}" src="${SPR[pre+s]}"${wv?` style="animation-delay:${(i*.1).toFixed(2)}s"`:''}>`}).join('');$('hp').innerHTML=q(p.hp,'h',0,0);$('fd').innerHTML=q(p.food,'f',1,p.food<=6)}const se=$('st');if(se)se.style.visibility=creative?'hidden':'visible'}

// ---------- ввод ----------
const keys={};let mining=false,spT=0,flT=0,lockT=0;const cvs=renderer.domElement;
// Linux: Chromium/Electron там даёт «сырую» мышь с огромными скачками → камера бешено крутится.
const LNX=/Linux|X11/.test(navigator.userAgent)&&!/Android/i.test(navigator.userAgent);
const lockPtr=()=>{const plain=()=>{try{cvs.requestPointerLock()}catch(e){}};if(!LNX)return plain();
try{const r=cvs.requestPointerLock({unadjustedMovement:true});if(r&&r.catch)r.catch(plain)}catch(e){plain()}};
addEventListener('keydown',E=>{const e=KE(E);if(dd){E.preventDefault();return}if(e.target.tagName=='INPUT')return;if(e.code=='Backquote'&&started&&!mo()&&!invOpen){e.preventDefault();openCon();return}if(e.code=='KeyT'&&started&&!mo()&&!invOpen&&!slp){e.preventDefault();openCon(true);return}if(!started||(!locked&&!invOpen))return;if(e.ctrlKey&&locked)e.preventDefault();if(e.code=='F5'){e.preventDefault();view=(view+1)%3}keys[e.code]=1;if(e.code=='Space'){e.preventDefault();if(creative&&locked&&!e.repeat){const n=performance.now();if(n-spT<350){cheat.fly^=1;p.vy=0;flT=n;spT=0;toast(cheat.fly?'Полёт включён':'Полёт выключен')}else spT=n}}
if(e.code=='KeyE')invOpen?closeInv():openInv(2);
if(e.code=='KeyQ'&&!slp){e.preventDefault();dropQ()}
if(e.code=='KeyF'&&!e.repeat&&!slp){e.preventDefault();swapHands()}
if(e.code.startsWith('Digit')&&+e.key>0){sel=e.key-1;ref()}});
addEventListener('keyup',E=>keys[kcode(E.code)]=0);
$('inv').addEventListener('mouseover',e=>{const t=e.target.closest('.sl');hovK=t?t.dataset.k:null});
$('inv').addEventListener('mousedown',e=>{if(!invOpen||!cur||e.target.closest('.sl,.g,#cr,h3,p'))return;
if(e.button==2){throwItem(cur.id,cur.w);if(!--cur.n)cur=null}else{for(let i=0;i<cur.n;i++)throwItem(cur.id,cur.w);cur=null}ref()});
addEventListener('wheel',e=>{if(dd){e.preventDefault();return}sel=(sel+(e.deltaY>0?1:8))%9;ref()});
addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('pointerlockchange',()=>{locked=document.pointerLockElement==cvs;if(locked){lockT=performance.now();if(conOpen)closeCon(false)}ovs()});
addEventListener('mousemove',e=>{$('cur').style.left=e.clientX+8+'px';$('cur').style.top=e.clientY+8+'px';if(!locked||dd)return;let dx=e.movementX,dy=e.movementY;
if(LNX){if(performance.now()-lockT<150||!isFinite(dx)||!isFinite(dy)||Math.abs(dx)>600||Math.abs(dy)>600)return}
p.yaw-=dx*.0025*SENS;p.pitch=Math.max(-1.55,Math.min(1.55,p.pitch-dy*.0025*SENS))});
addEventListener('mouseup',e=>{if(e.button==0){mining=false;if(bowOn)bowShoot()}});
addEventListener('mousedown',e=>{if(invOpen||!started||mo()||slp||dd)return;if(!locked){lockPtr();return}if(e.button==0){if(held()==96){if(!creative&&!cnt(97))toast('Нет стрел');else{bowOn=1;bowT=0}}else if(!attack())mining=true}if(e.button==2)useAny()});
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();hc.aspect=innerWidth/innerHeight;hc.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});

// ---------- луч, копание, стройка ----------
const hl=new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(1.01,1.01,1.01)),new THREE.LineBasicMaterial({color:0}));scene.add(hl);
let tg=null,mT={k:'',t:0};const held=()=>{const s=hand?oh[0]:inv[sel];return s?s.id:0};
function ray(fl){const d=new THREE.Vector3();camera.getWorldDirection(d);let pv=null;for(let t=0;t<5.5;t+=.02){const x=Math.floor(camera.position.x+d.x*t),y=Math.floor(camera.position.y+d.y*t),z=Math.floor(camera.position.z+d.z*t),b=get(x,y,z);if(b&&(fl||(b!=7&&b!=8)))return{x,y,z,pv};pv=[x,y,z]}return null}
const usable=id=>id&&(B[id]||id==31||(id>=38&&id<=41)||FD[id]||id==25||id==26||id==27||id==43||id==44||id==45||id==46||id==99);
function useAny(){const near=ridingBoat||boats.find(b=>Math.hypot(b.position.x-p.x,b.position.z-p.z)<2.2&&Math.abs(b.position.y-p.y)<2.5);if(near){if(ridingBoat===near){const b=near;ridingBoat=null;me.visible=false;{const bY=b.rotation.y;let ex=b.position.x,ez=b.position.z;for(const sg of[1,-1,0]){const tx=b.position.x+Math.cos(bY)*1.1*sg,tz=b.position.z-Math.sin(bY)*1.1*sg;if(!hit({w:p.w,h:1.8},tx,b.position.y+.3,tz)){ex=tx;ez=tz;break}}p.x=ex;p.z=ez}p.y=b.position.y+.3;b.userData.vx=b.userData.vz=0;/* Сбрасываем наклон взгляда, чтобы после выхода голова и камера не оставались запрокинутыми. */p.pitch=0;me.userData.leg.forEach(l=>{l.rotation.set(0,0,0)});me.userData.arm.forEach(a=>a.rotation.set(0,0,0));me.userData.bd.position.y=.7;me.userData.bd.rotation.set(0,0,0);me.userData.hd.rotation.set(0,0,0);me.userData.leg.forEach(l=>l.position.y=.7)}else{ridingBoat=near;me.visible=true}toast(ridingBoat?'Вы сели в лодку':'Вы вышли из лодки');return}if(oh[0]&&!usable(held())){const s0=swingT;hand=1;try{useItem()}finally{hand=0}swingT=s0;swL=.3}else useItem()}
// F — поменять предмет в руке с предметом в левой руке (в инвентаре — тот слот, на который наведена мышь)
function swapHands(){let i=sel;if(invOpen){if(hovK&&hovK[0]=='i')i=+hovK.slice(1);else return}
const a=inv[i],b=oh[0];if(!a&&!b)return;inv[i]=b;oh[0]=a;tone(420,.06,'square',.05,560);ref()}
function useItem(){swingT=.3;const id=held();
if(tg&&get(tg.x,tg.y,tg.z)==13)return openInv(3);
if(tg&&get(tg.x,tg.y,tg.z)==53)return openFurn(tg.x+','+tg.y+','+tg.z);
if(tg&&get(tg.x,tg.y,tg.z)==62)return openChest(tg.x,tg.y,tg.z);
{const tb=tg?get(tg.x,tg.y,tg.z):0;if(tb==16)return toggleDoor(tg.x,tg.y,tg.z);if(tb==17)return startSleep(tg.x,tg.y,tg.z)}
if(id==46){const a=aimA();if(a)feed(a);return}
if((id==43||id==44)&&tg){const b=get(tg.x,tg.y,tg.z);if((b==1||b==2)&&get(tg.x,tg.y+1,tg.z)==0){pset(tg.x,tg.y,tg.z,50,0);bsound(2,3);wearTool(1)}return}
if(id==45&&tg){if(get(tg.x,tg.y,tg.z)==50&&get(tg.x,tg.y+1,tg.z)==0){pset(tg.x,tg.y+1,tg.z,51,0);bsound(1,3);take(45,1)}return}
if(FD[id]){if(p.food>=20)return toast('Не голоден');p.food=Math.min(20,p.food+FD[id]);if([22,28,32,98].includes(id)&&Math.random()<(id==98?.8:.3)){p.hp-=2;toast('Сырое мясо... тошнит')}if(!sfx('eat',.9,.95+Math.random()*.1))for(let i=0;i<3;i++)noise(.07,.25,2200,'bandpass',i*.12);take(id,1);return}
if(id==25&&tg){const b=get(tg.x,tg.y,tg.z);if((b==7||b==8)&&fget(tg.x,tg.y,tg.z)==8){pset(tg.x,tg.y,tg.z,0,0);take(25,1);add(b==7?26:27,1)}return}
if(id==99){const dir=new THREE.Vector3();camera.getWorldDirection(dir);const bx=Math.floor(p.x+dir.x*1.5),bz=Math.floor(p.z+dir.z*1.5);if(Math.hypot(p.x-bx-.5,p.z-bz-.5)<.7)return toast('Слишком близко');let waterY=-1,groundY=-1;for(let yy=Math.min(H-2,Math.floor(p.y+1));yy>=Math.max(0,Math.floor(p.y)-4);yy--){const b=get(bx,yy,bz);if(b==7||b==8){waterY=yy+1;break}if(b&&b!=6&&b!=51&&b!=52&&b!=61){groundY=yy+1;break}}if(waterY<0&&groundY<0)return toast('Поставь лодку на воду или землю');const by=waterY>=0?waterY-.18:groundY;const boat=makeBoat(bx+.5,by,bz+.5,p.yaw);if(boat){boats.push(boat);take(99,1);syncBoat({t:'boat',a:'place',x:bx+.5,y:by,z:bz+.5,yaw:p.yaw})}return}
if(!tg||!tg.pv)return;const[x,y,z]=get(tg.x,tg.y,tg.z)==52?[tg.x,tg.y,tg.z]:tg.pv;
// Запрещаем размещение внутри ИЛИ непосредственно под любым игроком,
// включая других игроков в мультиплеере. Координата Y — уровень ног.
function blockConflictsWithPlayer(px,py,pz,pw=.6,ph=1.8){
 const bx0=x,bx1=x+1,bz0=z,bz1=z+1;
 const playerX0=px-pw/2,playerX1=px+pw/2,playerZ0=pz-pw/2,playerZ1=pz+pw/2;
 const overlapXZ=bx1>playerX0+.001&&bx0<playerX1-.001&&bz1>playerZ0+.001&&bz0<playerZ1-.001;
 // Верх блока, касающийся ступней, тоже считаем блоком под игроком.
 const overlapY=y<py+ph-.001&&y+1>=py-.05;
 return overlapXZ&&overlapY;
}
// Для локального персонажа ограничение снято: проверяем только остальных игроков.
for(const r of rp.values()){
 const q=r.g.position;
 if(blockConflictsWithPlayer(q.x,q.y,q.z,.6,1.8))return toast('Нельзя ставить блок внутри или под другим игроком');
}
if(id==26||id==27){put(x,y,z,id==26?7:8,8);net(x,y,z,get(x,y,z),fget(x,y,z));take(id,1);add(25,1);return}
if(id==61){const nx=x-tg.x,ny=y-tg.y,nz=z-tg.z;let m=-1;if(ny==1)m=0;else if(nx==-1)m=1;else if(nx==1)m=2;else if(nz==-1)m=3;else if(nz==1)m=4;if(m<0||get(x,y,z))return;const q=TS[m];if(!sol(x+q[0],y+q[1],z+q[2]))return;pset(x,y,z,61,m);bsound(9,3);take(61,1);return}
if((!B[id]&&id!=31&&!(id>=38&&id<=41))||id==7||id==8||id==16||id==17||y<0||y>=H)return;
if(id==62){placeChest(x,y,z);return}
if(id==31){if(y+1>=H||get(x,y+1,z)||!sol(x,y-1,z))return;placeDoor(x,y,z,dirOf()^1);bsound(9,3);take(31,1);return}
if(id>=38&&id<=41){const d=dirOf(),x2=x+[1,-1,0,0][d],z2=z+[0,0,1,-1][d],m=d|((id-38)<<2);if(get(x2,y,z2)||!sol(x,y-1,z)||!sol(x2,y-1,z2))return;pset(x,y,z,17,m);pset(x2,y,z2,17,m|16);bsound(9,3);take(id,1);return}
if(id==14||id==15){pset(x,y,z,id,dirOf());bsound(id,3);take(id,1);return}
pset(x,y,z,id,0);bsound(id,3);take(id,1)}
// два сундука вплотную (рядом, лицом в одну сторону) объединяются в двойной
function placeChest(x,y,z){let m=dirOf()^1,nb=null;
for(let k=0;k<4;k++){const a=x+HD[k][0],c=z+HD[k][1];if(get(a,y,c)!=62)continue;const q=fget(a,y,c);if((q>>2)&7)continue;const dn=q&3;if(dn<2?k>1:k<2){nb=[a,c,k,dn];break}}
if(nb){m=nb[3]|((nb[2]+1)<<2);pset(nb[0],y,nb[1],62,nb[3]|(((nb[2]^1)+1)<<2))}
pset(x,y,z,62,m);bsound(62,3);take(62,1)}
function aimA(){const d=new THREE.Vector3();camera.getWorldDirection(d);
for(let t=0;t<4;t+=.15){const x=camera.position.x+d.x*t,y=camera.position.y+d.y*t,z=camera.position.z+d.z*t;
for(const a of an)if(Math.abs(x-a.x)<a.w/2+.15&&Math.abs(z-a.z)<a.w/2+.15&&y>a.y-.1&&y<a.y+a.h+.1)return a}return null}
function attack(){swingT=.3;const boat=boats.find(b=>b!==ridingBoat&&Math.hypot(b.position.x-p.x,b.position.z-p.z)<3);if(boat){boat.userData.hits=(boat.userData.hits||0)+1;boat.rotation.z=boat.userData.hits%2?.12:-.12;setTimeout(()=>{if(boat.parent)boat.rotation.z=0},120);if(boat.userData.hits>=4){const x=boat.position.x,y=boat.position.y,z=boat.position.z;scene.remove(boat);boats.splice(boats.indexOf(boat),1);dropItem(99,1,x,y+.5,z);syncBoat({t:'boat',a:'remove',x,y,z});if(ridingBoat===boat)ridingBoat=null}else toast('Лодка: '+boat.userData.hits+'/4 ударов');return true}const a=aimA(),mm=aimM();if(mm&&(!a||Math.hypot(mm.x-p.x,mm.z-p.z)<Math.hypot(a.x-p.x,a.z-p.z))){const l=Math.hypot(mm.x-p.x,mm.z-p.z)||1,t=held();hitMob(mm,DMG[t]||1,(mm.x-p.x)/l*6,(mm.z-p.z)/l*6);if(TL[t]&&TL[t][0]=='w')wearTool(1);return true}if(!a)return false;
a.hp-=DMG[held()]||2;a.m.userData.fl=1;const l=Math.hypot(a.x-p.x,a.z-p.z)||1;a.kx=(a.x-p.x)/l*6;a.kz=(a.z-p.z)/l*6;a.vy=4;asound(a.kind,1);snd({t:'d',k:a.k,hp:a.hp,kx:a.kx,kz:a.kz});
if(a.hp<=0){dead.add(a.k);scene.remove(a.m);an.splice(an.indexOf(a),1);if(a.age==null){const D=(id,n)=>dropItem(id,n,a.x,a.y+.3,a.z);if(a.kind==0)D(22,1+(Math.random()*2|0));else if(a.kind==1){D(28,1+(Math.random()*2|0));if(Math.random()<.7)D(30,1+(Math.random()*2|0))}else{D(32,1+(Math.random()*2|0));if(Math.random()<.6)D(18+a.col,1+(Math.random()*2|0))}}}return true}

// ---------- животные ----------
const an=[];
function animal(kind,x,y,z,k,cr){const pig=kind==0,sheep=kind==2,g=new THREE.Group(),s=pig?1:sheep?1.1:1.3,mt=c=>{const m=new THREE.MeshBasicMaterial({color:c});m.userData.b=new THREE.Color(c);return m},
bx=(w,h,d,X,Y,Z,c,P=g)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mt(c));m.position.set(X,Y,Z);P.add(m)},W=0xf2f2f2,D=0x111111,BR=0x5a3b25,
ci=cr<.6?0:cr<.75?1:cr<.98?2:3,WC=[0xeeeeee,0x2b2b2e,0x6b4a2e,0xf3a6c8][ci],HC=0xd8bfa8;
if(sheep){const wl=new THREE.Color(WC).multiplyScalar(.88).getHex();
bx(.8,.65,1,0,.6,0,WC);bx(.82,.28,.5,0,.74,.15,wl);bx(.82,.22,.4,0,.5,-.3,wl);bx(.4,.4,.4,0,.72,.62,HC);bx(.44,.14,.44,0,.97,.6,WC);bx(.16,.1,.04,0,.64,.83,0xb09080);
for(const e of[-1,1]){bx(.1,.1,.02,e*.12,.76,.825,W);bx(.05,.08,.02,e*.11,.76,.835,D);bx(.16,.1,.06,e*.27,.82,.58,HC)}}
else{bx(.7,.55,.95,0,.55,0,pig?0xf0a8a8:BR);bx(.45,.45,.45,0,.65,.65,pig?0xf4b8b8:0x6a4630);
for(const e of[-1,1]){bx(.1,.1,.02,e*.14,.73,.885,W);bx(.05,.08,.02,e*.12,.73,.895,D)}
if(pig){bx(.24,.16,.1,0,.58,.92,0xf8c0c0);for(const e of[-1,1]){bx(.045,.05,.02,e*.06,.58,.975,0x8a3a4a);bx(.14,.14,.05,e*.2,.92,.62,0xe89090)}}
else{bx(.16,.34,.02,0,.7,.885,W);bx(.3,.2,.1,0,.55,.92,0xe9cdbb);for(const e of[-1,1]){bx(.05,.05,.02,e*.08,.55,.975,0x7a4a3a);bx(.07,.16,.07,e*.2,.93,.55,0xeeeedd);bx(.16,.08,.06,e*.31,.8,.6,BR)}
bx(.2,.12,.2,0,.22,-.15,0xf0b0b0);bx(.04,.25,.3,.35,.62,.2,W);bx(.04,.2,.28,-.35,.6,-.2,W);bx(.04,.18,.2,.35,.5,-.25,W);bx(.04,.22,.22,-.35,.66,.25,W);
bx(.3,.04,.35,-.05,.825,-.05,W);bx(.22,.04,.2,.15,.825,.25,W);bx(.2,.2,.04,.1,.6,-.475,W)}}
const q=[];for(const[i,j]of[[-.2,-.35],[.2,-.35],[-.2,.35],[.2,.35]]){const l=new THREE.Group();l.position.set(i,.3,j);g.add(l);bx(.18,.3,.18,0,-.15,0,pig?0xe89898:sheep?0xd9c7b5:0x3a2515,l);q.push(l)}
g.userData.q=q;g.scale.setScalar(s);scene.add(g);an.push({m:g,x:x+.5,y,z:z+.5,w:.7*s,h:.9*s,vy:0,hp:6,t:0,dir:null,kx:0,kz:0,k,kind,col:ci,pig,s,f:1,love:0,cd:0,age:null})}
function updA(a,dt){if(!ch.get((Math.floor(a.x)>>4)+','+(Math.floor(a.z)>>4)))return;if(!host()){if(a.nx!=null){a.x+=(a.nx-a.x)*.25;a.y+=(a.ny-a.y)*.25;a.z+=(a.nz-a.z)*.25;a.m.rotation.y=a.ry}a.m.position.set(a.x,a.y,a.z);return}a.t-=dt;if(a.t<=0){a.t=2+Math.random()*4;a.dir=Math.random()<.35?null:Math.random()*6.28}
if(a.kind){let tx=null,td=10;const chk=(x,z,y)=>{const d=Math.hypot(x-a.x,z-a.z);if(d<td&&Math.abs(y-a.y)<5){td=d;tx=[x,z]}};if(held()==46)chk(p.x,p.z,p.y);rp.forEach(r=>{if(r.h==46)chk(r.tx.x,r.tx.z,r.tx.y)});
if(tx){const ang=Math.atan2(tx[0]-a.x,tx[1]-a.z);a.dir=td>1.8?ang:null;a.t=.3;a.fol=1;a.m.rotation.y=ang}else if(a.fol){a.fol=0;a.dir=null;a.t=1.5}}
const wet=cell(a.x,a.y+.3,a.z)==7;a.kx*=.9;a.kz*=.9;a.vy-=26*dt;a.jt=(a.jt||0)-dt;if(wet&&a.jt<=0)a.vy=Math.min(1.5,a.vy+40*dt);a.vy=Math.max(a.vy,-28);
const vx=(a.dir==null?0:Math.sin(a.dir)*(a.fol?1.9:1.1))+a.kx,vz=(a.dir==null?0:Math.cos(a.dir)*(a.fol?1.9:1.1))+a.kz;
mv(a,vx*dt,a.vy*dt,vz*dt);if(a.hx&&a.dir!=null){if(a.g)a.vy=8.6;else if(wet){a.vy=10.5;a.jt=.45}}
if(a.dir!=null)a.m.rotation.y=a.dir;a.m.position.set(a.x,a.y,a.z)}

// ---------- выпавшие предметы ----------
const drops=[],dcache=new Map();let dN=0;
function dMesh(id){let m=dcache.get(id);if(!m){m=B[id]&&id!=61&&id!=54?blockMesh(id):itemMesh(id);dcache.set(id,m)}return m.clone()}
function spawnDrop(id,x,y,z,vx,vz,k,wr,n){const m=dMesh(id);m.scale.setScalar(B[id]&&id!=61?.22:.55);scene.add(m);
const d={k,id,wr,n:n||1,x,y,z,vx,vy:3.2,vz,w:.25,h:.25,g:0,age:0,m};drops.push(d);if(drops.length>400)rmDrop(0);return d}
function dropStack(id,n,x,y,z,w){const k=myId+'-'+(++dN)+'-'+(Date.now()%1e6),vx=(Math.random()-.5)*2.4,vz=(Math.random()-.5)*2.4,d=spawnDrop(id,x,y,z,vx,vz,k,w,n);if(d)d.ttl=300;snd({t:'i',k,id,x,y,z,vx,vz,w,n,ttl:300})}
function dropItem(id,n,x,y,z,w){if(creative)return;for(let i=0;i<n;i++){const k=myId+'-'+(++dN)+'-'+(Date.now()%1e6),vx=(Math.random()-.5)*2.4,vz=(Math.random()-.5)*2.4;spawnDrop(id,x,y,z,vx,vz,k,w);snd({t:'i',k,id,x,y,z,vx,vz,w})}}
function throwItem(id,w){const k=myId+'-'+(++dN)+'-'+(Date.now()%1e6),fx=-Math.sin(p.yaw),fz=-Math.cos(p.yaw),x=p.x+fx*.5,y=p.y+1.3,z=p.z+fz*.5,vx=fx*4.5,vz=fz*4.5;
const d=spawnDrop(id,x,y,z,vx,vz,k,w);if(d)d.age=-1.2;snd({t:'i',k,id,x,y,z,vx,vz,w})}
let hovK=null;
function dropQ(){if(invOpen){if(cur){throwItem(cur.id,cur.w);if(!--cur.n)cur=null;ref()}else if(hovK&&hovK[0]=='i'){const s=inv[+hovK.slice(1)];if(s){throwItem(s.id,s.w);if(!--s.n)inv[+hovK.slice(1)]=null;ref()}}return}
const s=inv[sel];if(!s)return;throwItem(s.id,s.w);if(!--s.n)inv[sel]=null;ref()}
function rmDrop(i){const d=drops[i];scene.remove(d.m);drops.splice(i,1)}
const canTake=id=>(!TL[id]&&inv.some(a=>a&&a.id==id))||inv.includes(null);
function updDrops(dt,br){const cc=Math.max(.1,br);for(const m of dcache.values())m.material.color.setScalar(cc);
for(let i=drops.length-1;i>=0;i--){const d=drops[i];d.age+=dt;
if(d.age>(d.ttl||120)||d.y<-10||cell(d.x,d.y+.1,d.z)==8){rmDrop(i);continue}
const dx=p.x-d.x,dy=p.y+.6-d.y,dz=p.z-d.z,dist=Math.hypot(dx,dy,dz);
if(d.age>.5&&!slp&&!dd&&dist<2.2&&canTake(d.id)){const k=Math.min(1,dt*8);d.x+=dx*k;d.y+=dy*k;d.z+=dz*k;d.vy=0;
if(dist<.7){add(d.id,d.n||1,d.wr);snd({t:'ip',k:d.k});if(!sfx('pop',.5,.9+Math.random()*.4))tone(520,.07,'sine',.12,880);rmDrop(i);continue}}
else{d.vy=Math.max(d.vy-22*dt,-20);mv(d,d.vx*dt,d.vy*dt,d.vz*dt);if(d.g){d.vx*=.8;d.vz*=.8}}
d.m.visible=!(d.age>(d.ttl||120)-10&&((d.age*5)|0)%2);d.m.rotation.y+=dt*1.6;d.m.position.set(d.x,d.y+.3+Math.sin(performance.now()/350+d.age)*.06,d.z)}}

// ---------- рост травы, увядание листвы ----------
const nearLog=(x,y,z)=>{for(let i=-3;i<=3;i++)for(let k=-3;k<=3;k++)for(let j=-3;j<=3;j++)if(get(x+i,y+j,z+k)==5)return 1;return 0};
const decayQ=[];
function decayAround(x,y,z){for(let i=-5;i<=5;i++)for(let k=-5;k<=5;k++)for(let j=-5;j<=5;j++)if(get(x+i,y+j,z+k)==6&&!nearLog(x+i,y+j,z+k))decayQ.push({x:x+i,y:y+j,z:z+k,t:1+Math.random()*20})}
function decayTick(dt){for(let i=decayQ.length-1;i>=0;i--){const q=decayQ[i];if((q.t-=dt)>0)continue;decayQ.splice(i,1);if(get(q.x,q.y,q.z)==6&&!nearLog(q.x,q.y,q.z))pset(q.x,q.y,q.z,0,0)}}
function randTick(){if(!host())return;const pc=p.x>>4,pz=p.z>>4,Ls=[];for(let i=-RD;i<=RD;i++)for(let j=-RD;j<=RD;j++){const c=ch.get((pc+i)+','+(pz+j));if(c)Ls.push(c)}
for(let n=0;n<6&&Ls.length;n++){const c=Ls[Math.random()*Ls.length|0];
for(let sm2=0;sm2<16;sm2++){const lx=Math.random()*16|0,lz=Math.random()*16|0,x=c.cx*16+lx,z=c.cz*16+lz,t=c.h[lz*16+lx],b=c.D[(t*16+lz)*16+lx];
if(b==2){const up=get(x,t+1,z);if((up==0||up==52)&&HD.some(d=>[-1,0,1].some(dy=>get(x+d[0],t+dy,z+d[1])==1))&&Math.random()<.5)pset(x,t,z,1,0)}
else if(b==6){if(!nearLog(x,t,z)&&Math.random()<.5)pset(x,t,z,0,0)}}}}

// ---------- пшеница, кормление и размножение ----------
const BT=180,hearts=[],heartTex=(()=>{const c=document.createElement('canvas');c.width=c.height=16;const g=c.getContext('2d');
['.XX..XX.','XXXXXXXX','XXXXXXXX','.XXXXXX.','..XXXX..','...XX...'].forEach((r,y)=>[...r].forEach((q,x)=>{if(q=='X'){g.fillStyle=y==1&&x<3?'#ff8aa0':'#e8284a';g.fillRect(x*2,y*2+2,2,2)}}));
const t=new THREE.CanvasTexture(c);t.magFilter=t.minFilter=THREE.NearestFilter;t.generateMipmaps=false;return t})();
function heart(x,y,z){const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:heartTex,transparent:true}));sp.scale.set(.3,.3,1);sp.position.set(x+(Math.random()-.5)*.5,y,z+(Math.random()-.5)*.5);scene.add(sp);hearts.push({s:sp,l:1.2})}
function updHearts(dt){for(let i=hearts.length-1;i>=0;i--){const h=hearts[i];h.l-=dt;h.s.position.y+=dt*.8;h.s.material.opacity=Math.min(1,h.l*2);if(h.l<=0){scene.remove(h.s);h.s.material.dispose();hearts.splice(i,1)}}}
function sizeA(a){const f=a.age==null?1:+(.5+.1*Math.min(5,Math.floor(a.age/(BT/5)))).toFixed(1);if(a.f!==f){a.f=f;a.m.scale.setScalar(a.s*f);a.w=.7*a.s*f;a.h=.9*a.s*f}}
function feed(a){if(a.age==null){if(a.love>0)return toast('Уже накормлено');if(a.cd>0)return toast('Пока не хочет')}
take(46,1);asound(a.kind,0);for(let i=0;i<3;i++)heart(a.x,a.y+a.h+.2,a.z);
if(host()){if(a.age!=null)a.age+=BT*.1;else a.love=30}else snd({t:'f',k:a.k})}
function breed(dt){ // только хост: таймеры, сближение, поцелуй и рождение детёныша
for(const a of an){if(a.love>0)a.love-=dt;if(a.cd>0)a.cd-=dt;if(a.age!=null){a.age+=dt;if(a.age>=BT)a.age=null;sizeA(a)}}
for(const a of an){if(!(a.love>0)||a.age!=null)continue;let b=null,bd=10;
for(const o of an)if(o!==a&&o.kind==a.kind&&o.love>0&&o.age==null){const d=Math.hypot(o.x-a.x,o.z-a.z);if(d<bd){bd=d;b=o}}
if(!b){a.kiss=0;continue}
if(bd>1.3){a.dir=Math.atan2(b.x-a.x,b.z-a.z);a.t=.4;a.kiss=0;continue}
a.dir=null;a.t=.3;a.kiss=(a.kiss||0)+dt;
if(a.kiss>1.5&&b.kiss>1.5){const pc=Math.random()<.5?a.col:b.col;
animal(a.kind,(a.x+b.x)/2-.5,Math.max(a.y,b.y),(a.z+b.z)/2-.5,'b'+Date.now().toString(36)+(Math.random()*1e4|0),[.3,.68,.85,.99][pc]);
const c=an[an.length-1];c.age=0;c.hp=3;sizeA(c);for(let i=0;i<8;i++)heart(c.x,c.y+.6,c.z);asound(a.kind,0);
a.love=b.love=0;a.cd=b.cd=60;a.kiss=b.kiss=0}}}
function growCrops(){if(!host())return;for(const k of crops){const[x,y,z]=k.split(',').map(Number);if(!ch.has((x>>4)+','+(z>>4)))continue;
if(get(x,y,z)!=51){crops.delete(k);continue}if(get(x,y-1,z)!=50){pset(x,y,z,0,0);continue}
const st=fget(x,y,z)&3;if(st<3&&Math.random()<1/80)pset(x,y,z,51,st+1)}} // ~80 с на стадию, 3 стадии ≈ игровые сутки (240 с)

// ---------- мультиплеер и модель игрока ----------
let started=0,ws=null,spr=Math.random,view=0,nT=0,currentSkin='';try{currentSkin=JSON.parse(localStorage.getItem('mc_skin'))||''}catch{}const rp=new Map(),edits=[];
const snd=m=>{if(ws&&ws.readyState==1)ws.send(JSON.stringify(m))},dead=new Set(),host=()=>!ws||myId<=Math.min(myId,...rp.keys()),net=(x,y,z,b,f=8)=>{if(ws)snd({t:'b',x,y,z,b,f});else edits.push([x,y,z,b,f])};
const pset=(x,y,z,b,f)=>{setB(x,y,z,b,f);net(x,y,z,b,f)};
const sps=(u,v,w,h,d,ou,ov,f0=0,f1=1,x={})=>({u,v,w,h,d,ou,ov,f0,f1,...x}),ARM_R=[40,16,40,32,{}],ARM_L=[32,48,48,48,{L:1,lu:40,lv:16}];
function person(col,name){const g=new THREE.Group(),mt=c=>{const m=new THREE.MeshBasicMaterial({color:c});m.userData.b=new THREE.Color(c);return m},
bx=(P,w,h,d,X,Y,Z,c,sp)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mt(c));m.position.set(X,Y,Z);if(sp)m.userData.sp=sp;P.add(m);return m},
pv=(P,x,y,z)=>{const q=new THREE.Group();q.position.set(x,y,z);P.add(q);return q},SK=0xf0c090,HR=0x4a2f1a,D={dc:1};
const bd=pv(g,0,.7,0);bx(bd,.5,.7,.25,0,.35,0,col,sps(16,16,8,12,4,16,32));
const hd=pv(bd,0,.7,0);bx(hd,.4,.4,.4,0,.2,0,SK,sps(0,0,8,8,8,32,0));bx(hd,.42,.12,.42,0,.36,0,HR,D);bx(hd,.42,.3,.04,0,.22,-.19,HR,D);
for(const e of[-1,1]){bx(hd,.1,.08,.02,e*.1,.23,.205,0xffffff,D);bx(hd,.05,.08,.02,e*.09,.23,.215,0x2a4a9a,D)}bx(hd,.12,.03,.02,0,.1,.205,0x8a4a3a,D);
// al (x<0) = правая рука игрока (в ней предмет), ar = левая
const al=pv(bd,-.36,.7,0),ar=pv(bd,.36,.7,0);for(const[a,A]of[[al,ARM_R],[ar,ARM_L]]){bx(a,.2,.5,.2,0,-.25,0,col,sps(A[0],A[1],4,12,4,A[2],A[3],0,5/7,A[4]));bx(a,.2,.2,.2,0,-.6,0,SK,sps(A[0],A[1],4,12,4,A[2],A[3],5/7,1,A[4]))}
const ll=pv(g,-.13,.7,0),lr=pv(g,.13,.7,0);bx(ll,.22,.7,.22,0,-.35,0,0x3b3b8a,sps(0,16,4,12,4,0,32));bx(lr,.22,.7,.22,0,-.35,0,0x3b3b8a,sps(16,48,4,12,4,0,48,0,1,{L:1,lu:0,lv:16}));
g.userData={arm:[al,ar],leg:[ll,lr],hd,bd};
if(name){const c=document.createElement('canvas');c.width=256;c.height=48;const x=c.getContext('2d');x.font='bold 30px sans-serif';x.textAlign='center';x.fillStyle='#0006';x.fillRect(0,0,256,48);x.fillStyle='#fff';x.fillText(name,128,35);
const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),depthTest:false}));s.scale.set(2,.38,1);s.position.y=2.2;g.add(s);g.userData.nt=s}
scene.add(g);return g}
// анимация: ходьба, прыжок (в воздухе), взмах рукой, наклон головы, дыхание
function anim(g,sp,dt,air,sw,pi,sn){const u=g.userData;u.ph=(u.ph||0)+sp*dt*(u.q?5:2.4);const k=Math.min(1,sp/(u.q?1.2:3)),w=Math.sin(u.ph)*k;if(g===me&&ridingBoat){const[al,ar]=u.arm,[ll,lr]=u.leg;u.bd.rotation.set(0,0,0);u.bd.position.y=.7;u.sn=0;
// сидим: ноги вытянуты вперёд, руки на вёслах и гребут в такт скорости лодки
ll.rotation.set(-1.25,.12,0);lr.rotation.set(-1.25,-.12,0);
const rw=Math.sin(u.ph)*Math.min(1,sp/2.5);al.rotation.set(-.95+rw*.45,0,-.12);ar.rotation.set(-.95-rw*.45,0,.12);
if(sw>0)al.rotation.x=-Math.sin((1-sw/.3)*Math.PI)*1.6-.3;
// голова: сначала поворот (Y), потом наклон (X) в локальных осях головы
u.hd.rotation.order='YXZ';u.hd.rotation.x=-(pi||0);return}
if(u.q){u.q.forEach((l,i)=>l.rotation.x=(i==0||i==3?w:-w)*.8);return}
u.sn=(u.sn||0)+((sn?1:0)-(u.sn||0))*Math.min(1,dt*12);u.bd.rotation.x=.5*u.sn;u.bd.position.y=.7-.12*u.sn;if(u.nt)u.nt.position.y=2.2-.35*u.sn;
const[al,ar]=u.arm,[ll,lr]=u.leg,b=Math.sin(performance.now()/600)*.03;
if(air){ll.rotation.x=-.45;lr.rotation.x=.45;al.rotation.set(0,0,-.55);ar.rotation.set(0,0,.55)}
else{ll.rotation.x=w*.9;lr.rotation.x=-w*.9;ll.rotation.z=0;lr.rotation.z=0;u.bd.position.y=.7;u.bd.rotation.x=.5*u.sn;al.rotation.set(-w*.9,0,-(.04+b)*(1-k));ar.rotation.set(w*.9,0,(.04+b)*(1-k))}
if(sw>0)al.rotation.x=-Math.sin((1-sw/.3)*Math.PI)*1.6-.3;
if(pi!=null)u.hd.rotation.x=-pi-u.bd.rotation.x}
// броня на модели: накладные боксы на тело, голову, руки, ноги (ids: ботинки, штаны, тело, шлем)
function setArmor(g,ids){const u=g.userData;(u.ao||[]).forEach(m=>{m.parent.remove(m);m.geometry.dispose();m.material.dispose()});u.ao=[];
const A=(P,i,w,h,d,X,Y,Z)=>{const id=ids[i];if(!id)return;const c=[0x9a5a2a,0xd0d0d0,0x33d6cc][(id-80)>>2],mm=new THREE.MeshBasicMaterial({color:c});mm.userData.b=new THREE.Color(c);const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mm);m.position.set(X,Y,Z);P.add(m);u.ao.push(m)};
const[al,ar]=u.arm,[ll,lr]=u.leg;
A(u.bd,2,.54,.72,.29,0,.35,0);for(const a of[al,ar])A(a,2,.25,.2,.25,0,-.08,0);
for(const l of[ll,lr]){A(l,1,.27,.5,.27,0,-.25,0);A(l,0,.27,.22,.33,0,-.59,.03)}
A(u.hd,3,.46,.16,.46,0,.33,0);A(u.hd,3,.46,.3,.05,0,.2,-.21);A(u.hd,3,.05,.3,.4,-.21,.2,0);A(u.hd,3,.05,.3,.4,.21,.2,0);A(u.hd,3,.46,.06,.05,0,.31,.21)}
const upArm=(g,ids)=>{const k=ids.join();if(g.userData.as!==k){g.userData.as=k;setArmor(g,ids)}};
const me=person(0x3a86ff);me.visible=false;
const myHeldG=new THREE.Group();me.userData.arm[0].add(myHeldG);const myHeldL=new THREE.Group();me.userData.arm[1].add(myHeldL);let myHeldId=-1,myHeldLId=-1;
// предмет в руке (вид от третьего лица): перед кистью правой руки, плоский предмет развёрнут вдоль взгляда
function holdObj(G,id){G.clear();if(!id)return;const blk=B[id]&&id!=61&&id!=54,ob=blk?blockMesh(id):itemMesh(id);
if(blk){ob.scale.setScalar(.32);G.position.set(0,-.64,.24);G.rotation.set(0,.6,0)}else{ob.scale.setScalar(.55);G.position.set(0,-.66,.24);G.rotation.set(-.35,-Math.PI/2,0)}G.add(ob)}
function syncMyHeld(){const id=held(),o=oh[0]?oh[0].id:0;if(id!==myHeldId){myHeldId=id;holdObj(myHeldG,id)}if(o!==myHeldLId){myHeldLId=o;holdObj(myHeldL,o)}}
// ---------- скины: библиотека, раскладка Minecraft 64x64 (и старые 64x32), слой одежды, рука от первого лица ----------
const skinLib=(()=>{try{return JSON.parse(localStorage.getItem('mc_skinlib'))||{}}catch{return{}}})(),skinTexC=new Map(),meR={g:me,skin:'',sd:''};
let currentSkinData=currentSkin&&skinLib[currentSkin]||'',srvBase=location.protocol.startsWith('http')?location.origin:'http://localhost:3000';
const saveLib=()=>{try{localStorage.setItem('mc_skinlib',JSON.stringify(skinLib))}catch(e){toast('Память браузера переполнена')}};
function urlToData(u){return fetch(u,{cache:'no-store'}).then(r=>{if(!r.ok)throw 0;return r.blob()}).then(b=>new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>fr.result.startsWith('data:image/png')?res(fr.result):rej(0);fr.onerror=rej;fr.readAsDataURL(b)}))}
function skinTex(d){let p=skinTexC.get(d);if(!p){p=new Promise((res,rej)=>{const im=new Image();im.onload=()=>{const t=new THREE.Texture(im);t.magFilter=t.minFilter=THREE.NearestFilter;t.generateMipmaps=false;t.needsUpdate=true;res({t,leg:im.height*2<=im.width})};im.onerror=rej;im.src=d});skinTexC.set(d,p)}return p}
function skinUV(geo,sp,ov,leg){const{w,h,d}=sp,fl=!ov&&sp.L&&leg,u=ov?sp.ou:fl?sp.lu:sp.u,v=ov?sp.ov:fl?sp.lv:sp.v,TH=leg?32:64,y1=v+d,y2=v+d+h,ys=y1+(y2-y1)*sp.f0,ye=y1+(y2-y1)*sp.f1,
R={px:[u+d+w,ys,u+2*d+w,ye],nx:[u,ys,u+d,ye],pz:[u+d,ys,u+d+w,ye],nz:[u+2*d+w,ys,u+2*d+2*w,ye],py:[u+d,v,u+d+w,v+d],ny:[u+d+w,v,u+2*d+w,v+d]},
N=fl?['nx','px','py','ny','pz','nz']:['px','nx','py','ny','pz','nz'],a=geo.attributes.uv;
for(let f=0;f<6;f++){const r=R[N[f]];for(let j=0;j<4;j++){const i=f*4+j,U=a.getX(i),V=a.getY(i);a.setXY(i,(r[0]+(fl?1-U:U)*(r[2]-r[0]))/64,1-(r[1]+(1-V)*(r[3]-r[1]))/TH)}}a.needsUpdate=true}
function clearSkin(g){const u=g.userData;(u.ov||[]).forEach(m=>{if(m.parent)m.parent.remove(m);m.geometry.dispose()});u.ov=[];(u.skM||[]).forEach(m=>m.dispose());u.skM=[];
g.traverse(o=>{if(!o.isMesh)return;if(o.userData.m0){o.material=o.userData.m0;o.geometry.attributes.uv.array.set(o.userData.uv0);o.geometry.attributes.uv.needsUpdate=true}if(o.userData.sp&&o.userData.sp.dc)o.visible=true});if(g===me)handClear()}
function applyPlayerSkin(r,name,data){r.skin=name||'';r.sd=data||'';const g=r.g;if(!g)return;clearSkin(g);if(!name||!data)return;
skinTex(data).then(({t,leg})=>{if(r.skin!==name||r.sd!==data)return;clearSkin(g);const u=g.userData,mb=new THREE.MeshBasicMaterial({map:t}),mo=new THREE.MeshBasicMaterial({map:t,transparent:true,alphaTest:.1}),add=[];
mb.userData.b=new THREE.Color(1,1,1);mo.userData.b=new THREE.Color(1,1,1);u.skM=[mb,mo];
g.traverse(o=>{const s=o.isMesh&&o.userData.sp;if(!s)return;if(s.dc){o.visible=false;return}
if(!o.userData.m0){o.userData.m0=o.material;o.userData.uv0=o.geometry.attributes.uv.array.slice()}
skinUV(o.geometry,s,0,leg);o.material=mb;
if(!leg||(s.ou==32&&s.ov==0)){const P=o.geometry.parameters,og=new THREE.BoxGeometry(P.width*1.05,P.height*1.02,P.depth*1.05);skinUV(og,s,1,leg);const m=new THREE.Mesh(og,mo);m.position.copy(o.position);add.push([o.parent,m])}});
add.forEach(([P,m])=>{P.add(m);u.ov.push(m)});if(g===me)handSkin(t,leg)}).catch(()=>console.warn('Не удалось прочитать скин '+name))}
// чужой скин: данные приходят по сети; если их нет (слишком большой файл) — берём с сервера
function setRemoteSkin(r,name,data){r.want=name;if(!name||data)return applyPlayerSkin(r,name,data);r.skin=name;urlToData(srvBase+'/skins/'+encodeURIComponent(name)).then(d=>{if(r.want===name)applyPlayerSkin(r,name,d)}).catch(()=>{})}
const sendSkin=()=>snd({t:'skin',skin:currentSkin,data:currentSkinData&&currentSkinData.length<400000?currentSkinData:''});
async function equipSkin(n){let d='';try{d=await urlToData(srvBase+'/skins/'+encodeURIComponent(n))}catch{}if(!d)d=skinLib[n]||'';if(!d)return toast('Не удалось загрузить скин');
skinLib[n]=d;saveLib();currentSkin=n;currentSkinData=d;LS('skin',n);applyPlayerSkin(meR,n,d);sendSkin();loadSkinList();toast('Скин экипирован: '+n.replace(/\.png$/i,''))}
function addP(q){const g=person(0xd9534f,q.name);g.position.set(q.x,q.y,q.z);
const heldG=new THREE.Group(),heldL=new THREE.Group();g.userData.arm[0].add(heldG);g.userData.arm[1].add(heldL);
rp.set(q.id,{name:q.name,g,tx:new THREE.Vector3(q.x,q.y,q.z),yaw:q.yaw,heldG,heldL,heldId:0,heldLId:0,skin:'',h:q.h||0,o:q.o||0});const r=rp.get(q.id);if(q.skin)setRemoteSkin(r,q.skin,q.sd||'');if(r.h)syncHeldObject(r,r.h);if(r.o){r.heldLId=r.o;holdObj(r.heldL,r.o)}}
function syncHeldObject(r,id){if(!r||!r.heldG)return;r.heldId=id||0;holdObj(r.heldG,r.heldId)}
// ---------- список игроков (Tab) ----------
let pingMap={};const faceImgs=new Map(),tabEl=document.createElement('div');
tabEl.style.cssText='position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:20;min-width:300px;max-width:92vw;background:rgba(0,0,0,.55);padding:8px 10px;display:none;pointer-events:none;font:14px/1.2 sans-serif;color:#fff;border-radius:4px;text-shadow:1px 1px #000';document.body.appendChild(tabEl);
function faceCv(data){const cv=document.createElement('canvas');cv.width=cv.height=24;cv.style.cssText='width:24px;height:24px;image-rendering:pixelated;flex:none';const c=cv.getContext('2d');c.imageSmoothingEnabled=false;
const draw=im=>{c.clearRect(0,0,24,24);c.drawImage(im,8,8,8,8,0,0,24,24);if(im.height>=64||im.width>=im.height*2&&im.height>=32)c.drawImage(im,40,8,8,8,0,0,24,24)};
if(!data){c.fillStyle='#f0c090';c.fillRect(0,0,24,24);c.fillStyle='#4a2f1a';c.fillRect(0,0,24,7);c.fillStyle='#fff';c.fillRect(4,10,6,4);c.fillRect(14,10,6,4);c.fillStyle='#2a4a9a';c.fillRect(7,10,3,4);c.fillRect(14,10,3,4);return cv}
let im=faceImgs.get(data);if(!im){im=new Image();im.src=data;faceImgs.set(data,im)}if(im.complete&&im.naturalWidth)draw(im);else im.addEventListener('load',()=>draw(im));return cv}
function renderTab(){const rows=[{n:myName||'Игрок',sd:currentSkinData,ping:ws?(pingMap[myId]??null):0,me:1},...[...rp].map(([id,r])=>({n:r.name,sd:r.sd||'',ping:pingMap[id]??null}))];
tabEl.innerHTML='';const h=document.createElement('div');h.textContent='Игроки: '+rows.length;h.style.cssText='text-align:center;margin-bottom:6px;color:#ddd';tabEl.append(h);
rows.forEach(p=>{const row=document.createElement('div');row.style.cssText='display:flex;align-items:center;gap:8px;padding:3px 4px;background:rgba(255,255,255,'+(p.me?.14:.06)+');margin:2px 0';
const nm=document.createElement('span');nm.textContent=p.n;nm.style.cssText='flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
const pg=document.createElement('span'),v=p.ping;pg.textContent=v==null?'—':v+' мс';pg.style.cssText='min-width:56px;text-align:right;font-weight:bold;color:'+(v==null?'#aaa':v<80?'#55ff55':v<160?'#ffff55':v<300?'#ffaa00':'#ff5555');
row.append(faceCv(p.sd),nm,pg);tabEl.append(row)})}
let tabT=0;const tabHide=()=>{tabEl.style.display='none';clearInterval(tabT);tabT=0};
addEventListener('keydown',e=>{if(kcode(e.code)!='Tab')return;if(e.target.tagName=='INPUT')return;if(!started||mo())return;e.preventDefault();if(e.repeat||tabT)return;renderTab();tabEl.style.display='block';tabT=setInterval(renderTab,500)});
addEventListener('keyup',e=>{if(kcode(e.code)=='Tab')tabHide()});addEventListener('blur',tabHide);
function onMsg(m){
if(m.t=='pg'){snd(m);return}if(m.t=='pings'){pingMap=m.p||{};return}
if(m.t=='init'){seed=m.seed;myId=m.id;diff=m.df||3;wt=m.wt||'normal';tm=m.tm||0;m.dead.forEach(k=>dead.add(k));for(const e of m.edits)edits.push(e);(m.chests||[]).forEach(([k,a])=>chests.set(k,a));m.players.forEach(addP);startGame(loadMP);toast('Подключено! Кликни по экрану');if(m.v!==2)setTimeout(()=>lg('Сервер старый: замени server.js и перезапусти server.bat, иначе скины не видны другим','#f55'),2500)}
else if(m.t=='join'){addP(m.p);lg(m.p.name+' присоединился','#ff0')}
else if(m.t=='skin'){const r=rp.get(m.id);if(r)setRemoteSkin(r,m.skin||'',m.data||'')}
else if(m.t=='boat'){if(m.a==='place')makeBoat(m.x,m.y,m.z,m.yaw||0);else if(m.a==='remove'){const b=boats.find(q=>Math.hypot(q.position.x-m.x,q.position.z-m.z)<1);if(b){if(ridingBoat===b)unseat();scene.remove(b);boats.splice(boats.indexOf(b),1)}}}
else if(m.t=='p'){const r=rp.get(m.id);if(r){r.tx.set(m.x,m.y,m.z);r.yaw=m.yaw;r.h=m.h;r.o=m.o;r.ar=m.ar;r.pt=m.pt;r.sn=m.sn;
if(r.heldId!==(m.h||0))syncHeldObject(r,m.h||0);if(r.heldLId!==(m.o||0)){r.heldLId=m.o||0;holdObj(r.heldL,r.heldLId)}r.h=m.h||0;r.o=m.o||0;
if(m.s&&!(r.swT>0))r.swT=.3}}
else if(m.t=='b'){if(!m.b&&Math.hypot(m.x-p.x,m.z-p.z)<64){const ob=get(m.x,m.y,m.z);if(ob)blockFx(ob,m.x,m.y,m.z,26)}edits.push([m.x,m.y,m.z,m.b,m.f]);setB(m.x,m.y,m.z,m.b,m.f)}
else if(m.t=='m'){setRCrack(m.id,m.x,m.y,m.z,m.s);if(m.s>0&&Math.hypot(m.x-p.x,m.z-p.z)<48){const ob=get(m.x,m.y,m.z);if(ob)blockFx(ob,m.x,m.y,m.z,4,1)}}else if(m.t=='leave'){setRCrack(m.id,0,0,0,0);const r=rp.get(m.id);if(r){lg(r.name+' вышел','#ff0');scene.remove(r.g);rp.delete(m.id)}}else if(m.t=='c')lg('<'+m.n+'> '+m.m,'#ff0');else if(m.t=='tm')tm=m.v;else if(m.t=='a')m.a.forEach(q=>{let a=an.find(a=>a.k==q[0]);
if(!a&&q[7]>=0&&!dead.has(q[0])&&ch.has((Math.floor(q[1])>>4)+','+(Math.floor(q[3])>>4))){animal(q[5],q[1]-.5,q[2],q[3]-.5,q[0],[.3,.68,.85,.99][q[6]]||.3);a=an[an.length-1];a.hp=3;for(let i=0;i<5;i++)heart(q[1],q[2]+.6,q[3])}
if(a){a.nx=q[1];a.ny=q[2];a.nz=q[3];a.ry=q[4];a.age=q[7]>=0?q[7]:null;a.love=q[8]?30:0;sizeA(a)}});
else if(m.t=='f'){if(host()){const a=an.find(a=>a.k==m.k);if(a){if(a.age!=null)a.age+=BT*.1;else if(!(a.love>0)&&!(a.cd>0))a.love=30}}}else if(m.t=='i'){const d=spawnDrop(m.id,m.x,m.y,m.z,m.vx,m.vz,m.k,m.w,m.n);if(d&&m.ttl)d.ttl=m.ttl}else if(m.t=='k'){if(Array.isArray(m.s))setChest(m.k,m.s);else chests.delete(m.k)}else if(m.t=='ip'){const i=drops.findIndex(d=>d.k==m.k);if(i>=0)rmDrop(i)}else if(m.t=='mo'){if(!host()){const seen=new Set();for(const q of m.a){seen.add(q[0]);let a=mobs.find(a=>a.id==q[0]);if(!a){if(!ch.has((Math.floor(q[2])>>4)+','+(Math.floor(q[4])>>4)))continue;a=newMob(q[1],q[2],q[3],q[4],q[0])}if(q[6]<a.hp-.01){a.m.userData.fl=1;msnd(a.type,1,q[2],q[3],q[4])}a.hp=q[6];a.nx=q[2];a.ny=q[3];a.nz=q[4];a.ry=q[5];a.aim=q[7]}for(let i=mobs.length-1;i>=0;i--)if(!seen.has(mobs[i].id))rmMob(i)}}
else if(m.t=='mh'){if(host()){const a=mobs.find(a=>a.id==m.id);if(a)damageMob(a,Math.min(20,+m.d||0),+m.kx||0,+m.kz||0)}}
else if(m.t=='ar'){fireArrow(m.x,m.y,m.z,m.vx,m.vy,m.vz,'r',0,0)}
else if(m.t=='dm'){if(m.to==myId)harmPlayer(Math.min(20,+m.d||0),+m.fx||0,+m.fz||0)}
else if(m.t=='z'){m.v?sleepers.add(m.id):sleepers.delete(m.id)}else if(m.t=='d'){const a=an.find(a=>a.k==m.k);if(a){a.hp=m.hp;a.m.userData.fl=1;a.kx=m.kx;a.kz=m.kz;a.vy=4;if(m.hp<=0){scene.remove(a.m);an.splice(an.indexOf(a),1)}}if(m.hp<=0)dead.add(m.k)}}
// Индикатор дыхания под сердцами: 10 пузырьков, урон после их исчезновения.
const breathUI=document.createElement('div');breathUI.id='breath';breathUI.style.cssText='display:none;text-align:center;font-size:21px;letter-spacing:1px;text-shadow:1px 1px #222;line-height:22px';
$('hud').prepend(breathUI);let air=10,airTick=0,drownTick=0;
function updateAir(dt){const underwater=cell(p.x,p.y+1.45,p.z)==7;if(!underwater){air=10;airTick=0;drownTick=0;breathUI.style.display='none';return}
breathUI.style.display='block';airTick+=dt;if(airTick>=1){airTick-=1;if(air>0)air--;else{drownTick+=1;if(drownTick>=1){drownTick=0;if(!cheat.god){p.hp-=2;if(p.hp<=0&&!dd)die()}}}}
breathUI.textContent='🫧'.repeat(air)+'○'.repeat(10-air);breathUI.style.color=air<=3?'#ff7777':'#fff'}
const boats=[];let ridingBoat=null;
// посадка: насколько опускаем модель игрока и сдвигаем её назад от центра лодки
const SEAT_DROP=.58,SEAT_Z=.15;
function unseat(){const u=me.userData;if(ridingBoat){ridingBoat.userData.vx=ridingBoat.userData.vz=0;ridingBoat=null}u.leg.forEach(l=>l.rotation.set(0,0,0));u.arm.forEach(a=>a.rotation.set(0,0,0));u.bd.position.y=.7;u.bd.rotation.set(0,0,0);u.hd.rotation.set(0,0,0)}
function makeBoat(x,y,z,yaw=0){const g=new THREE.Group();const colors=[0x9b6938,0xb1814a,0x805128,0xc19458,0x6d4728],mats=colors.map(color=>new THREE.MeshBasicMaterial({color}));const plank=(w,h,d,px,py,pz,mi=0)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mats[mi%mats.length]);m.position.set(px,py,pz);g.add(m)};for(let i=-3;i<=3;i++)plank(.78,.12,.16,0,.015,i*.16,(i+3)%5);for(let i=0;i<7;i++){const zz=-.48+i*.16;plank(.13,.2,.15,-.38,.12,zz,i%3);plank(.13,.2,.15,.38,.12,zz,(i+2)%5)}plank(.78,.14,.14,0,.12,-.51,3);plank(.78,.14,.14,0,.12,.51,1);plank(.14,.18,1.02,-.38,.12,0,0);plank(.14,.18,1.02,.38,.12,0,2);plank(.84,.05,.055,0,.235,-.51,3);plank(.84,.05,.055,0,.235,.51,3);plank(.055,.05,1.02,-.38,.235,0,3);plank(.055,.05,1.02,.38,.235,0,3);g.position.set(x,y,z);g.rotation.order='YXZ';g.rotation.y=yaw;g.userData={hits:0,vy:0,water:false};scene.add(g);return g}
function updateBoats(dt,now){for(const b of boats){const u=b.userData,bx=Math.floor(b.position.x),bz=Math.floor(b.position.z);let wy=-1,support=-1;for(let y=Math.min(H-1,Math.floor(b.position.y+1.2));y>=Math.max(0,Math.floor(b.position.y)-3);y--){const id=get(bx,y,bz);if(id==7||id==8){wy=y+1;break}if(id&&id!=6&&id!=51&&id!=52&&id!=61){support=y+1;break}}if(wy>=0){u.water=true;u.vy=0;const target=wy-.05;b.position.y+=(target-b.position.y)*Math.min(1,dt*8);b.rotation.z=Math.sin(now*.002+b.position.x)*.012;b.rotation.x=Math.cos(now*.0018+b.position.z)*.008}else{u.water=false;b.rotation.z*=Math.max(0,1-dt*3);b.rotation.x*=Math.max(0,1-dt*3);u.vy=(u.vy||0)-18*dt;const target=support>=0?support-.18:-20;b.position.y=Math.max(target,b.position.y+u.vy*dt);if(b.position.y<=target){b.position.y=target;u.vy=0}}if(ridingBoat===b){p.x=b.position.x;p.z=b.position.z;p.y=b.position.y+.08;p.vy=0;me.position.set(p.x,p.y,p.z);me.rotation.y=b.rotation.y+Math.PI}}}
function syncBoat(m){if(ws&&ws.readyState===1)ws.send(JSON.stringify(m))}
function startGame(f){if(started)return;started=1;M.style.display='none';M.classList.add('pz');spr=rng(seed);spawn();if(f)f();ref();hud();requestAnimationFrame(frame)}
// ---------- Beta 1.0: враждебные мобы, лук и стрелы, смерть, сложность ----------
const dfc=()=>ws&&diff>4?4:diff;   // в мультиплеере «Эксперт» работает как «Сложная» (без удаления мира)
const MCAP=[0,0,7,10,13,15],DMGZ=[0,0,2,3,5,5],DMGA=[0,0,2,3,4,4],ASPR=[0,0,.14,.09,.05,.04],ACD=[0,0,2.6,2,1.6,1.4],GA=14,BO=[[0,1],[0,-1],[1,0],[-1,0],[1,1],[-1,-1],[1,-1],[-1,1],[2,0],[-2,0],[0,2],[0,-2]];
let TGL=[],mobSent=0,rpp=null,rpm=0,spawnProt=0;
function msnd(t,k,x=p.x,y=p.y,z=p.z){ // Звук моба с затуханием по расстоянию
const dist=Math.hypot((x??p.x)-p.x,(y??p.y)-p.y,(z??p.z)-p.z);if(dist>28)return;const att=Math.max(0,1-dist/28);const vol=att*att; if(vol<.015)return;
const n=(t?'skeleton':'zombie')+(k==1?'_hurt':k==2?'_death':'');if(sfx(n,.8*vol,.95+Math.random()*.1))return;
if(t==0){if(k==0)tone(85,.7,'sawtooth',.1*vol,60);else if(k==1)tone(170,.22,'sawtooth',.16*vol,90);else tone(120,.6,'sawtooth',.16*vol,40)}
else{if(k==0)noise(.25,.12*vol,2500,'bandpass');else if(k==1){noise(.12,.25*vol,3000,'bandpass');tone(300,.1,'square',.06*vol,200)}else{noise(.4,.3*vol,2000,'bandpass');tone(200,.35,'square',.08*vol,70)}}}
function newMob(type,x,y,z,id){
const g=new THREE.Group(),mt=c=>{const m=new THREE.MeshBasicMaterial({color:c});m.userData.b=new THREE.Color(c);return m},
bx=(w,h,d,X,Y,Z,c,P=g)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mt(c));m.position.set(X,Y,Z);P.add(m);return m},
pv=(P,X,Y,Z)=>{const o=new THREE.Group();o.position.set(X,Y,Z);P.add(o);return o},
zb=type==0,SK=zb?0x5f9d4a:0xdadada,SH=zb?0x2f6fa8:0xc8c8c8,PN=zb?0x35358a:0xc0c0c0,aw=zb?.25:.13,lw=zb?.25:.15,bw=zb?.5:.4,bd=zb?.25:.2;
bx(bw,.75,bd,0,1.125,0,SH);if(!zb)for(const y of[.95,1.1,1.25,1.4])bx(bw+.02,.05,bd+.02,0,y,0,0x6e6e6e);
const hd=pv(g,0,1.5,0);bx(.5,.5,.5,0,.25,0,SK,hd);bx(.1,.1,.02,-.12,.3,.26,0x111111,hd);bx(.1,.1,.02,.12,.3,.26,0x111111,hd);
if(zb)bx(.22,.06,.02,0,.12,.26,0x2c4a22,hd);else bx(.18,.04,.02,0,.12,.26,0x333333,hd);
const al=pv(g,-(bw/2+aw/2),1.4,0),ar=pv(g,bw/2+aw/2,1.4,0);for(const a of[al,ar])bx(aw,.75,aw,0,-.325,0,SK,a);
const ll=pv(g,-.125,.75,0),lr=pv(g,.125,.75,0);for(const l of[ll,lr])bx(lw,.75,lw,0,-.375,0,PN,l);
if(!zb){const bo=pv(al,0,-.6,.12);bx(.04,.34,.05,0,0,.07,0x7a5a2a,bo);const u=bx(.04,.26,.05,0,.27,.02,0x7a5a2a,bo),w=bx(.04,.26,.05,0,-.27,.02,0x7a5a2a,bo);u.rotation.x=.5;w.rotation.x=-.5;bx(.012,.7,.012,0,0,-.03,0xeeeeee,bo)}
g.position.set(x,y,z);scene.add(g);
const a={id,type,m:g,hd,al,ar,ll,lr,x,y,z,vy:0,kx:0,kz:0,hp:20,w:.6,h:1.9,cd:1.5,t:0,dir:null,rot:Math.random()*6.28,aim:0,drawing:0,dT:0,sd:1,sdT:0,ph:0,los:1,lT:0,g:0,hx:0};mobs.push(a);return a}
function rmMob(i){const a=mobs[i];scene.remove(a.m);a.m.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.material)o.material.dispose()});mobs.splice(i,1)}
function animMob(a,sp,dt){const k=Math.min(1,sp/2.2);a.ph+=sp*dt*3.2;const w=Math.sin(a.ph)*k*.9;a.ll.rotation.x=w;a.lr.rotation.x=-w;
if(a.type==0){a.al.rotation.x=a.ar.rotation.x=-1.45+Math.sin(a.ph*.5)*.1*k}
else if(a.aim){a.al.rotation.x=-1.5;a.ar.rotation.x=-1.4;a.ar.rotation.y=.55}
else{a.al.rotation.x=-w*.8;a.ar.rotation.x=w*.8;a.ar.rotation.y=0}}
const nearMob=()=>mobs.some(a=>Math.hypot(a.x-p.x,a.z-p.z)<10&&Math.abs(a.y-p.y)<6);
function targets(){const L2=[];if(!dd&&!creative&&started)L2.push({x:p.x,y:p.y,z:p.z,id:myId,me:1});rp.forEach((r,id)=>L2.push({x:r.tx.x,y:r.tx.y,z:r.tx.z,id}));return L2}
function tgNear(a,R){let b=null,bd=R;for(const t of TGL){const d=Math.hypot(t.x-a.x,t.z-a.z);if(d<bd&&Math.abs(t.y-a.y)<14){bd=d;b={t,d}}}return b}
function los(x0,y0,z0,x1,y1,z1){const d=Math.hypot(x1-x0,y1-y0,z1-z0),n=Math.ceil(d/.5);for(let i=1;i<n;i++){const t=i/n;if(sol(Math.floor(x0+(x1-x0)*t),Math.floor(y0+(y1-y0)*t),Math.floor(z0+(z1-z0)*t)))return 0}return 1}
function hurtFx(){const e=$('hurt');e.style.transition='none';e.style.opacity=.45;void e.offsetWidth;e.style.transition='opacity .5s';e.style.opacity=0}
function harmPlayer(d,fx,fz){if(dd||creative||cheat.god||spawnProt>0||!d)return;p.hp-=d*aDef();kbx+=fx*9;kbz+=fz*9;if(p.g)p.vy=Math.max(p.vy,5);if(slp)wake();hurtFx()}
const harm=(t,d,fx,fz)=>{if(t.me)harmPlayer(d,fx,fz);else snd({t:'dm',to:t.id,d,fx,fz})};
function killMob(a){const D=(id,n,w)=>dropItem(id,n,a.x,a.y+.5,a.z,w);
if(a.type==0){const n=Math.random()*3|0;if(n)D(98,n);if(Math.random()<.04)D(71,1)}else{const n=Math.random()*3|0;if(n)D(97,n);if(Math.random()<.4)D(96,1,Math.random()*120|0)}
msnd(a.type,2,a.x,a.y,a.z);const i=mobs.indexOf(a);if(i>=0)rmMob(i)}
function damageMob(a,d,kx,kz){a.hp-=d;a.m.userData.fl=1;a.kx=kx;a.kz=kz;a.vy=Math.max(a.vy,4);msnd(a.type,1,a.x,a.y,a.z);if(a.hp<=0)killMob(a)}
function hitMob(a,d,kx,kz){if(host())damageMob(a,d,kx,kz);else{a.hp-=d;a.m.userData.fl=1;msnd(a.type,1,a.x,a.y,a.z);snd({t:'mh',id:a.id,d,kx,kz})}}
function aimM(){const d=new THREE.Vector3();camera.getWorldDirection(d);
for(let t=0;t<4;t+=.15){const x=camera.position.x+d.x*t,y=camera.position.y+d.y*t,z=camera.position.z+d.z*t;
for(const a of mobs)if(Math.abs(x-a.x)<a.w/2+.2&&Math.abs(z-a.z)<a.w/2+.2&&y>a.y-.1&&y<a.y+a.h+.1)return a}return null}
// --- стрелы ---
function fireArrow(x,y,z,vx,vy,vz,own,dmg,net=1){const g=new THREE.Group(),m=(w,h,d,Z,c)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshBasicMaterial({color:c}));o.position.z=Z;g.add(o)};
m(.035,.035,.55,0,0x8b6a3a);m(.07,.07,.1,.3,0x9a9a9a);m(.12,.02,.12,-.24,0xeeeeee);m(.02,.12,.12,-.24,0xeeeeee);g.position.set(x,y,z);g.lookAt(x+vx,y+vy,z+vz);scene.add(g);
arrs.push({m:g,x,y,z,vx,vy,vz,own,dmg,life:20,st:0});if(arrs.length>80)rmArr(0);
if(net)snd({t:'ar',x,y,z,vx,vy,vz});if(Math.hypot(x-p.x,z-p.z)<30&&!sfx('bow',.8,.95+Math.random()*.1)){noise(.12,.25,2500,'bandpass');tone(220,.1,'triangle',.12,120)}}
function rmArr(i){const a=arrs[i];scene.remove(a.m);a.m.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.material)o.material.dispose()});arrs.splice(i,1)}
function updArrows(dt){for(let i=arrs.length-1;i>=0;i--){const a=arrs[i];a.life-=dt;if(a.life<=0||a.y<-10){rmArr(i);continue}if(a.st)continue;
const n=3,h=dt/n;let r=0;
for(let s=0;s<n&&!r;s++){const ox=a.x,oy=a.y,oz=a.z;a.vy-=GA*h;a.x+=a.vx*h;a.y+=a.vy*h;a.z+=a.vz*h;
if(sol(Math.floor(a.x),Math.floor(a.y),Math.floor(a.z))){a.x=ox;a.y=oy;a.z=oz;a.st=1;a.life=Math.min(a.life,6);r=1;if(Math.hypot(a.x-p.x,a.z-p.z)<20)tone(160,.07,'square',.08,100);break}
if(a.dmg){const l=Math.hypot(a.vx,a.vz)||1;
if(a.own=='p'){for(const m of mobs)if(Math.abs(a.x-m.x)<.45&&Math.abs(a.z-m.z)<.45&&a.y>m.y-.1&&a.y<m.y+m.h+.1){hitMob(m,a.dmg,a.vx/l*5,a.vz/l*5);r=2;break}}
else for(const t of TGL)if(Math.abs(a.x-t.x)<.45&&Math.abs(a.z-t.z)<.45&&a.y>t.y-.1&&a.y<t.y+1.9){harm(t,a.dmg,a.vx/l,a.vz/l);r=2;break}}}
if(r==2){rmArr(i);continue}
a.m.position.set(a.x,a.y,a.z);if(!a.st)a.m.lookAt(a.x+a.vx,a.y+a.vy,a.z+a.vz)}}
// --- ИИ (считает хост, остальные получают позиции по сети) ---
function shootAt(a,t){const ox=a.x+Math.sin(a.rot)*.4,oy=a.y+1.45,oz=a.z+Math.cos(a.rot)*.4,sp=26,dx=t.x-ox,dy=t.y+1.3-oy,dz=t.z-oz,D=Math.hypot(dx,dy,dz)||1,T=D/sp,sr=ASPR[dfc()],r=()=>(Math.random()-.5)*2*sr*sp;
fireArrow(ox,oy,oz,dx/T+r(),dy/T+.5*GA*T+r(),dz/T+r(),'m',DMGA[dfc()])}
function updMobH(a,dt){if(!ch.get((Math.floor(a.x)>>4)+','+(Math.floor(a.z)>>4)))return 0;
const d=dfc(),wet=cell(a.x,a.y+.3,a.z)==7;a.kx*=.88;a.kz*=.88;a.vy-=26*dt;a.vy=Math.max(a.vy,-28);a.jt=(a.jt||0)-dt;if(wet&&a.jt<=0)a.vy=Math.min(1.5,a.vy+40*dt);
let vx=0,vz=0,mvg=0;a.cd-=dt;const r=tgNear(a,a.type?26:22);
if(r){const t=r.t,dx=t.x-a.x,dz=t.z-a.z,dist=r.d||1;a.rot=Math.atan2(dx,dz);a.dir=null;
if(a.type==0){const sp=2.4+(d>=4?.4:0);if(dist>.8){vx=dx/dist*sp;vz=dz/dist*sp;mvg=1}
if(dist<1.4&&Math.abs(t.y-a.y)<1.8&&a.cd<=0){a.cd=1;msnd(0,0,a.x,a.y,a.z);harm(t,DMGZ[d],dx/dist,dz/dist)}}
else{const sp=1.7;a.sdT-=dt;if(a.sdT<=0){a.sdT=1.2+Math.random()*2;a.sd=Math.random()<.5?-1:1}
a.lT-=dt;if(a.lT<=0){a.lT=.12;a.los=los(a.x,a.y+1.5,a.z,t.x,t.y+1.4,t.z)}
// Сккелет не должен целиться или стрелять сквозь блоки. При потере прямой видимости отменяем натяжение лука.
if(!a.los){a.drawing=0;a.dT=0;a.aim=0}
if(!a.los||dist>14){vx=dx/dist*sp;vz=dz/dist*sp;mvg=1}else if(dist<6){vx=-dx/dist*sp;vz=-dz/dist*sp;mvg=1}else{vx=-dz/dist*sp*.7*a.sd;vz=dx/dist*sp*.7*a.sd;mvg=1}
if(a.drawing&&a.los&&dist<20){a.dT+=dt;vx*=.25;vz*=.25;a.aim=1;if(a.dT>=.85){a.drawing=0;a.aim=0;if(los(a.x,a.y+1.5,a.z,t.x,t.y+1.4,t.z)){a.cd=ACD[d];shootAt(a,t)}else{a.cd=.25}}}
else{a.drawing=0;a.dT=0;a.aim=0;if(a.cd<=0&&a.los&&dist<20){a.drawing=1;a.dT=0}}}}
else{a.aim=0;a.drawing=0;a.t-=dt;if(a.t<=0){a.t=2+Math.random()*4;a.dir=Math.random()<.4?null:Math.random()*6.28}if(a.dir!=null){vx=Math.sin(a.dir);vz=Math.cos(a.dir);mvg=1;a.rot=a.dir}}
if(Math.random()<dt*.07)msnd(a.type,0,a.x,a.y,a.z);
if(DF>.55&&!wet&&lt(Math.floor(a.x),Math.floor(a.y+1.8),Math.floor(a.z))>=1){a.bt=(a.bt||0)+dt;a.m.userData.fl=Math.max(a.m.userData.fl||0,.25);if(a.bt>=.5){a.bt-=.5;a.hp-=1;if(a.hp<=0){killMob(a);return 1}}}
mv(a,(vx+a.kx)*dt,a.vy*dt,(vz+a.kz)*dt);if(a.hx&&mvg){if(a.g)a.vy=8.6;else if(wet){a.vy=10.5;a.jt=.45}}
a.m.rotation.y=a.rot;a.m.position.set(a.x,a.y,a.z);return 0}
function trySpawn(d){const cap=MCAP[d],tries=[0,0,2,3,4,5][d];
for(const t of TGL){let n=0;for(const a of mobs)if(Math.hypot(a.x-t.x,a.z-t.z)<48)n++;if(n>=cap||mobs.length>=40)continue;
for(let k=0;k<tries;k++){const ang=Math.random()*6.283,rr=14+Math.random()*14,x=Math.floor(t.x+Math.cos(ang)*rr),z=Math.floor(t.z+Math.sin(ang)*rr);if(!ch.get((x>>4)+','+(z>>4)))continue;
const lo=Math.max(3,Math.floor(t.y)-14),hi=Math.min(H-4,Math.floor(t.y)+14),C=[];
for(let y=hi;y>=lo;y--)if(!get(x,y,z)&&!get(x,y+1,z)&&sol(x,y-1,z)){const gb=get(x,y-1,z);if(gb!=6&&gb!=7&&gb!=8)C.push(y)}
if(!C.length)continue;const y=C[Math.random()*C.length|0];
const sk=lt(x,y+1,z)*DF,sv=BRU.value;BRU.value=0;const bl=lightAt(x+.5,y+.5,z+.5);BRU.value=sv;if(Math.max(sk,bl)>.3)continue;   // спавн только в темноте: ночью или в пещерах
if(TGL.some(q=>Math.hypot(q.x-x-.5,q.z-z-.5)<12&&Math.abs(q.y-y)<8))continue;
newMob(Math.random()<.62?0:1,x+.5,y,z+.5,'m'+myId+'-'+(++mobN));if(++n>=cap||mobs.length>=40)break}}}
function mobFrame(dt){
if(host()){TGL=targets();const d=dfc();
if(d<=1){while(mobs.length)rmMob(mobs.length-1)}
else{spT2+=dt;if(spT2>1.5){spT2=0;trySpawn(d)}
for(let i=mobs.length-1;i>=0;i--){const a=mobs[i];if(!TGL.some(t=>Math.hypot(t.x-a.x,t.z-a.z)<80)){rmMob(i);continue}
const px=a.x,pz=a.z;if(updMobH(a,dt))continue;animMob(a,Math.hypot(a.x-px,a.z-pz)/Math.max(dt,.001),dt)}}}
else for(const a of mobs){if(a.nx!=null){const px=a.x,pz=a.z;a.x+=(a.nx-a.x)*.25;a.y+=(a.ny-a.y)*.25;a.z+=(a.nz-a.z)*.25;a.m.rotation.y=a.ry;animMob(a,Math.hypot(a.x-px,a.z-pz)/Math.max(dt,.001),dt)}a.m.position.set(a.x,a.y,a.z)}
if(spawnProt>0)spawnProt-=dt;updArrows(dt)}
// --- лук ---
function bowTick(dt){if(bowOn){if(held()!=96||!locked||dd||slp||(!creative&&!cnt(97)))bowOn=0;else bowT=Math.min(1.2,bowT+dt)}
if(bowOn){const pb=$('pb');pb.style.display='block';pb.firstChild.style.width=Math.min(100,bowT*100)+'%'}
const tf=FOV-(bowOn?Math.min(1,bowT)*9:0);if(Math.abs(camera.fov-tf)>.05){camera.fov+=(tf-camera.fov)*Math.min(1,dt*10);camera.updateProjectionMatrix()}}
function bowShoot(){if(!bowOn)return;bowOn=0;const pw=Math.min(1,bowT);bowT=0;if(pw<.15)return;if(!creative&&!cnt(97))return;
const d=new THREE.Vector3();camera.getWorldDirection(d);const sp=14+pw*26;
fireArrow(camera.position.x+d.x*.5,camera.position.y-.1+d.y*.5,camera.position.z+d.z*.5,d.x*sp,d.y*sp,d.z*sp,'p',2+pw*7);if(!creative){take(97,1);wearTool(1)}}
// --- смерть и точка возрождения ---
function respT(){rpm=0;if(rsp){const[bx,by,bz]=rsp;for(let i=-1;i<=1;i++)for(let j=-1;j<=1;j++){const a=(bx>>4)+i,b=(bz>>4)+j;if(!ch.get(a+','+b))gen(a,b)}
if(get(bx,by,bz)==17){for(const[dx,dz]of BO)for(const dy of[0,1,-1]){const x=bx+dx,y=by+dy,z=bz+dz;if(!get(x,y,z)&&!get(x,y+1,z)&&sol(x,y-1,z)&&get(x,y-1,z)!=17)return[x+.5,y,z+.5]}return[bx+.5,by+1,bz+.5]}
rsp=null;rpm=1}
return findSpawn()||[.5,130,.5]}
function die(){if(dd)return;dd=1;for(const k in keys)keys[k]=0;mining=false;bowOn=0;p.vx=p.vy=p.vz=0;kbx=kbz=0;wake();if(ridingBoat)unseat();if(invOpen)closeInv();
if(!creative){const X=p.x,Y=p.y+.9,Z=p.z,L2=[...inv,...arm,oh[0]];if(cur)L2.push(cur);for(const s of L2)if(s)dropStack(s.id,s.n,X,Y,Z,s.w);inv.fill(null);arm.fill(null);oh[0]=null;cur=null;gr.fill(null);ref()}
rpp=respT();const ex=curW&&curW.diff==5&&!ws;
if(ex){const i=worlds.indexOf(curW);if(i>=0)worlds.splice(i,1);LS('worlds',worlds);curW=null}
$('dtx').textContent=ex?'Режим «Эксперт»: мир удалён безвозвратно. Вернуться в него нельзя.':(rsp?'Вы возродитесь у своей кровати':'');
$('drs').disabled=!!ex;$('death').style.display='flex';document.exitPointerLock();ovs()}
function respawn(){if(!dd||!rpp)return;dd=0;$('death').style.display='none';const q=rpp;rpp=null;p.x=q[0];p.y=q[1];p.z=q[2];p.vx=p.vy=p.vz=0;kbx=kbz=0;p.hp=20;p.food=20;lastHp=20;spawnProt=3;if(rpm)toast('Ваша кровать пропала — вы на точке спавна');lockPtr();ovs();ref();hud()}
function deathMenu(){if(curW)save();location.reload()}
$('death').onclick=e=>{const b=e.target.closest('[data-d]');if(!b||b.disabled)return;if(!sfx('click',.7))tone(500,.05,'square',.1,380);b.dataset.d=='r'?respawn():deathMenu()};

// ---------- рука и предмет от первого лица ----------
const hs=new THREE.Scene(),hc=new THREE.PerspectiveCamera(70,innerWidth/innerHeight,.01,10),hg=new THREE.Group(),ig=new THREE.Group(),
hMat=new THREE.MeshBasicMaterial({map:tex,vertexColors:true,alphaTest:.5}),hCache=new Map(),aMats=[];
function sbox(w,h,d,c){const g=new THREE.BoxGeometry(w,h,d),C=new THREE.Color(c),sh=[.8,.8,1,.5,.65,.65],a=[];for(let f=0;f<6;f++)for(let v=0;v<4;v++)a.push(C.r*sh[f],C.g*sh[f],C.b*sh[f]);
g.setAttribute('color',new THREE.Float32BufferAttribute(a,3));return new THREE.Mesh(g,new THREE.MeshBasicMaterial({vertexColors:true}))}
function blockMesh(id){const T={p:[],u:[],c:[],i:[]};for(const f of FACES){const t=B[id].t[f[4]],base=T.p.length/3,k=Math.max(.55,f[5]);
f[3].forEach((v,j)=>{T.p.push(v[0]-.5,v[1]-.5,v[2]-.5);T.u.push((t+.01+UV[j][0]*.98)/NT,.01+UV[j][1]*.98);T.c.push(k,k,k)});T.i.push(base,base+1,base+2,base,base+2,base+3)}
const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(T.p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(T.u,2));g.setAttribute('color',new THREE.Float32BufferAttribute(T.c,3));g.setIndex(T.i);return new THREE.Mesh(g,hMat)}
function itemMesh(id){const c=icoCv[id],d=c.getContext('2d').getImageData(0,0,16,16).data,P=[],C=[],S=.7/16,Tz=S*1.1,op=(x,y)=>x>=0&&y>=0&&x<16&&y<16&&d[(y*16+x)*4+3]>128;
const q=(v0,v1,v2,v3,col)=>{P.push(...v0,...v1,...v2,...v0,...v2,...v3);for(let i=0;i<6;i++)C.push(col[0],col[1],col[2])};
for(let y=0;y<16;y++)for(let x=0;x<16;x++){if(!op(x,y))continue;const i=(y*16+x)*4,cr=d[i]/255,cg=d[i+1]/255,cb=d[i+2]/255,x0=(x-8)*S,x1=x0+S,y1=(8-y)*S,y0=y1-S,z0=-Tz/2,z1=Tz/2,dk=[cr*.7,cg*.7,cb*.7];
q([x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1],[cr,cg,cb]);q([x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0],[cr*.85,cg*.85,cb*.85]);
if(!op(x-1,y))q([x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0],dk);if(!op(x+1,y))q([x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1],dk);
if(!op(x,y-1))q([x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0],dk);if(!op(x,y+1))q([x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1],dk)}
const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(P,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(C,3));
return new THREE.Mesh(geo,new THREE.MeshBasicMaterial({vertexColors:true,side:THREE.DoubleSide}))}
const sl=sbox(.22,.22,.6,0x3a86ff),hn=sbox(.22,.22,.3,0xf0c090);sl.position.z=.6;hn.position.z=.15;hg.add(sl,hn,ig);hs.add(hg);aMats.push(sl.material,hn.material);
const hgL=new THREE.Group(),igL=new THREE.Group(),slL=sbox(.22,.22,.6,0x3a86ff),hnL=sbox(.22,.22,.3,0xf0c090),hCacheL=new Map();slL.position.z=.6;hnL.position.z=.15;hgL.add(slL,hnL,igL);hgL.visible=false;hs.add(hgL);aMats.push(slL.material,hnL.material);
function handSkin(t,leg){handClear();const mR=new THREE.MeshBasicMaterial({map:t}),mL=new THREE.MeshBasicMaterial({map:t});
[[sl,ARM_R,.6,0,2/3,mR],[hn,ARM_R,.3,2/3,1,mR],[slL,ARM_L,.6,0,2/3,mL],[hnL,ARM_L,.3,2/3,1,mL]].forEach(([m,A,len,f0,f1,mat])=>{if(!m.userData.o0)m.userData.o0=[m.geometry,m.material];const g=new THREE.BoxGeometry(.22,len,.22);skinUV(g,sps(A[0],A[1],4,12,4,A[2],A[3],f0,f1,A[4]),0,leg);g.rotateX(Math.PI/2);m.geometry=g;m.material=mat;m.userData.sk=[g,mat]});
aMats.length=0;aMats.push(mR,mL)}
function handClear(){[sl,hn,slL,hnL].forEach(m=>{if(m.userData.o0){const k=m.userData.sk;m.geometry=m.userData.o0[0];m.material=m.userData.o0[1];if(k){k[0].dispose();k[1].dispose()}m.userData.sk=null}});aMats.length=0;aMats.push(sl.material,hn.material,slL.material,hnL.material)}
if(currentSkin){if(currentSkinData)applyPlayerSkin(meR,currentSkin,currentSkinData);else urlToData(srvBase+'/skins/'+encodeURIComponent(currentSkin)).then(d=>{skinLib[currentSkin]=d;saveLib();currentSkinData=d;applyPlayerSkin(meR,currentSkin,d)}).catch(()=>{})}
let hid=-1,hy=1,wph=0,hidL=0,hyL=1;
function setItem(id,G=ig,C=hCache,left=0){G.remove(...G.children);if(!id)return;let m=C.get(id);if(!m){m=B[id]&&id!=61&&id!=54?blockMesh(id):itemMesh(id);C.set(id,m)}G.add(m);const q=left?-1:1;
if(B[id]&&id!=61){G.position.set(-.07*q,.13,-.1);G.rotation.set(.2,.75*q,0);G.scale.setScalar(.2)}else{G.position.set(-.02*q,.2,-.14);G.rotation.set(0,-.55*q,0);G.scale.setScalar(.42)}}
function dynLights(){HL.length=0;const T=performance.now(),fl=.96+.04*Math.sin(T/110)*Math.sin(T/47+1);
if(held()==61||(oh[0]&&oh[0].id==61))HL.push([p.x-Math.sin(p.yaw)*.4,p.y+1.35-.35*snk,p.z-Math.cos(p.yaw)*.4,9*fl]);
for(const r of rp.values())if(r.h==61||r.o==61)HL.push([r.g.position.x,r.g.position.y+1.3,r.g.position.z,9*fl]);
HL.sort((a,b)=>Math.hypot(a[0]-p.x,a[2]-p.z)-Math.hypot(b[0]-p.x,b[2]-p.z));HL.length=Math.min(4,HL.length);
for(let i=0;i<4;i++){const q=HL[i];HLU.value[i].set(q?q[0]:0,q?q[1]:0,q?q[2]:0,q?q[3]:0)}}
function updHand(dt,br){const w=held();if(w!==hid){hy=Math.min(1,hy+dt*7);if(hy>=1){setItem(w);hid=w}}else hy=Math.max(0,hy-dt*7); // смена предмета: рука опускается и поднимается
const wo=oh[0]?oh[0].id:0;if(wo!==hidL){hyL=Math.min(1,hyL+dt*7);if(hyL>=1){setItem(wo,igL,hCacheL,1);hidL=wo}}else hyL=wo?Math.max(0,hyL-dt*7):Math.min(1,hyL+dt*7); // левая рука: появляется, только когда в ней что-то есть
const sp=Math.hypot(p.vx,p.vz),k=p.g&&locked&&OP.bob?Math.min(1,sp/4):0;wph+=sp*dt*2.4;
const sw=swingT>0?Math.sin((1-swingT/.3)*Math.PI):0; // взмах при ломании/стройке/ударе
hg.position.set(.32-sw*.12+Math.sin(wph)*.02*k,-.3-hy*.55-sw*.1+Math.abs(Math.cos(wph))*.02*k,-.55-sw*.15);hg.rotation.set(.45-sw*.9,.35+sw*.35,-.05);
const swl=swL>0?Math.sin((1-swL/.3)*Math.PI):0;swL=Math.max(0,swL-dt);
hgL.visible=hyL<.99;hgL.position.set(-.32+swl*.12-Math.sin(wph)*.02*k,-.3-hyL*.55-swl*.1+Math.abs(Math.cos(wph+1.6))*.02*k,-.55-swl*.15);hgL.rotation.set(.45-swl*.9,-.35-swl*.35,.05);
const c=Math.max(.07,br);aMats.forEach(m=>m.color.setScalar(c));hMat.color.setScalar(c);const im=ig.children[0];if(im)im.material.color.setScalar(c);const iL=igL.children[0];if(iL)iL.material.color.setScalar(c)}
// ---------- трещины на ломаемом блоке ----------
const CK=[];{const r=rng(12345),px=[];for(let a=0;a<6;a++){let x=8,y=8;const dx=Math.cos(a*1.05+.3),dy=Math.sin(a*1.05+.3);for(let i=0;i<14;i++){x+=dx+(r()-.5)*.9;y+=dy+(r()-.5)*.9;const X=x|0,Y=y|0;if(X>=0&&X<16&&Y>=0&&Y<16)px.push([X,Y,i])}}
px.sort((a,b)=>a[2]-b[2]);for(let st=1;st<=10;st++){const c=document.createElement('canvas');c.width=c.height=16;const g=c.getContext('2d');g.fillStyle='rgba(0,0,0,.55)';const n=Math.ceil(px.length*st/10);
for(let i=0;i<n;i++){g.fillRect(px[i][0],px[i][1],1,1);if(st>6&&i%2)g.fillRect(px[i][0]+1,px[i][1],1,1)}const t=new THREE.CanvasTexture(c);t.magFilter=t.minFilter=THREE.NearestFilter;t.generateMipmaps=false;CK.push(t)}}
const crack=new THREE.Mesh(new THREE.BoxGeometry(1.004,1.004,1.004),new THREE.MeshBasicMaterial({map:CK[0],transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1}));crack.visible=false;scene.add(crack);
const rcr=new Map();let crS={k:'',s:0,t:0};
function setRCrack(id,x,y,z,st){let c=rcr.get(id);if(st<1){if(c){scene.remove(c);c.material.dispose();rcr.delete(id)}return}
if(!c){c=new THREE.Mesh(crack.geometry,new THREE.MeshBasicMaterial({map:CK[0],transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1}));scene.add(c);rcr.set(id,c)}
c.material.map=CK[Math.min(9,st-1)];c.position.set(x+.5,y+.5,z+.5);c.userData.t=performance.now()}
function sendCr(x,y,z,st){const k=x+','+y+','+z,n=performance.now();if(crS.k!=k||crS.s!=st||n-crS.t>1000){crS={k,s:st,t:n};snd({t:'m',x,y,z,s:st})}}
function crReset(){if(crS.s){crS={k:'',s:0,t:0};snd({t:'m',x:0,y:0,z:0,s:0})}}
setInterval(()=>{const n=performance.now();for(const[id,c]of[...rcr])if(n-c.userData.t>3500)setRCrack(id,0,0,0,0)},700);


// ---------- сундук: открывающаяся крышка ----------
function mkLid(x,y,z,m){const mm=m&63,q=pbox(62,mm|64,x,y,z)[0],n=HD[mm&3],px=n[0]>0?q[0]:n[0]<0?q[3]:.5,pz=n[1]>0?q[2]:n[1]<0?q[5]:.5;
const T={p:[],u:[],c:[],i:[],b:[]};BL=bl(x,y,z);part(T,62,mm|64,0,y,0,x,z);if(!T.i.length)return null;
for(let i=0;i<T.p.length;i+=3){T.p[i]-=px;T.p[i+1]-=y+.625;T.p[i+2]-=pz}
const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(T.p,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(T.u,2));g.setAttribute('color',new THREE.Float32BufferAttribute(T.c,3));g.setAttribute('bcol',new THREE.Float32BufferAttribute(T.b,3));g.setIndex(T.i);
const G=new THREE.Group();G.add(new THREE.Mesh(g,matO));G.position.set(x+px,y+.625,z+pz);G.userData={n};scene.add(G);return G}
function lidSync(x,y,z,b,f){const k=x+','+y+','+z,L=lids.get(k);
if(b==62&&(f&32)){if(!L){const G=mkLid(x,y,z,f);if(G){lids.set(k,{g:G,t:0,d:1});if(Math.hypot(x-p.x,z-p.z)<12&&!sfx('chest_open',.8))tone(160,.25,'sawtooth',.05,320)}}else if(!L.keep)L.d=1}
else if(L&&!L.keep){L.keep=2;L.d=0;L.t=0;L.g.rotation.set(0,0,0)}}
function trample(){for(const[dx,dz]of[[-.3,-.3],[.3,-.3],[-.3,.3],[.3,.3]]){const x=Math.floor(p.x+dx),z=Math.floor(p.z+dz),y=Math.floor(p.y-.05);
if(get(x,y,z)==50){pset(x,y,z,2,0);if(get(x,y+1,z)==51)pset(x,y+1,z,0,0);bsound(2,2)}}}
function animLids(dt){lids.forEach((L,k)=>{if(L.keep){if(--L.keep<=0){scene.remove(L.g);L.g.traverse(o=>o.geometry&&o.geometry.dispose());lids.delete(k)}return}
L.t=Math.max(0,Math.min(1,L.t+L.d*dt*4));const a=Math.sin(L.t*Math.PI/2)*1.3,n=L.g.userData.n;if(n[1])L.g.rotation.x=n[1]>0?-a:a;else L.g.rotation.z=n[0]>0?a:-a;
if(L.d<0&&L.t<=0){const[x,y,z]=k.split(',').map(Number);L.keep=2;if(!sfx('chest_close',.8)){tone(110,.12,'square',.1,70);noise(.06,.15,600)}if(get(x,y,z)==62)pset(x,y,z,62,fget(x,y,z)&~32)}})}
// ---------- звук (синтез через WebAudio) ----------
const RED=new THREE.Color(1,.15,.15);let sneak=0,snk=0,shk=0,swingT=0,AX=null,gS,gM,nb,stepD=0,wasWet=false,lastHp=20,hurtT=0,hitT=0,nextMus=0;
const gains=()=>{if(AX){gS.gain.value=OP.vol;gM.gain.value=OP.mus}};
function aud(){if(AX===null){try{AX=new(window.AudioContext||window.webkitAudioContext)();gS=AX.createGain();gM=AX.createGain();gS.connect(AX.destination);gM.connect(AX.destination);nb=AX.createBuffer(1,AX.sampleRate,AX.sampleRate);const d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;gains()}catch(e){AX=0}}if(AX&&AX.state=='suspended')AX.resume();return AX}
function tone(f,d,ty='sine',v=.3,f2=f,out=gS,t0=0){const a=aud();if(!a)return;const t=a.currentTime+t0,o=a.createOscillator(),g=a.createGain();o.type=ty;o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(Math.max(20,f2),t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(out);o.start(t);o.stop(t+d)}
function noise(d,v=.3,f=1000,ty='lowpass',t0=0){const a=aud();if(!a)return;const t=a.currentTime+t0,c=a.createBufferSource(),fl=a.createBiquadFilter(),g=a.createGain();c.buffer=nb;c.playbackRate.value=.8+Math.random()*.4;fl.type=ty;fl.frequency.value=f;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);c.connect(fl);fl.connect(g);g.connect(gS);c.start(t,Math.random()*.5,d)}
const SPK=new Map();let MU=null;
// настоящие звуки: файлы из папки sounds/ (ogg/mp3/wav, имена с цифрой 1-4 для вариантов); если файла нет — звук синтезируется
function sfx(name,v=1,r=1,ch='vol'){let e=SPK.get(name);if(!e){e={l:[]};SPK.set(name,e);for(const n of['',1,2,3,4])for(const x of['ogg','mp3','wav']){const a=new Audio();a.preload='auto';a.oncanplaythrough=()=>{if(!e.l.includes(a))e.l.push(a)};a.src='sounds/'+name+n+'.'+x}return false}
if(!e.l.length)return false;if(ch=='mus'&&MU&&!MU.ended&&!MU.paused)return true;const a=e.l[Math.random()*e.l.length|0].cloneNode();a.volume=Math.min(1,v*OP[ch]);a.playbackRate=r;a.preservesPitch=false;a.play().catch(()=>{});if(ch=='mus')MU=a;return true}
const MN={s:'stone',w:'wood',a:'sand',n:'snow',l:'cloth',g:'grass'},MAT=b=>[3,10,11,15,53,63].includes(b)?'s':[5,9,13,14,16,17,54,62].includes(b)?'w':b==4?'a':b==12?'n':b==6||(b>=18&&b<=21)?'l':'g';
function bsound(b,k){const m=MAT(b);if(sfx((k?'':'step_')+MN[m],[.45,.5,.9,.7][k],(k==1?1.12:k==3?.9:1)*(.93+Math.random()*.14)))return;const v=[.08,.14,.3,.22][k],d=[.07,.09,.2,.1][k];// k: 0 шаг, 1 удар, 2 слом, 3 постановка
if(m=='s'){noise(d,v,k?2500:1800,'bandpass');if(k>1)tone(180,.1,'square',v*.3,90)}
else if(m=='w'){noise(d,v*.6,900,'lowpass');tone(k>1?220:300,d,'triangle',v*.9,150)}
else if(m=='a'||m=='n')noise(d*1.3,v*.8,k?5000:3500,'highpass');
else if(m=='l')noise(d,v*.7,4000,'highpass');
else{noise(d,v,k?700:500,'lowpass');tone(110,d,'sine',v*.5,60)}}
function asound(kind,hurt){if(sfx(['pig','cow','sheep'][kind]+(hurt?'_hurt':''),hurt?.9:.7,.95+Math.random()*.1))return;if(kind==0)tone(hurt?900:260,hurt?.22:.18,'square',.1,hurt?400:180);else if(kind==1)tone(hurt?200:110,hurt?.3:.7,'sawtooth',.12,hurt?90:80);else tone(hurt?520:380,hurt?.3:.55,'sawtooth',.07,hurt?330:300)}
setInterval(()=>{if(!started||!OP.mus||!AX)return;const n=performance.now();if(!nextMus)nextMus=n+12000;if(n<nextMus)return;nextMus=n+40000+Math.random()*50000;
if(sfx('music',1,1,'mus'))return;const sc=[262,294,330,392,440,523,588,660];let t=0,i=Math.random()*5|0;for(let k=0;k<4+(Math.random()*3|0);k++){i=Math.max(0,Math.min(7,i+(Math.random()*5|0)-2));tone(sc[i],3,'sine',.2,sc[i],gM,t);tone(sc[i]/2,3,'triangle',.07,sc[i]/2,gM,t);t+=.8+Math.random()*.9}},1000);

// ---------- меню, миры, настройки ----------
const M=$('menu'),mo=()=>M.style.display!='none',LS=(k,v)=>{try{if(v===undefined)return JSON.parse(localStorage.getItem('mc_'+k));localStorage.setItem('mc_'+k,JSON.stringify(v))}catch(e){return null}};
const OP=Object.assign({rd:4,fov:75,sens:1,info:1,vol:.6,mus:.3,bri:0,clouds:1,part:2,sunsh:1,bob:1,cross:1,hand:1},LS('set')||{}),WTY={normal:'Обычный',flat:'Плоский',amp:'Расширенный',isl:'Архипелаг'},MD={survival:'Выживание',creative:'Творческий'};
let worlds=LS('worlds')||[],selW=-1,curW=null,scrN='main',newT='normal',newM='survival';
M.style.backgroundImage='url('+ico[2]+')';
// ---------- управление: переназначение клавиш ----------
const KDEF={fwd:['Вперёд','KeyW'],back:['Назад','KeyS'],left:['Влево','KeyA'],right:['Вправо','KeyD'],jump:['Прыжок / полёт вверх','Space'],sneak:['Красться / полёт вниз','ShiftLeft'],sprint:['Бег','ControlLeft'],inv:['Инвентарь','KeyE'],drop:['Выбросить предмет','KeyQ'],swap:['Поменять руки','KeyF'],chat:['Чат','KeyT'],cmd:['Консоль','Backquote'],view:['Вид от 3-го лица','F5'],tab:['Список игроков','Tab']};
const KB=Object.assign({},...Object.keys(KDEF).map(k=>({[k]:KDEF[k][1]})),LS('keys')||{}),DEFS=new Set(Object.keys(KDEF).map(k=>KDEF[k][1]));let REM={};
const buildRem=()=>{REM={};for(const k in KDEF)REM[KB[k]]=KDEF[k][1]};buildRem();
const kcode=c=>REM[c]||(DEFS.has(c)?'':c),KE=E=>({code:kcode(E.code),key:E.key,target:E.target,repeat:E.repeat,ctrlKey:E.ctrlKey,preventDefault:()=>E.preventDefault()});
const keyName=c=>({Space:'Пробел',ShiftLeft:'Shift (лев.)',ShiftRight:'Shift (прав.)',ControlLeft:'Ctrl (лев.)',ControlRight:'Ctrl (прав.)',AltLeft:'Alt (лев.)',Backquote:'` (тильда)',ArrowUp:'↑',ArrowDown:'↓',ArrowLeft:'←',ArrowRight:'→',Tab:'Tab',CapsLock:'Caps Lock'})[c]||c.replace(/^Key/,'').replace(/^Digit/,'').replace(/^Numpad/,'Num ');
function applySet(){RD=OP.rd;FOV=OP.fov;SENS=OP.sens;camera.fov=FOV;camera.updateProjectionMatrix();fogN.far=RD*16+4;fogN.near=Math.min(40,RD*8);camera.far=Math.max(200,RD*16+80);camera.updateProjectionMatrix();$('info').style.display=OP.info?'block':'none';gains();$('cross').style.display=OP.cross?'':'none';LS('set',OP)}
function scr(n){scrN=n;const bt=(a,t,x='')=>`<button class="mb" data-a="${a}" ${x}>${t}</button>`;let h='';
if(n=='main')h='<h1>MINECRAFT</h1>'+bt('single','Одиночная игра')+bt('multi','Мультиплеерная игра')+bt('skins','Skins')+bt('set','Настройки');
else if(n=='pause')h='<h2>Игра приостановлена</h2>'+bt('resume','Вернуться в игру')+(!ws&&curW?bt('chdiff','Сложность: '+DN[diff],curW.diff==5?'disabled':''):'')+bt('set','Настройки')+bt('quit','Сохранить и выйти в меню')+'<p style="max-width:460px;font-size:12px;color:#ccc;text-align:center">WASD — движение · Пробел — прыжок · Shift — бег · ЛКМ — ломать/бить (с луком: зажать и отпустить — выстрел) · ПКМ — ставить/есть · E — инвентарь · F5 — вид · &#96; — консоль</p>';
else if(n=='single')h='<h2>Выбор мира</h2><div id="wl">'+(worlds.map((w,i)=>`<div class="w${i==selW?' on':''}" data-a="sel" data-i="${i}"><b>${w.name}</b><small>${MD[w.mode||'survival']} · ${DN[w.diff||3]} · ${WTY[w.type]} · сид ${w.seed}</small></div>`).join('')||'<p style="text-align:center;color:#aaa">Миров пока нет</p>')+'</div>'+bt('play','Играть в выбранном мире',selW<0?'disabled':'')+bt('new','Создать новый мир')+bt('del','Удалить мир',selW<0?'disabled':'')+bt('main','Назад');
else if(n=='new')h=`<h2>Создание мира</h2><input class="mi" id="wn" placeholder="Название мира" value="Новый мир ${worlds.length+1}" maxlength="24"><input class="mi" id="ws" placeholder="Сид (пусто — случайный)">`+bt('mode','Режим: '+MD[newM])+bt('diff','Сложность: '+DN[newD])+`<p id="dnote" style="margin:0;color:#ccc;font-size:13px">${DNOTE[newD]}</p>`+bt('type','Тип мира: '+WTY[newT])+bt('create','Создать мир')+bt('single','Назад');
else if(n=='multi')h=`<h2>Мультиплеер</h2><input class="mi" id="nk" placeholder="Ник" maxlength="16" value="${LS('nick')||''}"><input class="mi" id="ip" placeholder="IP:порт (например 192.168.0.5:3000)" value="${LS('ip')||(location.protocol.startsWith('http')?location.host:'')}"><div id="msg"></div>`+bt('join','Подключиться')+bt('main','Назад');
else if(n=='skins'){h='<h2>Скины</h2><p style="text-align:center;color:#ccc;margin:0 0 6px">Библиотека скинов. Нажми «Экипировать» — скин будет на тебе в одиночной игре и виден всем в мультиплеере, рука от первого лица тоже станет такой же.</p><div id="skinlist" style="width:min(460px,90vw);max-height:250px;overflow:auto"></div><input class="mi" id="skinname" maxlength="32" placeholder="Название скина (например Alex)"><input id="skinfile" type="file" accept="image/png" class="mi"><button class="mb" data-a="uploadskin">Добавить PNG в библиотеку</button><button class="mb" data-a="unskin">Снять скин</button>'+bt('main','Назад')+'<p style="font-size:12px;color:#aaa;text-align:center">PNG 64×64 (или 64×32). Скины также можно класть в папку skins рядом с server.js.</p>';setTimeout(loadSkinList,0)}
else if(n=='set'){const r=(k,t,mn,mx,st,u='')=>`<div class="sr"><label>${t}: <b id="v_${k}">${OP[k]}${u}</b></label><input type="range" data-s="${k}" min="${mn}" max="${mx}" step="${st}" value="${OP[k]}"></div>`;
const tg=(k,t)=>bt('tg',t+': '+(OP[k]?'ВКЛ':'выкл'),'data-k="'+k+'"');
h='<h2>Настройки</h2><div style="width:min(460px,92vw);max-height:60vh;overflow:auto;padding-right:6px">'+r('rd','Дальность прорисовки',2,32,1,' чанков')+r('fov','Поле зрения (FOV)',50,110,1)+r('sens','Чувствительность мыши',.2,3,.1)+r('bri','Яркость',0,.5,.05)+r('vol','Громкость звуков',0,1,.1)+r('mus','Музыка',0,1,.1)+r('part','Частицы (0 — выкл, 1 — мало, 2 — много)',0,2,1)+tg('clouds','Облака')+tg('sunsh','Освещение от солнца (затенение граней)')+tg('bob','Покачивание руки при ходьбе')+tg('cross','Прицел')+tg('hand','Рука и предмет от 1-го лица')+tg('info','Координаты и инфо')+'</div>'+bt('controls','Управление...')+bt('back','Готово')}
else if(n=='controls'){h='<h2>Управление</h2><p style="margin:0 0 6px;color:#ccc;text-align:center">Нажми на кнопку и затем на нужную клавишу</p><div style="width:min(460px,92vw);max-height:56vh;overflow:auto;padding-right:6px">'+Object.keys(KDEF).map(k=>`<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin:4px 0"><span>${KDEF[k][0]}</span><button class="mb" style="width:170px;margin:0" data-a="bind" data-k="${k}">${keyName(KB[k])}</button></div>`).join('')+'</div>'+bt('resetkeys','Сбросить по умолчанию')+bt('set','Назад')}
M.innerHTML=h}
M.oninput=e=>{const k=e.target.dataset.s;if(!k)return;OP[k]=+e.target.value;$('v_'+k).textContent=OP[k]+(k=='rd'?' чанков':'');applySet()};
async function loadSkinList(){const el=$('skinlist');if(!el)return;let srv=[];try{srv=await fetch(srvBase+'/api/skins',{cache:'no-store'}).then(r=>{if(!r.ok)throw 0;return r.json()})}catch{}
const el2=$('skinlist');if(!el2)return;const names=[...new Set([...srv,...Object.keys(skinLib)])].sort();el2.innerHTML='';
if(!names.length){el2.textContent='Скинов пока нет. Добавь PNG кнопкой ниже или положи файл в папку skins рядом с server.js.';return}
names.forEach(n=>{const row=document.createElement('div');row.style.cssText='display:flex;gap:8px;align-items:center;justify-content:space-between;margin:5px 0;padding:6px;background:#0006';
const cv=document.createElement('canvas');cv.width=cv.height=32;cv.style.cssText='width:32px;height:32px;image-rendering:pixelated;flex:none';const im=new Image();im.onload=()=>{const c=cv.getContext('2d');c.imageSmoothingEnabled=false;c.drawImage(im,8,8,8,8,0,0,32,32);if(im.height>=64)c.drawImage(im,40,8,8,8,0,0,32,32)};im.src=skinLib[n]||srvBase+'/skins/'+encodeURIComponent(n);
const t=document.createElement('span');t.textContent=n.replace(/\.png$/i,'');t.style.cssText='overflow-wrap:anywhere;flex:1;text-align:left';
const b=document.createElement('button');b.className='mb';b.style.width='130px';b.textContent=currentSkin===n?'Экипировано':'Экипировать';b.onclick=()=>equipSkin(n);row.append(cv,t,b);el2.append(row)})}
const act={controls:()=>scr('controls'),tg:b=>{const k=b.dataset.k;OP[k]=OP[k]?0:1;applySet();scr('set')},resetkeys:()=>{for(const k in KDEF)KB[k]=KDEF[k][1];LS('keys',KB);buildRem();scr('controls')},
bind:b=>{const k=b.dataset.k;b.textContent='Нажми клавишу… (Esc — отмена)';const on=ev=>{ev.preventDefault();ev.stopPropagation();removeEventListener('keydown',on,true);if(ev.code!='Escape'){const old=KB[k];for(const o in KB)if(o!=k&&KB[o]==ev.code)KB[o]=old;KB[k]=ev.code;LS('keys',KB);buildRem()}scr('controls')};addEventListener('keydown',on,true)},
skins:()=>scr('skins'),uploadskin:async()=>{const f=$('skinfile')?.files?.[0];if(!f)return toast('Выбери PNG-файл');if(f.size>512*1024)return toast('Файл больше 512 КБ');
const name=(($('skinname')?.value||f.name.replace(/\.png$/i,'')).replace(/[^a-zA-Z0-9_-]/g,'').slice(0,32)||'skin')+'.png';
const d=await new Promise(r=>{const fr=new FileReader();fr.onload=()=>r(fr.result);fr.onerror=()=>r('');fr.readAsDataURL(f)});if(!d.startsWith('data:image/png'))return toast('Нужен PNG');
const ok=await new Promise(r=>{const im=new Image();im.onload=()=>r(im.width>=64&&(im.height==im.width||im.height*2==im.width));im.onerror=()=>r(0);im.src=d});if(!ok)return toast('Нужен скин 64×64 или 64×32');
skinLib[name]=d;saveLib();try{await fetch(srvBase+'/api/skins',{method:'POST',headers:{'Content-Type':'image/png','X-Skin-Name':name.replace(/\.png$/,'')},body:f})}catch{}
await equipSkin(name)},unskin:()=>{currentSkin='';currentSkinData='';LS('skin','');applyPlayerSkin(meR,'','');sendSkin();loadSkinList();toast('Скин снят')},single:()=>{selW=worlds.length?0:-1;scr('single')},multi:()=>scr('multi'),set:()=>scr('set'),main:()=>scr('main'),back:()=>scr(started?'pause':'main'),new:()=>scr('new'),
sel:b=>{selW=+b.dataset.i;scr('single')},
mode:b=>{newM=newM=='survival'?'creative':'survival';b.textContent='Режим: '+MD[newM]},
diff:b=>{newD=newD%5+1;b.textContent='Сложность: '+DN[newD];const n=$('dnote');if(n)n.textContent=DNOTE[newD]},
chdiff:b=>{if(ws||!curW||curW.diff==5)return;diff=curW.diff=diff%4+1;b.textContent='Сложность: '+DN[diff]},
type:b=>{const k=Object.keys(WTY);newT=k[(k.indexOf(newT)+1)%k.length];b.textContent='Тип мира: '+WTY[newT]},
create:()=>{if(newD==5&&!confirm('Эксперт: одна жизнь. После смерти мир будет удалён безвозвратно. Создать мир?'))return;const n=($('wn').value||'Мир').replace(/[<>&"]/g,'').slice(0,24),t=$('ws').value.trim(),sd=t?(/^-?\d+$/.test(t)?+t:[...t].reduce((a,c)=>(a*31+c.charCodeAt(0))|0,7)):Math.random()*1e4;
const w={name:n,type:newT,mode:newM,diff:newD,seed:Math.abs(sd)|0};worlds.push(w);LS('worlds',worlds);startSP(w)},
play:()=>startSP(worlds[selW]),
del:()=>{if(!confirm('Удалить мир «'+worlds[selW].name+'»?'))return;worlds.splice(selW,1);selW=-1;LS('worlds',worlds);scr('single')},
info:b=>{OP.info^=1;b.textContent='Координаты и инфо: '+(OP.info?'ВКЛ':'выкл');applySet()},
resume:()=>{M.style.display='none';lockPtr()},
quit:()=>{save();location.reload()},
join:()=>{const a=$('ip').value.trim(),nick=$('nk').value.trim()||'Игрок';if(!a)return $('msg').textContent='Введите адрес сервера';
LS('nick',nick);LS('ip',a);myName=nick;mpKey='mpinv:'+a.toLowerCase()+'|'+nick.toLowerCase();$('msg').textContent='Подключение...';
srvBase='http://'+(a.includes(':')?a:a+':3000');try{ws=new WebSocket('ws://'+(a.includes(':')?a:a+':3000')+'/?n='+encodeURIComponent(nick))}catch(e){ws=null;return $('msg').textContent='Неверный адрес'}
ws.onmessage=e=>{const m=JSON.parse(e.data);onMsg(m);if(m.t==='init'&&currentSkin)sendSkin()};
ws.onclose=()=>{if(started)toast('Соединение потеряно');else{ws=null;const m=$('msg');if(m)m.textContent='Не удалось подключиться'}}}};
M.onclick=e=>{const b=e.target.closest('[data-a]');if(b&&!b.disabled){if(!sfx('click',.7))tone(500,.05,'square',.1,380);act[b.dataset.a](b)}};
function startSP(w){curW=w;diff=w.diff||3;rsp=w.rsp||null;dd=0;seed=w.seed;wt=w.type;creative=w.mode=='creative'?1:0;cheat.god=creative;cheat.fly=0;edits.length=0;furn.clear();for(const[k,f]of w.furn||[])furn.set(k,f);chests.clear();for(const[k,a]of w.chests||[])chests.set(k,a);for(const e of w.edits||[])edits.push(e);
startGame(()=>{if(w.px!=null){Object.assign(p,{x:w.px,y:w.py,z:w.pz,hp:w.hp,food:w.food,vy:0});const a=Math.floor(p.x)>>4,b=Math.floor(p.z)>>4;
for(let i=-1;i<=1;i++)for(let j=-1;j<=1;j++)if(!ch.get((a+i)+','+(b+j)))gen(a+i,b+j);(w.inv||[]).forEach((s,i)=>inv[i]=s);(w.arm||[]).forEach((s,i)=>arm[i]=s);(w.oh||[]).forEach((s,i)=>oh[i]=s);if(w.tm!=null)tm=w.tm}});lockPtr()}
let mpKey='';function saveMP(){if(!mpKey||!started)return;LS(mpKey,{inv,arm,oh,rsp})}
function loadMP(){const d=mpKey&&LS(mpKey);if(!d)return;const ok=s=>s&&typeof s.id=='number'&&(B[s.id]||IT[s.id]||TL[s.id])&&s.n>0?{id:s.id,n:Math.min(64,s.n|0),w:s.w||0}:null;(d.inv||[]).slice(0,27).forEach((s,i)=>inv[i]=ok(s));(d.arm||[]).slice(0,4).forEach((s,i)=>arm[i]=ok(s));if(d.oh&&d.oh[0])oh[0]=ok(d.oh[0]);if(Array.isArray(d.rsp)&&d.rsp.length==3)rsp=d.rsp.map(Number);ref()}
function save(){saveMP();if(!curW||!started)return;const E=new Map();edits.forEach(e=>E.set(e[0]+','+e[1]+','+e[2],e));Object.assign(curW,{mode:creative?'creative':'survival',edits:[...E.values()],px:dd&&rpp?rpp[0]:p.x,py:dd&&rpp?rpp[1]:p.y,pz:dd&&rpp?rpp[2]:p.z,hp:dd?20:p.hp,food:dd?20:p.food,rsp,diff,inv,arm,oh,tm,furn:[...furn],chests:[...chests]});LS('worlds',worlds)}
setInterval(save,10000);addEventListener('beforeunload',save);addEventListener('pagehide',save);

// ---------- консоль (клавиша `) ----------
let conOpen=false;const hist=[];let hi=0;
const chatLog=[],mkLine=(t,c)=>{const d=document.createElement('div');d.textContent=t;d.style.color=c;return d},
lg=(t,c='#fff')=>{chatLog.push([t,c]);if(chatLog.length>300)chatLog.shift();const d=mkLine(t,c),L=$('clog');L.append(d);if(conOpen)L.scrollTop=L.scrollHeight;else{while(L.children.length>10)L.firstChild.remove();setTimeout(()=>d.remove(),9000)}};
let chatMode=false;
function openCon(c){chatMode=!!c;conOpen=true;document.exitPointerLock();$('con').classList.add('o');{const L=$('clog');L.replaceChildren(...chatLog.map(([t,c])=>mkLine(t,c)));L.scrollTop=L.scrollHeight}$('cin').placeholder=chatMode?'Сообщение в чат (Enter — отправить, / — команда)':'Команда (help — список)';ovs();$('cin').value='';$('cin').focus()}
function closeCon(relock=true){conOpen=false;$('con').classList.remove('o');{const L=$('clog');L.replaceChildren();chatLog.slice(-5).forEach(([t,c])=>{const d=mkLine(t,c);L.append(d);setTimeout(()=>d.remove(),5000)})}$('cin').blur();if(relock)lockPtr();ovs()}
$('cin').onkeydown=e=>{e.stopPropagation();if(e.code=='Backquote'||e.key=='Escape'){e.preventDefault();return closeCon()}
if(e.key=='Enter'){const v=$('cin').value.trim();if(v){hist.push(v);if(chatMode&&v[0]!='/')CMD.say([v]);else run(v)}hi=hist.length;closeCon()}
else if(e.key=='ArrowUp'){e.preventDefault();hi=Math.max(0,hi-1);$('cin').value=hist[hi]||''}else if(e.key=='ArrowDown'){hi=Math.min(hist.length,hi+1);$('cin').value=hist[hi]||''}};
const nn=s=>s.toLowerCase().replace(/ё/g,'е').replace(/[ _]+/g,'_'),EN={sword:92,wooden_sword:92,stone_sword:93,iron_sword:94,diamond_sword:95,bow:96,arrow:97,rotten_flesh:98,iron_block:64,grass:1,dirt:2,stone:3,sand:4,log:5,wood:5,leaves:6,planks:9,cobblestone:10,cobble:10,coal_ore:11,glass:63,snow:12,table:13,crafting_table:13,stick:77,torch:61,pickaxe:48,raw_meat:22,porkchop:22,pork:22,cooked_porkchop:23,cooked_meat:23,beef:28,raw_beef:28,steak:29,leather:30,stairs:14,cobble_stairs:15,door:31,wool:18,white_wool:18,black_wool:19,brown_wool:20,pink_wool:21,mutton:32,cooked_mutton:33,bed:38,white_bed:38,black_bed:39,brown_bed:40,pink_bed:41,coal:24,bucket:25,water_bucket:26,lava_bucket:27,furnace:53,fence:54,chest:62,boat:99,лодка:99,wooden_pickaxe:48,stone_pickaxe:34,axe:35,wooden_axe:35,stone_axe:36,shovel:37,wooden_shovel:37,stone_shovel:42,iron_axe:100,diamond_axe:101,iron_shovel:102,diamond_shovel:103,hoe:43,wooden_hoe:43,stone_hoe:44,seeds:45,wheat:46,bread:47,farmland:50};
function fid(s){s=nn(s);if(/^\d+$/.test(s))return+s;if(EN[s])return EN[s];for(const id in B)if(B[id].n&&nn(B[id].n)==s)return+id;for(const id in IT)if(nn(IT[id][0])==s)return+id;return 0}
const okI=id=>id&&((B[id]&&B[id].n)||IT[id]);
const CMD={
help:()=>lg('gamemode creative|survival · god · fly · give <предмет> [кол-во] · items · tp <x y z | x z | ник> · time <day|night|0-24> · heal · feed · kill · difficulty 1-4 · spawn · clear · seed · say <текст>'),
gamemode:a=>{const m=(a[0]||'').toLowerCase();if(['creative','c','1','креатив'].includes(m)){creative=1;cheat.god=1;cheat.fly=0;p.hp=20;p.food=20}else if(['survival','s','0','выживание'].includes(m)){creative=0;cheat.god=0;cheat.fly=0}else return lg('gamemode creative | survival','#f66');lg('Режим: '+(creative?'креатив (бессмертие, все блоки на E, двойной пробел — полёт)':'выживание'));ref();hud()},gm:a=>CMD.gamemode(a),
god:()=>{cheat.god^=1;lg('Бессмертие: '+(cheat.god?'ВКЛ':'выкл'))},
fly:()=>{cheat.fly^=1;p.vy=0;flT=performance.now();lg('Полёт: '+(cheat.fly?'ВКЛ (Пробел — вверх, Shift — вниз)':'выкл'))},
give:a=>{let n=1;if(a.length>1&&/^\d+$/.test(a[a.length-1]))n=Math.min(2304,+a.pop());const id=fid(a.join(' '));if(!okI(id))return lg('Неизвестный предмет. Список: items','#f66');add(id,n);lg(`Выдано: ${nm(id)} ×${n}`)},
items:()=>lg('Предметы: '+[...Object.keys(B).filter(i=>B[i].n),...Object.keys(IT).filter(i=>i!=70)].map(i=>i+'='+nm(i)).join(', ')),
tp:a=>{let x,y,z;const n=a.map(Number);if(n.length>=3)[x,y,z]=n;else if(n.length==2&&!n.some(isNaN)){x=n[0];z=n[1];y=col(Math.floor(x),Math.floor(z)).h+3}
else{const r=[...rp.values()].find(r=>r.name.toLowerCase()==(a[0]||'').toLowerCase());if(!r)return lg('tp x y z | tp x z | tp ник','#f66');x=r.tx.x;y=r.tx.y;z=r.tx.z}
if([x,y,z].some(isNaN))return lg('Неверные координаты','#f66');p.x=x;p.y=y+YO;p.z=z;p.vy=0;lg(`Телепорт: ${x|0} ${y|0} ${z|0}`)},
time:a=>{const v=a[0]=='day'?12:a[0]=='night'?0:+a[0];if(a[0]==null||isNaN(v))return lg('time day | night | 0-24','#f66');tm=(((v-6)/24)%1+1)%1;snd({t:'tm',v:tm});lg('Время: '+v+':00')},
heal:()=>{p.hp=20;lg('Здоровье восстановлено')},feed:()=>{p.food=20;lg('Сытость восстановлена')},kill:()=>{p.hp=0},
spawn:()=>{spawn();lg('Вы на точке спавна')},clear:()=>{inv.fill(null);ref();lg('Инвентарь очищен')},seed:()=>lg('Сид: '+seed+' · тип: '+WTY[wt]),
difficulty:a=>{if(ws||!curW)return lg('Сложность меняется только в одиночной игре','#f66');if(curW.diff==5)return lg('«Эксперт» изменить нельзя','#f66');const v=+a[0];if(!(v>=1&&v<=4))return lg('difficulty 1 (мирная) | 2 | 3 | 4 (сложная)','#f66');diff=curW.diff=v;lg('Сложность: '+DN[v])},
say:a=>{const t=a.join(' ');if(!t)return;lg('<'+myName+'> '+t,'#ff0');snd({t:'c',m:t})}};
function run(v){lg('> '+v,'#aaa');const a=v.replace(/^\//,'').split(/\s+/),c=a.shift().toLowerCase();(Object.hasOwn(CMD,c)?CMD[c]:()=>lg('Неизвестная команда. help — список','#f66'))(a)}
applySet();scr('main');


// ---------- главный цикл ----------
const OFF=[];for(let i=-RG;i<=RG;i++)for(let j=-RG;j<=RG;j++)if(i*i+j*j<=RG*RG)OFF.push([i,j]);OFF.sort((a,b)=>a[0]**2+a[1]**2-b[0]**2-b[1]**2);
let last=performance.now(),hT=0,fT=0,gT=0,cT=0,rT=0;
function stream(){const pc=p.x>>4,pz=p.z>>4;let g=0,b=0;
for(const[i,j]of OFF){if(i*i+j*j>(RD+1)*(RD+1))break;const c=ch.get((pc+i)+','+(pz+j));
if(!c){if(g<2){gen(pc+i,pz+j);g++}continue}
if(c.q&&b<2&&i*i+j*j<=RD*RD&&[[1,0],[-1,0],[0,1],[0,-1]].every(d=>ch.get((c.cx+d[0])+','+(c.cz+d[1])))){build(c);b++}}}
// контур выделения повторяет форму блока (дверь целиком, ступеньки, сундук, забор, кровать...)
let hlKey='';
function setHL(tg){const b=get(tg.x,tg.y,tg.z),m=fget(tg.x,tg.y,tg.z);let bx=null,oy=0;
if(b==16){const lo=m&8?tg.y-1:tg.y,r=pbox(16,fget(tg.x,lo,tg.z),tg.x,lo,tg.z,0)[0];bx=[[r[0],0,r[2],r[3],2,r[5]]];oy=lo-tg.y}
else if(PT.has(b))bx=pbox(b,m,tg.x,tg.y,tg.z,0).map(q=>q.slice(0,6));
const key=bx?JSON.stringify(bx):'c';
if(key!==hlKey){hlKey=key;hl.geometry.dispose();const P=[],E=.004;
for(const q of bx||[[0,0,0,1,1,1]]){const x0=q[0]-E,y0=q[1]-E,z0=q[2]-E,x1=q[3]+E,y1=q[4]+E,z1=q[5]+E;
for(const y of[y0,y1])for(const z of[z0,z1])P.push(x0,y,z,x1,y,z);
for(const x of[x0,x1])for(const z of[z0,z1])P.push(x,y0,z,x,y1,z);
for(const x of[x0,x1])for(const y of[y0,y1])P.push(x,y,z0,x,y,z1)}
hl.geometry=new THREE.BufferGeometry();hl.geometry.setAttribute('position',new THREE.Float32BufferAttribute(P,3))}
hl.position.set(tg.x,tg.y+oy,tg.z)}
// ---------- небо: кубическое солнце и луна, облака; частицы бега ----------
const SKYR=140,pixTex=(base,spots)=>{const c=document.createElement('canvas');c.width=c.height=16;const g=c.getContext('2d');g.fillStyle=base;g.fillRect(0,0,16,16);for(const[col,x,y,w,h]of spots){g.fillStyle=col;g.fillRect(x,y,w,h)}const t=new THREE.CanvasTexture(c);t.magFilter=t.minFilter=THREE.NearestFilter;t.generateMipmaps=false;return t},
mkSky=(sz,tex,add)=>{const m=new THREE.Mesh(new THREE.PlaneGeometry(sz,sz),new THREE.MeshBasicMaterial({map:tex,transparent:true,fog:false,depthWrite:false,side:THREE.DoubleSide,blending:add?THREE.AdditiveBlending:THREE.NormalBlending}));m.frustumCulled=false;scene.add(m);return m},
glowTex=(()=>{const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d'),r=g.createRadialGradient(32,32,2,32,32,32);r.addColorStop(0,'rgba(255,240,170,.9)');r.addColorStop(.35,'rgba(255,210,100,.3)');r.addColorStop(1,'rgba(255,200,80,0)');g.fillStyle=r;g.fillRect(0,0,64,64);return new THREE.CanvasTexture(c)})(),
sunM=mkSky(30,pixTex('#ffe566',[['#fff7b8',3,3,10,10],['#ffd23a',0,0,16,1],['#ffd23a',0,15,16,1],['#ffd23a',0,0,1,16],['#ffd23a',15,0,1,16]])),
moonM=mkSky(24,pixTex('#dde1e8',[['#b4bac6',3,3,3,3],['#b4bac6',9,2,2,2],['#b4bac6',9,8,4,4],['#b4bac6',2,10,3,3],['#c9ced8',6,12,2,2]])),
sunG=mkSky(120,glowTex,true);
const DUSK=new THREE.Color(0xe0643a),TA=Math.asin(.25)/6.2832;
// сутки = 20 минут: день 10 мин, закат 1.5, ночь 7, рассвет 1.5 (tm — прежняя шкала, скорость зависит от фазы)
function tmRate(t){if(t>=1-TA||t<TA||(t>=.5-TA&&t<.5+TA))return 2*TA/90;return t<.5-TA?(.5-2*TA)/600:(.5-2*TA)/420}
const starP=[];for(let i=0;i<350;i++){let x,y,z,l;do{x=Math.random()*2-1;y=Math.random()*2-1;z=Math.random()*2-1;l=Math.hypot(x,y,z)}while(l>1||l<.2);starP.push(x/l*SKYR*.95,y/l*SKYR*.95,z/l*SKYR*.95)}
const starG=new THREE.BufferGeometry();starG.setAttribute('position',new THREE.Float32BufferAttribute(starP,3));
const starM=new THREE.Points(starG,new THREE.PointsMaterial({color:0xffffff,size:2.2,sizeAttenuation:false,transparent:true,fog:false,depthWrite:false}));starM.frustumCulled=false;scene.add(starM);
const CLW=360,CLY=150,cloudMat=new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.78,fog:false,depthWrite:false}),CLB=new THREE.BoxGeometry(1,1,1),CL=[];
for(let i=0;i<64;i++){const m=new THREE.Mesh(CLB,cloudMat);m.frustumCulled=false;scene.add(m);m.material=cloudMat.clone();CL.push({m,x:Math.random()*CLW,z:Math.random()*CLW,w:16+Math.random()*44,d:12+Math.random()*30,h:4+Math.random()*3})}
let cloudT=0;
function updSky(dt,df,cb){const th=tm*6.2832,dx=Math.cos(th),dy=Math.sin(th),dz=.28,L=Math.hypot(dx,dy,dz),cp=camera.position,uw=cb==7||cb==8;
sunM.position.set(cp.x+dx/L*SKYR,cp.y+dy/L*SKYR,cp.z+dz/L*SKYR);sunG.position.copy(sunM.position);moonM.position.set(cp.x-dx/L*SKYR,cp.y-dy/L*SKYR,cp.z-dz/L*SKYR);
sunM.visible=sunG.visible=!uw&&dy>-.15;moonM.visible=!uw&&dy<.15;for(const m of[sunM,moonM,sunG])m.lookAt(cp);sunG.material.opacity=Math.max(0,Math.min(1,dy*4+.2));
starM.position.copy(cp);starM.rotation.z=th;starM.material.opacity=uw?0:Math.max(0,1-df*1.7);starM.visible=starM.material.opacity>0;
SUNU.value.set(dx/L,dy/L,dz/L,OP.sunsh?Math.max(0,Math.min(1,dy*3)):0);
cloudT+=dt;cloudMat.color.setScalar(.28+.72*df);
for(const o of CL){const rx=((o.x+cloudT*2.4-cp.x)%CLW+CLW)%CLW-CLW/2,rz=((o.z-cp.z)%CLW+CLW)%CLW-CLW/2,f=Math.max(0,Math.min(1,(150-Math.hypot(rx,rz))/50));
o.m.visible=!!OP.clouds&&f>0&&!uw;o.m.position.set(cp.x+rx,CLY,cp.z+rz);o.m.scale.set(o.w,o.h,o.d);o.m.material.color.copy(cloudMat.color);o.m.material.opacity=.78*f}}
const FXN=160,fxM=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshBasicMaterial(),FXN),fxD=new THREE.Object3D(),fxP=[],fxTile=new Map();let fxAcc=0;
fxM.frustumCulled=false;for(let i=0;i<FXN;i++){fxP.push({l:0,x:0,y:0,z:0,vx:0,vy:0,vz:0,s:0});fxM.setColorAt(i,new THREE.Color(1,1,1));fxD.scale.set(0,0,0);fxD.updateMatrix();fxM.setMatrixAt(i,fxD.matrix)}scene.add(fxM);
function fxPix(b){const ti=B[b].t[0];let d=fxTile.get(ti);if(!d){d=cx.getImageData(ti*16,0,16,16).data;fxTile.set(ti,d)}const k=((Math.random()*16|0)*16+(Math.random()*16|0))*4;return[d[k]/255,d[k+1]/255,d[k+2]/255]}
function updRunFx(dt){const sp=Math.hypot(p.vx,p.vz),col=new THREE.Color();
if(locked&&p.g&&sp>5&&OP.part&&!slp&&!cheat.fly){const b=get(Math.floor(p.x),Math.floor(p.y-.08),Math.floor(p.z));
if(b&&B[b]&&b!=7&&b!=8&&b!=51&&b!=52&&b!=61){fxAcc+=dt*26*(OP.part==1?.5:1);
while(fxAcc>=1){fxAcc--;const q=fxP.find(o=>o.l<=0);if(!q)break;const c=fxPix(b),r=()=>Math.random()-.5;q.l=.45+Math.random()*.4;q.x=p.x-p.vx/sp*.25+r()*.4;q.y=p.y+.05;q.z=p.z-p.vz/sp*.25+r()*.4;q.vx=-p.vx*.12+r()*1.2;q.vy=1+Math.random()*1.6;q.vz=-p.vz*.12+r()*1.2;q.s=.06+Math.random()*.07;q.c=c}}}
fxM.material.color.setScalar(Math.max(.25,plS));
for(let i=0;i<FXN;i++){const q=fxP[i];if(q.l>0){q.l-=dt;q.vy-=14*dt;q.x+=q.vx*dt;q.y+=q.vy*dt;q.z+=q.vz*dt;const s=q.l>0?q.s*Math.min(1,q.l/.2):0;fxD.position.set(q.x,q.y,q.z);fxD.scale.set(s,s,s);fxD.updateMatrix();fxM.setMatrixAt(i,fxD.matrix);col.setRGB(q.c[0],q.c[1],q.c[2]);fxM.setColorAt(i,col)}else if(q.s>0){q.s=0;fxD.scale.set(0,0,0);fxD.updateMatrix();fxM.setMatrixAt(i,fxD.matrix)}}
fxM.instanceMatrix.needsUpdate=true;fxM.instanceColor.needsUpdate=true}

// ---------- частицы ломания блока (выживание: пока копаешь; выживание и креатив: при разрушении) ----------
const BFN=400,bfM=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshBasicMaterial(),BFN),bfD=new THREE.Object3D(),bfP=[];let bfI=0;
bfM.frustumCulled=false;for(let i=0;i<BFN;i++){bfP.push({l:0,x:0,y:0,z:0,vx:0,vy:0,vz:0,s:0,c:[1,1,1]});bfM.setColorAt(i,new THREE.Color(1,1,1));bfD.scale.set(0,0,0);bfD.updateMatrix();bfM.setMatrixAt(i,bfD.matrix)}scene.add(bfM);
function bfPix(b){const T=B[b]&&B[b].t;if(!T)return null;const ti=T[Math.random()<.65?(T[2]!==undefined?2:0):0];if(ti===undefined)return null;let d=fxTile.get(ti);if(!d){d=cx.getImageData(ti*16,0,16,16).data;fxTile.set(ti,d)}const k=((Math.random()*16|0)*16+(Math.random()*16|0))*4;return[d[k]/255,d[k+1]/255,d[k+2]/255]}
function blockFx(b,x,y,z,n,hit){if(!OP.part||!b||!B[b]||b==7||b==8)return;n=Math.ceil(n*(OP.part==1?.5:1));for(let i=0;i<n;i++){const c=bfPix(b);if(!c)return;const q=bfP[bfI=(bfI+1)%BFN],r=()=>Math.random()-.5;q.l=.5+Math.random()*.6;q.s=hit?.05+Math.random()*.05:.07+Math.random()*.09;q.c=c;
q.x=x+.5+r()*.9;q.y=y+.5+r()*.9;q.z=z+.5+r()*.9;const ox=q.x-x-.5,oz=q.z-z-.5,k=hit?1.2:2.6;q.vx=ox*k+r()*.8;q.vz=oz*k+r()*.8;q.vy=hit?.6+Math.random()*1.4:1+Math.random()*2.6}}
function updBlockFx(dt){const col=new THREE.Color();bfM.material.color.setScalar(Math.max(.25,plS));
for(let i=0;i<BFN;i++){const q=bfP[i];if(q.l>0){q.l-=dt;q.vy-=16*dt;let nx=q.x+q.vx*dt,ny=q.y+q.vy*dt,nz=q.z+q.vz*dt;const gb=get(Math.floor(nx),Math.floor(ny),Math.floor(nz));if(gb&&gb!=7&&gb!=8&&B[gb]&&B[gb].h){if(q.vy<0){ny=q.y;q.vy=0}q.vx*=Math.max(0,1-dt*10);q.vz*=Math.max(0,1-dt*10);nx=q.x+q.vx*dt;nz=q.z+q.vz*dt}q.x=nx;q.y=ny;q.z=nz;const s=q.l>0?q.s*Math.min(1,q.l/.2):0;bfD.position.set(q.x,q.y,q.z);bfD.scale.set(s,s,s);bfD.updateMatrix();bfM.setMatrixAt(i,bfD.matrix);col.setRGB(q.c[0],q.c[1],q.c[2]);bfM.setColorAt(i,col);if(q.l<=0)q.s=0}}
bfM.instanceMatrix.needsUpdate=true;bfM.instanceColor.needsUpdate=true}
let bgTick=false;
function frame(now){if(!bgTick)requestAnimationFrame(frame);const dt=Math.min(.033,(now-last)/1000);last=now;
stream();updateBoats(dt,now);fT+=dt;if(fT>.25){fT=0;fluid()}cT+=dt;if(cT>1){cT=0;growCrops()}updHearts(dt);updateAir(dt);
tm=(tm+dt*tmRate(tm))%1;const df=Math.max(0,Math.min(1,Math.sin(tm*6.2832)*2+.5)),br=Math.min(1,.25+OP.bri+(.75-OP.bri)*df);DF=df;
skyC.copy(NIGHT).lerp(SKY,df);{const tw=1-Math.abs(df*2-1);if(tw>0)skyC.lerp(DUSK,tw*.75)}BRU.value=br;const LV=(o,x,y,z)=>{const u=o.userData;if((u.lT=(u.lT||0)-dt)<=0){u.lT=.3+Math.random()*.2;u.lv=lightAt(x,y+.8,z)}return u.lv},dim=(g,l)=>g.traverse(o=>{const b=o.material&&o.material.userData.b;if(b){o.material.color.copy(b).multiplyScalar(l);if(g.userData.fl>0)o.material.color.lerp(RED,Math.min(1,g.userData.fl*1.6))}});an.forEach(a=>{dim(a.m,LV(a.m,a.x,a.y,a.z));if(a.m.userData.fl>0)a.m.userData.fl-=dt});mobs.forEach(a=>{dim(a.m,LV(a.m,a.x,a.y,a.z));if(a.m.userData.fl>0)a.m.userData.fl-=dt});rp.forEach(r=>dim(r.g,LV(r.g,r.g.position.x,r.g.position.y,r.g.position.z)));dim(me,plS);fogN.color.copy(skyD);
const wet=cell(p.x,p.y+.5,p.z)==7,lava=cell(p.x,p.y+.3,p.z)==8||cell(p.x,p.y+1,p.z)==8,sw=wet||lava;
sneak=locked&&(keys.ShiftLeft||keys.ShiftRight)&&!cheat.fly&&!sw&&!slp?1:0;snk+=(sneak-snk)*Math.min(1,dt*12);
if(sneak)p.h=1.5;else if(p.h<1.8&&!hit({w:p.w,h:1.8},p.x,p.y,p.z))p.h=1.8;
if(locked){const f=(keys.KeyW?1:0)-(keys.KeyS?1:0),s=(keys.KeyD?1:0)-(keys.KeyA?1:0),ctl=keys.ControlLeft||keys.ControlRight,spr=ctl&&f>0&&p.food>6&&!sneak,fb=cheat.fly&&ctl;
const sp=4.3*(spr&&!cheat.fly?1.4:1)*(sw&&!cheat.fly?.55:1)*(cheat.fly?(fb?5:2.2):1)*(sneak?.3:1),l=Math.hypot(f,s)||1,sy=Math.sin(p.yaw),cy=Math.cos(p.yaw);
p.vx=(-sy*f+cy*s)/l*sp;p.vz=(-cy*f-sy*s)/l*sp;if(ridingBoat){me.visible=true;const bo=ridingBoat,bu=bo.userData;bu.vx=bu.vx||0;bu.vz=bu.vz||0;
// D — вправо (по часовой), A — влево; камера поворачивается вместе с лодкой
const turn=-s*dt*(bu.water?1.9:1.1);bo.rotation.y+=turn;p.yaw+=turn;
// голову нельзя повернуть дальше ~100° от носа лодки
{let rel=p.yaw-bo.rotation.y;rel=Math.atan2(Math.sin(rel),Math.cos(rel));if(Math.abs(rel)>1.75)p.yaw=bo.rotation.y+Math.sign(rel)*1.75}
const yaw=bo.rotation.y,fx=-Math.sin(yaw),fz=-Math.cos(yaw),lx=-fz,lz=fx,inW=bu.water;
let vf=bu.vx*fx+bu.vz*fz,vl=bu.vx*lx+bu.vz*lz;
vf+=(f>0?f:f*.45)*(inW?5.2:1.8)*dt;vf*=Math.max(0,1-dt*(inW?.65:3.5));vl*=Math.max(0,1-dt*(inW?2.5:9));
bu.vx=fx*vf+lx*vl;bu.vz=fz*vf+lz*vl;
// столкновения лодки с берегом и стенами
const cy0=bo.position.y+.3,bh=(x,z)=>hit({w:.9,h:.5},x,cy0,z),inside=bh(bo.position.x,bo.position.z),nx=bo.position.x+bu.vx*dt,nz=bo.position.z+bu.vz*dt;
if(inside||!bh(nx,bo.position.z))bo.position.x=nx;else bu.vx=0;
if(inside||!bh(bo.position.x,nz))bo.position.z=nz;else bu.vz=0;
p.vx=bu.vx;p.vz=bu.vz;p.x=bo.position.x;p.z=bo.position.z;p.y=bo.position.y+.08;p.vy=0;}if(spr&&!cheat.fly)p.food-=dt*.05}else p.vx=p.vz=0;p.vx+=kbx;p.vz+=kbz;kbx*=Math.max(0,1-dt*7);kbz*=Math.max(0,1-dt*7);
if(cheat.fly){p.vy=locked?((keys.Space?1:0)-(keys.ShiftLeft?1:0))*((keys.ControlLeft||keys.ControlRight)?15:9):0}else if(sw){p.vy-=6*dt;p.vy=Math.max(p.vy,-2.5);if(locked&&keys.Space)p.vy=Math.min(p.vy+22*dt,3.3);
if(p.hx&&locked){const l2=Math.hypot(p.vx,p.vz);if(l2>.1&&!sol(Math.floor(p.x+p.vx/l2*.7),Math.floor(p.y+1.9),Math.floor(p.z+p.vz/l2*.7)))p.vy=Math.max(p.vy,10.5)}}
else{p.vy-=26*dt;p.vy=Math.max(p.vy,-28);if(locked&&keys.Space&&p.g)p.vy=8.6}
const v0=p.vy;let mx=p.vx*dt,mz=p.vz*dt;
if(sneak&&p.g){const st=.05,sh=a=>Math.abs(a)<st?0:a-Math.sign(a)*st; // на краю блока не даём упасть
while(mx&&!hit(p,p.x+mx,p.y-.6,p.z))mx=sh(mx);while(mz&&!hit(p,p.x,p.y-.6,p.z+mz))mz=sh(mz);while(mx&&mz&&!hit(p,p.x+mx,p.y-.6,p.z+mz)){mx=sh(mx);mz=sh(mz)}}
if(ridingBoat){me.visible=true;p.x=ridingBoat.position.x;p.z=ridingBoat.position.z;p.y=ridingBoat.position.y+.08;me.position.set(p.x,p.y,p.z);me.rotation.y=ridingBoat.rotation.y+Math.PI}else{me.visible=false;mv(p,mx,p.vy*dt,mz);}if(creative&&cheat.fly&&p.g&&v0<0&&performance.now()-flT>300)cheat.fly=0;
if(p.g&&v0<-5&&!sw&&!cheat.fly)trample();if(p.g&&v0<-10&&!sw)shk=Math.min(1,(-v0-8)/14);if(p.g&&v0<-13&&!sw){p.hp-=(-v0-12)*1.2*aDef();toast('Ай! Падение')}
if(p.g&&!sw&&locked&&!cheat.fly&&Math.hypot(p.vx,p.vz)>.5){stepD+=Math.hypot(p.vx,p.vz)*dt;if(stepD>1.9){stepD=0;bsound(cell(p.x,p.y-.5,p.z),0)}}
if(wet&&!wasWet&&!sfx('splash',.8))noise(.35,.35,1800,'lowpass');wasWet=wet;
if(p.hp<lastHp-.5&&now-hurtT>400){hurtT=now;if(!sfx('hurt',.9,.95+Math.random()*.1)){tone(260,.25,'sawtooth',.22,110);noise(.1,.2,800)}}lastHp=p.hp;
if(lava)p.hp-=4*dt*aDef();if(p.y<-5)p.hp=0;
if(dfc()>1)p.food-=dt*.04;if(dfc()==1&&p.hp<20&&p.hp>0)p.hp=Math.min(20,p.hp+dt*.5);if(p.food>=18&&p.hp<20)p.hp=Math.min(20,p.hp+dt*.6);if(p.food<=0){p.food=0;p.hp-=dt*.5}
if(cheat.god){p.hp=20;p.food=20;if(p.y<-5)spawn()}if(p.hp<=0&&!dd)die();
{const bY=ridingBoat?ridingBoat.rotation.y:0,sz=ridingBoat?SEAT_Z:0;camera.position.set(p.x+Math.sin(bY)*sz,p.y+(ridingBoat?1.62-SEAT_DROP:(slp?.45:1.62-.35*snk)),p.z+Math.cos(bY)*sz)}camera.rotation.set(p.pitch,p.yaw,0);
if(shk>0){shk=Math.max(0,shk-dt*1.6);const q=shk*.09;camera.position.x+=(Math.random()-.5)*q;camera.position.y+=(Math.random()-.5)*q;camera.rotation.z=(Math.random()-.5)*shk*.08;camera.rotation.x+=(Math.random()-.5)*shk*.05}
if((skyTt-=dt)<=0){skyTt=.15;let m=0;const X=Math.floor(p.x),Y=Math.floor(p.y+1.6),Z=Math.floor(p.z);for(let i=-2;i<=2;i++)for(let j=-2;j<=2;j++){const v=lt(X+i*3,Y,Z+j*3);if(v>m)m=v}skyT=m}skyF+=(skyT-skyF)*Math.min(1,dt*3);skyD.copy(skyC).multiplyScalar(skyF);dynLights();plS+=(lightAt(p.x,p.y+1,p.z)-plS)*Math.min(1,dt*6);
const cb=cell(p.x,p.y+1.62,p.z);scene.fog=cb==7?fogW:cb==8?fogL:fogN;scene.background.copy(cb==7?new THREE.Color(0x2040a0):cb==8?new THREE.Color(0xc04010):skyD);
tg=locked?ray([25,26,27].includes(held())||(oh[0]&&!usable(held())&&[25,26,27].includes(oh[0].id))):null;if(tg){setHL(tg);hl.visible=true}else hl.visible=false;
const pb=$('pb'),bk=tg&&(creative&&get(tg.x,tg.y,tg.z)==55?{h:1}:B[get(tg.x,tg.y,tg.z)]); // бедрок ломается только в креативе
if(mining&&bk&&bk.h&&locked){const k=tg.x+','+tg.y+','+tg.z;if(mT.k!=k)mT={k,t:0};
mT.t+=dt*(creative?1e3:toolMul(held(),get(tg.x,tg.y,tg.z)));pb.style.display='block';if(swingT<=0)swingT=.3;if((hitT-=dt)<=0){hitT=.22;bsound(get(tg.x,tg.y,tg.z),1);if(!creative)blockFx(get(tg.x,tg.y,tg.z),tg.x,tg.y,tg.z,5,1)}pb.firstChild.style.width=Math.min(100,mT.t/bk.h*100)+'%';{const st=Math.floor(Math.min(1,mT.t/bk.h)*10);crack.visible=st>=1;if(st>=1){crack.material.map=CK[Math.min(9,st-1)];crack.position.set(tg.x+.5,tg.y+.5,tg.z+.5)}sendCr(tg.x,tg.y,tg.z,st)}
if(mT.t>=bk.h){const b=get(tg.x,tg.y,tg.z),fm=fget(tg.x,tg.y,tg.z);let dr=bk.d===undefined?b:bk.d;const X=tg.x+.5,Y=tg.y+.3,Z=tg.z+.5;if(b==52&&Math.random()<.2)dropItem(45,1,X,Y,Z);if(b==51){const sg=fm&3;if(sg==3){dropItem(46,1,X,Y,Z);dropItem(45,1+(Math.random()*2|0),X,Y,Z)}else dropItem(45,1,X,Y,Z)}blockFx(b,tg.x,tg.y,tg.z,26);pset(tg.x,tg.y,tg.z,0,0);chkT(tg.x,tg.y,tg.z);if(b==16){unpairDoor(tg.x,tg.y,tg.z,fm);const y2=tg.y+(fm&8?-1:1);if(get(tg.x,y2,tg.z)==16)pset(tg.x,y2,tg.z,0,0)}if(b==17){dr=38+((fm>>2)&3);const d=fm&3,sg=fm&16?-1:1,x2=tg.x+[1,-1,0,0][d]*sg,z2=tg.z+[0,0,1,-1][d]*sg;if(get(x2,tg.y,z2)==17)pset(x2,tg.y,z2,0,0)}bsound(b,2);crack.visible=false;crReset();if(get(tg.x,tg.y+1,tg.z)==52)pset(tg.x,tg.y+1,tg.z,0,0);if(b==5)decayAround(tg.x,tg.y,tg.z);if(b==53){const fk=tg.x+','+tg.y+','+tg.z,f=furn.get(fk);if(f){f.s.forEach(q=>q&&dropItem(q.id,q.n,X,Y,Z));furn.delete(fk)}}
if(b==62){const ck=tg.x+','+tg.y+','+tg.z,ca=chests.get(ck);if(ca){ca.forEach(q=>q&&dropItem(q.id,q.n,X,Y,Z,q.w));chests.delete(ck);syncChest(ck)}const pc=(fm>>2)&7;if(pc){const d=HD[pc-1],x2=tg.x+d[0],z2=tg.z+d[1];if(get(x2,tg.y,z2)==62)pset(x2,tg.y,z2,62,fget(x2,tg.y,z2)&3)}}
const rq=REQ[b];if(rq&&ptier(held())<rq){dr=0;if(!creative)toast('Эта кирка слишком слабая — добыча потеряна')}
if(!creative&&B[b]&&B[b].s&&ptier(held())<1){dr=0;toast('Камень нужно добывать киркой — ничего не выпало')}if(dr)dropItem(dr,1,X,Y,Z);wearTool(1);mT={k:'',t:0}}}
else{pb.style.display='none';crack.visible=false;crReset();mT={k:'',t:0}}
bowTick(dt);mobFrame(dt);for(const a of an){updA(a,dt);{const sp=Math.hypot(a.x-(a.px??a.x),a.z-(a.pz??a.z))/Math.max(dt,.001);a.px=a.x;a.pz=a.z;anim(a.m,sp,dt)}if((a.sT=(a.sT||Math.random()*8)-dt)<0){a.sT=6+Math.random()*10;if(Math.hypot(a.x-p.x,a.z-p.z)<20)asound(a.kind,0)}}
for(const a of an)if(a.love>0){a.hT=(a.hT||0)-dt;if(a.hT<=0){a.hT=.8;heart(a.x,a.y+a.h+.3,a.z)}}if(host())breed(dt);rT+=dt;if(rT>.5){rT=0;randTick()}decayTick(dt);sleepTick(dt);furnTick(dt);
gT+=dt;if(gT>5){gT=0;for(let i=an.length-1;i>=0;i--)if(Math.hypot(an[i].x-p.x,an[i].z-p.z)>110){scene.remove(an[i].m);an.splice(i,1)}
for(const c of ch.values())if(c.m&&Math.hypot(c.cx-(p.x>>4),c.cz-(p.z>>4))>RD+2){drop(c);c.q=1}}
hT+=dt;if(hT>.2){hT=0;hud();furnUI();const hh=Math.floor((tm*24+6)%24),k=col(Math.floor(p.x),Math.floor(p.z)).bi;
$('info').textContent=`Minecraft HTML ${VER}\nX ${p.x.toFixed(0)} Y ${(p.y-YO).toFixed(0)} Z ${p.z.toFixed(0)} · ${['Равнины','Лес','Пустыня','Тундра'][k]} · ${hh}:00 ${df>.5?'день':'ночь'} · ${DN[dfc()]}${held()?' · '+nm(held()):''}`}
upArm(me,arm.map(a=>a?a.id:0));syncMyHeld();me.visible=view>0;me.position.set(p.x,p.y,p.z);me.rotation.y=ridingBoat?ridingBoat.rotation.y+Math.PI:p.yaw+Math.PI;if(ridingBoat){const bY=ridingBoat.rotation.y;me.position.set(p.x+Math.sin(bY)*SEAT_Z,p.y-SEAT_DROP,p.z+Math.cos(bY)*SEAT_Z)}swingT=Math.max(0,swingT-dt);anim(me,Math.hypot(p.vx,p.vz),dt,!p.g&&!sw,swingT,p.pitch,sneak);if(ridingBoat){const dY=p.yaw-ridingBoat.rotation.y;me.userData.hd.rotation.y=Math.atan2(Math.sin(dY),Math.cos(dY))}lieSync(me,slp,p.x,p.y,p.z,sleepH[0],sleepH[1]);
if(view){const d=new THREE.Vector3(),sg=view==1?-1:1;camera.getWorldDirection(d);let t=0;for(;t<4;t+=.1)if(sol(Math.floor(p.x+d.x*t*sg),Math.floor(p.y+1.62+d.y*t*sg),Math.floor(p.z+d.z*t*sg)))break;camera.position.addScaledVector(d,sg*Math.max(0,t-.3));if(view==2)camera.rotation.set(-p.pitch,p.yaw+Math.PI,0)}
for(const [rid,r] of rp){if(r.g.userData.lying)r.g.position.copy(r.tx);upArm(r.g,r.ar||[0,0,0,0]);const ox=r.g.position.x,oy=r.g.position.y,oz=r.g.position.z;r.g.position.lerp(r.tx,.25);r.g.rotation.y=r.yaw+Math.PI;r.pc=(r.pc||0)+((r.pt||0)-(r.pc||0))*Math.min(1,dt*14);r.swT=Math.max(0,(r.swT||0)-dt);anim(r.g,Math.hypot(r.g.position.x-ox,r.g.position.z-oz)/Math.max(dt,.001),dt,Math.abs(r.g.position.y-oy)/Math.max(dt,.001)>1.2,r.swT,r.pc,r.sn);{const sl=sleepers.has(rid),bx=Math.floor(r.tx.x),by=Math.floor(r.tx.y-.2),bz=Math.floor(r.tx.z),hd=sl&&get(bx,by,bz)==17?HD[fget(bx,by,bz)&3]:[0,1];lieSync(r.g,sl,r.tx.x,r.tx.y,r.tx.z,hd[0],hd[1])}}
nT+=dt;if(nT>.1){nT=0;snd({t:'p',x:p.x,y:p.y,z:p.z,yaw:p.yaw,h:held(),o:oh[0]?oh[0].id:0,ar:arm.map(a=>a?a.id:0),pt:+p.pitch.toFixed(2),sn:sneak,s:swingT>0?1:0});if(host()&&(mobs.length||mobSent)){mobSent=mobs.length;snd({t:'mo',a:mobs.map(m=>[m.id,m.type,+m.x.toFixed(2),+m.y.toFixed(2),+m.z.toFixed(2),+m.m.rotation.y.toFixed(2),+m.hp.toFixed(1),m.aim?1:0])})}if(host()&&an.length)snd({t:'a',a:an.map(a=>[a.k,+a.x.toFixed(2),+a.y.toFixed(2),+a.z.toFixed(2),+a.m.rotation.y.toFixed(2),a.kind,a.col,a.age==null?-1:Math.round(a.age),a.love>0?1:0])})}
animLids(dt);updSky(dt,df,cb);updRunFx(dt);updBlockFx(dt);updHand(dt,plS);updDrops(dt,plS);renderer.autoClear=false;if(!bgTick){renderer.render(scene,camera);if(view==0&&!slp&&OP.hand){renderer.clearDepth();renderer.render(hs,hc)}}}
// В свёрнутой вкладке requestAnimationFrame не работает — игра «замирала» (и позиции, и животные у всех).
// Пока вкладка скрыта, логику крутит таймер из воркера (его браузер не замедляет), без отрисовки.
try{const W=new Worker(URL.createObjectURL(new Blob(['setInterval(()=>postMessage(0),30)'],{type:'text/javascript'})));
W.onmessage=()=>{if(document.hidden&&started&&!bgTick){bgTick=true;try{frame(performance.now())}catch(e){}bgTick=false}}}catch(e){}
// при сворачивании/потере фокуса отпускаем зажатые клавиши, чтобы персонаж не «залипал»
addEventListener('blur',()=>{for(const k in keys)keys[k]=0;mining=false});
