const { app, BrowserWindow } = require('electron');
// Linux: если камера всё ещё дёргается, попробуйте MC_OZONE=x11 ./start.sh  или  MC_OZONE=wayland ./start.sh
if (process.platform === 'linux' && process.env.MC_OZONE) app.commandLine.appendSwitch('ozone-platform', process.env.MC_OZONE);
app.whenReady().then(() => {
  const w = new BrowserWindow({ width: 1280, height: 720, autoHideMenuBar: true, webPreferences: { backgroundThrottling: false }, title: 'Minecraft HTML' });
  w.loadFile('minecraft.html');
});
app.on('window-all-closed', () => app.quit());
