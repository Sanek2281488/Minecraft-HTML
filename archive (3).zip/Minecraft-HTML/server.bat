@echo off
if not exist node_modules\ws (call npm install)
if not exist world.json (set /p WORLD=World type [normal/flat/amp/isl], Enter = normal: )
if "%WORLD%"=="" set WORLD=normal
node server.js
pause
