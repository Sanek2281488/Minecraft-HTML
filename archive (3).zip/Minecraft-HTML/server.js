const http = require('http'), fs = require('fs'), path = require('path'), os = require('os');
const { WebSocketServer } = require('ws');
const PORT = process.env.PORT || 3000, F = path.join(__dirname, 'world.json');
let sv = {}; try { sv = JSON.parse(fs.readFileSync(F)); } catch {}
const seed = sv.seed ?? (Math.random() * 1e4 | 0), wt = sv.wt || process.env.WORLD || 'normal';
const E = new Map((sv.edits || []).map(e => [e[0] + ',' + e[1] + ',' + e[2], e])), dead = new Set(sv.dead || []), pl = new Map(), CH = new Map(sv.chests || []);
let nid = 1;
// сложность мира: 1 мирная … 4 сложная (5 «Эксперт» в мультиплеере работает как 4). Меняется переменной DIFFICULTY или diff в world.json
const DIFF = Math.min(5, Math.max(1, (+(process.env.DIFFICULTY || sv.diff || 3)) | 0)) || 3;
// общее время суток: сутки 20 минут — день 10 мин, закат 1.5, ночь 7, рассвет 1.5 (такая же формула в minecraft.html)
let tmS = .1, tmT = Date.now();
const TA = Math.asin(.25) / 6.2832, tmRate = t => (t >= 1 - TA || t < TA || (t >= .5 - TA && t < .5 + TA)) ? 2 * TA / 90 : t < .5 - TA ? (.5 - 2 * TA) / 600 : (.5 - 2 * TA) / 420;
const TM = () => { const n = Date.now(); let dt = (n - tmT) / 1000; tmT = n; while (dt > 0) { const s = Math.min(dt, .5); tmS = (tmS + s * tmRate(tmS)) % 1; dt -= s; } return tmS; };
const save = () => { try { fs.writeFileSync(F, JSON.stringify({ seed, wt, edits: [...E.values()], dead: [...dead], chests: [...CH], diff: DIFF })); } catch {} };
setInterval(save, 30000); process.on('SIGINT', () => { save(); process.exit(); });
const MIME = { '.ogg': 'audio/ogg', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.png': 'image/png' }, SD = path.join(__dirname, 'sounds'), SK = path.join(__dirname, 'skins');
fs.mkdirSync(SK, { recursive: true });
function safeSkin(n){ return typeof n === 'string' && /^[a-zA-Z0-9_-]{1,32}\.png$/.test(n); }

const CF = path.join(__dirname, 'saves-config.json'); let SDIR = ''; try { SDIR = JSON.parse(fs.readFileSync(CF)).dir || ''; } catch {}
const srv = http.createServer((q, s) => {
  s.setHeader('Access-Control-Allow-Origin', '*'); s.setHeader('Access-Control-Allow-Headers', 'X-Skin-Name, Content-Type'); s.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  if (q.method === 'OPTIONS') { s.writeHead(204); return s.end(); }
  let raw = ''; try { raw = decodeURIComponent((q.url || '/').split('?')[0]); } catch {}
  if (raw.startsWith('/api/store')) {   // хранилище сохранений в выбранной папке (только с этого компьютера)
    if (!/^(::1|127\.0\.0\.1|::ffff:127\.0\.0\.1)$/.test(q.socket.remoteAddress || '')) { s.writeHead(403); return s.end(); }
    const J = (c, o) => { s.writeHead(c, {'Content-Type':'application/json; charset=utf-8'}); s.end(JSON.stringify(o)); };
    const body = (lim, cb) => { const c = []; let n = 0; q.on('data', b => { n += b.length; if (n > lim) q.destroy(); else c.push(b); }); q.on('end', () => cb(Buffer.concat(c))); };
    if (raw === '/api/store-config') {
      if (q.method === 'GET') return J(200, { dir: SDIR });
      if (q.method === 'PUT') return body(4096, b => { try { const d = String(JSON.parse(b).dir || '').trim(); if (d) { const r = path.resolve(d); fs.mkdirSync(r, { recursive: true }); fs.accessSync(r, fs.constants.W_OK); SDIR = r; } else SDIR = ''; fs.writeFileSync(CF, JSON.stringify({ dir: SDIR })); J(200, { dir: SDIR }); } catch (e) { J(400, { error: String(e.message || e) }); } });
    }
    if (!SDIR) return J(404, { error: 'folder not set' });
    if (raw === '/api/store' && q.method === 'GET') return fs.readdir(SDIR, (e, f) => J(200, (f || []).filter(n => /^mc_[a-zA-Z0-9_-]+\.json$/.test(n)).map(n => n.slice(3, -5))));
    const k = raw.slice(11); if (!/^[a-zA-Z0-9_-]{1,40}$/.test(k)) { s.writeHead(400); return s.end(); }
    const fp = path.join(SDIR, 'mc_' + k + '.json');
    if (q.method === 'GET') return fs.readFile(fp, (e, d) => { if (e) { s.writeHead(404); return s.end(); } s.writeHead(200, {'Content-Type':'application/json; charset=utf-8'}); s.end(d); });
    if (q.method === 'PUT') return body(300 * 1048576, b => fs.writeFile(fp, b, e => { s.writeHead(e ? 500 : 200); s.end(); }));
    s.writeHead(405); return s.end();
  }
  if (raw === '/api/skins' && q.method === 'GET') {
    return fs.readdir(SK, (e, files) => { s.writeHead(200, {'Content-Type':'application/json; charset=utf-8'}); s.end(JSON.stringify((files || []).filter(n => safeSkin(n)))); });
  }
  if (raw === '/api/skins' && q.method === 'POST') {
    const name = String(q.headers['x-skin-name'] || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0,32);
    if (!name) { s.writeHead(400); return s.end('Invalid skin name'); }
    let chunks = [], size = 0;
    q.on('data', b => { size += b.length; if (size > 2*1024*1024) { s.writeHead(413); s.end('PNG too large'); q.destroy(); } else chunks.push(b); });
    q.on('end', () => { const b = Buffer.concat(chunks); if (b.length < 8 || b.subarray(0,8).toString('hex') !== '89504e470d0a1a0a') { s.writeHead(400); return s.end('Upload a PNG file'); }
      fs.writeFile(path.join(SK, name + '.png'), b, e => { if (e) { s.writeHead(500); return s.end('Save failed'); } s.writeHead(200, {'Content-Type':'application/json'}); s.end(JSON.stringify({name:name+'.png'})); });
    }); return;
  }

  let u = ''; try { u = decodeURIComponent((q.url || '/').split('?')[0]); } catch {}
  if (u.startsWith('/skins/')) {
    const n = path.basename(u.slice(7));
    if (!safeSkin(n)) { s.writeHead(403); return s.end(); }
    return fs.readFile(path.join(SK, n), (e,d) => { if(e){s.writeHead(404);return s.end();} s.writeHead(200, {'Content-Type':'image/png','Cache-Control':'no-cache'}); s.end(d); });
  }
  if (u.startsWith('/sounds/')) { // звуки для всех игроков раздаёт сервер
    const f = path.join(__dirname, u);
    if (!f.startsWith(SD + path.sep)) { s.writeHead(403); return s.end(); }
    return fs.readFile(f, (e, d) => { if (e) { s.writeHead(404); return s.end(); } s.writeHead(200, { 'Content-Type': MIME[path.extname(f).toLowerCase()] || 'application/octet-stream' }); s.end(d); });
  }
  fs.readFile(path.join(__dirname, 'minecraft.html'), (e, d) => {
    if (e) { s.writeHead(404); return s.end('minecraft.html не найден'); }
    s.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); s.end(d);
  });
});
const wss = new WebSocketServer({ server: srv });
setInterval(() => { const ts = Date.now(); wss.clients.forEach(c => { if (c.readyState === 1) c.send(JSON.stringify({ t: 'pg', ts })); }); }, 2000);   // пинг игроков для списка по Tab
setInterval(() => { const p = {}; pl.forEach((P, i) => { if (P.ping != null) p[i] = P.ping; }); bc({ t: 'pings', p }); }, 1000);
const bc = (m, ex) => { const s = JSON.stringify(m); wss.clients.forEach(c => { if (c !== ex && c.readyState === 1) c.send(s); }); };
wss.on('connection', (ws, req) => {
  const id = nid++, name = (new URL(req.url, 'http://x').searchParams.get('n') || 'Игрок' + id).slice(0, 16);
  pl.set(id, { id, name, x: 0, y: 100, z: 0, yaw: 0, skin: '', sd: '', h: 0, o: 0 });
  ws.send(JSON.stringify({ t: 'init', v: 2, df: DIFF, id, seed, wt, tm: TM(), edits: [...E.values()], dead: [...dead], chests: [...CH], players: [...pl.values()].filter(p => p.id !== id) }));
  bc({ t: 'join', p: pl.get(id) }, ws);
  console.log('+', name);
  ws.on('message', d => {
    let m; try { m = JSON.parse(d); } catch { return; }
    const P = pl.get(id);
    if (m.t === 'pg') { P.ping = Math.max(0, Math.min(999, Date.now() - m.ts | 0)); }
    else if (m.t === 'boat') { if (m.a === 'place' || m.a === 'remove') bc(m, ws); }
    else if (m.t === 'p') { Object.assign(P, { x: m.x, y: m.y, z: m.z, yaw: m.yaw, h: m.h || 0, o: m.o || 0, d: m.d || 0 }); bc({ t: 'p', id, x: m.x, y: m.y, z: m.z, yaw: m.yaw, h: P.h, o: P.o, ar: m.ar, pt: m.pt, sn: m.sn, s: m.s, d: m.d || 0 }, ws); }
    else if (m.t === 'skin') { const skin = typeof m.skin === 'string' && safeSkin(m.skin) ? m.skin : '', sd = skin && typeof m.data === 'string' && m.data.startsWith('data:image/png;base64,') && m.data.length < 400000 ? m.data : ''; P.skin = skin; P.sd = sd; console.log('skin', name, skin || '(снят)', sd ? sd.length + ' байт' : 'без данных'); bc({ t: 'skin', id, skin, data: sd }, ws); }   // скин: имя + PNG, чтобы все видели одно и то же
    else if (m.t === 'b') { // блоки и жидкости: дубли от разных клиентов отбрасываются
      const k = m.x + ',' + m.y + ',' + m.z, o = E.get(k);
      if (o && o[3] === m.b && o[4] === m.f) return;
      E.set(k, [m.x, m.y, m.z, m.b, m.f]); bc(m, ws);
    }
    else if (m.t === 'd') { if (m.hp <= 0) dead.add(m.k); bc(m, ws); }   // урон животным
    else if (m.t === 'k') { if (typeof m.k !== 'string') return; if (Array.isArray(m.s) && m.s.length <= 27) CH.set(m.k, m.s); else CH.delete(m.k); bc(m, ws); }   // содержимое сундуков
    else if (m.t === 'a') bc(m, ws);
    else if (m.t === 'm') bc({ t: 'm', id, x: m.x | 0, y: m.y | 0, z: m.z | 0, s: Math.max(0, Math.min(10, m.s | 0)), h: m.h ? 1 : 0, d: m.d ? 1 : 0 }, ws);   // трещины и удары по блоку (видят все)
    else if (m.t === 'adm' || m.t === 'mo' || m.t === 'mh' || m.t === 'ar' || m.t === 'dm') bc(m, ws);   // враждебные мобы, стрелы, урон игрокам                                       // позиции животных от хоста
    else if (m.t === 'f') bc(m, ws);                                       // кормление животных
    else if (m.t === 'i' || m.t === 'ip') bc(m, ws);                       // выпавшие предметы
    else if (m.t === 'z') bc({ t: 'z', id, v: m.v ? 1 : 0 }, ws);          // сон
    else if (m.t === 'c') bc({ t: 'c', n: name, m: String(m.m).slice(0, 200) }, ws);
    else if (m.t === 'tm') { tmS = ((+m.v % 1) + 1) % 1; tmT = Date.now(); bc(m, ws); }
  });
  ws.on('close', () => { pl.delete(id); bc({ t: 'leave', id }); console.log('-', name); });
});
srv.listen(PORT, '0.0.0.0', () => {
  console.log('Сервер запущен. Мир: ' + wt + ', сид ' + seed + '. Адреса для друзей (порт ' + PORT + '):');
  for (const n of Object.values(os.networkInterfaces())) for (const i of n) if (i.family === 'IPv4' && !i.internal) console.log('  ' + i.address + ':' + PORT);
  console.log('Ты сам заходи на localhost:' + PORT);
});
