#!/usr/bin/env bash
# Запуск сервера на Linux (аналог server.bat). Тип мира: WORLD=flat ./server.sh
cd "$(dirname "$0")" || exit 1
[ -d node_modules/ws ] || npm install || exit 1
if [ ! -f world.json ] && [ -z "$WORLD" ]; then
  read -r -p "World type [normal/flat/amp/isl], Enter = normal: " WORLD
fi
export WORLD="${WORLD:-normal}"
exec node server.js
