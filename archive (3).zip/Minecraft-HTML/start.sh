#!/usr/bin/env bash
# Запуск игры на Linux (аналог start.bat)
cd "$(dirname "$0")" || exit 1
[ -d node_modules/electron ] || npm install || exit 1
# --no-sandbox: у electron из node_modules на Linux часто нет прав на chrome-sandbox
exec npm start -- --no-sandbox "$@"
